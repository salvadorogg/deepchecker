<?php

namespace App\Console\Commands;

use App\Support\Worker\EthereumWorker;
use Exception;
use Illuminate\Console\Command;

/**
 * Class CurrencyEthereum
 */
class CurrencyEthereum extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'currency:ethereum {queue_id}';

    /**
     * @return void
     * @throws Exception
     */
    public function handle(): void
    {
        $worker = new EthereumWorker(
            $this, 'queue_currency_parse_eth_selenium_'.$this->argument('queue_id'), 'eth'
        );

        $worker->work();
    }
}

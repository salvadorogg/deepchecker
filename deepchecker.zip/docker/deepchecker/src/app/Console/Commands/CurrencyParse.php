<?php

namespace App\Console\Commands;

use App\Support\Worker\CurrencyWorker;
use Exception;
use Illuminate\Console\Command;

/**
 * Class CurrencyParse
 */
class CurrencyParse extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'currency:parse {currency}';

    /**
     * @return void
     * @throws Exception
     */
    public function handle(): void
    {
        $worker = new CurrencyWorker(
            $this, 'queue_currency_parse_'.$this->argument('currency'), $this->argument('currency')
        );

        $worker->work();
    }
}

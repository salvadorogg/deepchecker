<?php

namespace App\Console\Commands;

use App\Models\Proxy;
use App\Support\ProxyBus;
use Carbon\Carbon;
use Illuminate\Console\Command;

/**
 * Class ProxyCheck
 */
class ProxyCheck extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'proxy:check';

    /**
     * @param ProxyBus $proxyBus
     */
    public function __construct(
        protected ProxyBus $proxyBus
    )
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        while(true) {
            $needResetCache = false;

            Proxy::get()
                ->each(function(Proxy $proxy) use (&$needResetCache): void {
                    if($proxy->is_active && $this->proxyBus->hasTooManyErrors($proxy)) {
                        $proxy->is_active = 0;
                        $proxy->save();

                        $needResetCache = true;

                        $this->proxyBus->lockForEnabling($proxy);

                        $this->info(Carbon::now()->format('H:i:s').': proxy checker: proxy '.$proxy->id.' excluded from list on 1 hour');

                        return;
                    }

                    if(!$proxy->is_active && !$this->proxyBus->hasLockedEnabling($proxy)) {
                        if($this->proxyBus->isValid($proxy)) {
                            $proxy->is_active = 1;
                            $proxy->save();

                            $this->info(Carbon::now()->format('H:i:s').': proxy checker: proxy '.$proxy->id.' was bad boy, but i think time is come');
                            $needResetCache = true;
                            return;
                        }

                        $this->proxyBus->lockForEnabling($proxy);
                    }
                });

            if($needResetCache) {
                $this->proxyBus->flush();
            }

            sleep(30);
        }
    }
}

<?php

namespace App\Console\Commands;

use App\Models\TelegramCode;
use Carbon\Carbon;
use Illuminate\Console\Command;

/**
 * Class TelegramClear
 */
class TelegramClear extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'telegram:clear';

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        TelegramCode::where('created_at', '<', Carbon::now()->subMinutes(15))->delete();
    }
}

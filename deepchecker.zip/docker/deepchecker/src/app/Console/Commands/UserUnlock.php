<?php

namespace App\Console\Commands;

use App\Models\User;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;

/**
 * Class UserUnlock
 *
 * Команда для хард-анлока процесса добавления
 * новых мнемоников пользователями на тот
 * случай, если процесс добавления прервался
 * из-за серверной ошибки
 */
class UserUnlock extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'user:unlock';

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        User::get()->each(static function(User $user): void {
            $lock = Cache::lock('mnemonics_'.$user->id, 1);

            if(!$lock->get()
                && $user->wallets()->where('created_at', '>', Carbon::now()->subMinute())->doesntExist()) {
                $lock->forceRelease();
            }
        });
    }
}

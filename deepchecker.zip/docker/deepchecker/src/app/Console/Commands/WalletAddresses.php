<?php

namespace App\Console\Commands;

use App\Models\Wallet;
use App\Support\Mnemonic;
use App\Support\QueuePlaner;
use App\Support\Statistic;
use App\Support\Worker\AddressesWorker;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;

/**
 * Class WalletAddresses
 */
class WalletAddresses extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'wallet:addresses {queue_id}';

    /**
     * @return void
     * @throws Exception
     */
    public function handle(): void
    {
        $worker = new AddressesWorker(
            $this, 'queue_addresses_parse_'.$this->argument('queue_id')
        );

        $worker->work();
    }
}

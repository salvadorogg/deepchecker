<?php

namespace App\Console\Commands;

use App\Models\InvalidMnemonic;
use App\Support\CurrencyBuilder;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;

/**
 * Class WalletClear
 */
class WalletClear extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'wallet:clear';

    /**
     * Execute the console command.
     *
     * @return void
     */
    public function handle(): void
    {
        InvalidMnemonic::where('created_at', '<', Carbon::now()->subDay())->delete();

        $currencyBuilder = new CurrencyBuilder;

        $date = Carbon::now()->subDays(2);

        for($i = 1; $i <= 48; $i++) {
            $date->subDay();
            $formatted = $date->format('YmdH');

            foreach($currencyBuilder->all() as $currency) {
                Cache::forget($formatted.'_checked_total_'.$currency->getSlug());
            }

            Cache::forget("{$formatted}_checked_total_addresses");
        }
    }
}

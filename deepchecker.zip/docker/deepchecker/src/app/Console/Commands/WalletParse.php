<?php

namespace App\Console\Commands;

use App\Jobs\AmountChanged;
use App\Models\Wallet;
use App\Support\CurrencyBuilder;
use App\Support\Statistic;
use Carbon\Carbon;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;

/**
 * Class WalletParse
 */
class WalletParse extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'wallet:parse {queue} {--loop}';

    protected string $pid;

    /**
     * WalletParse constructor
     * @param CurrencyBuilder $currencyBuilder
     */
    public function __construct(
        protected CurrencyBuilder $currencyBuilder
    )
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return void
     * @throws Exception
     */
    public function handle(): void
    {
        if($this->option('loop')) {
            while(true) {
                if($this->isRestartRequired()) {
                    $this->restartPlanned();
                    $this->info('Перезапуск очереди...');
                    break;
                }

                sleep(
                    $this->parseWalletsData()
                );
            }
        }
        else {
            $this->parseWalletsData();
        }
    }

    /**
     * @return bool
     */
    protected function isRestartRequired(): bool
    {
        return Cache::has('restart_'.$this->argument('queue').'_parse');
    }

    /**
     * @return void
     */
    protected function restartPlanned(): void
    {
        Cache::forget('restart_'.$this->argument('queue').'_parse');
    }

    /**
     * @return int
     * @throws Exception
     */
    protected function parseWalletsData(): int
    {
        $wallet = Wallet::whereIsNeedCheck()->where('queue_id', $this->argument('queue'))->orderBy('next_check_at')->first()
                    ?? Wallet::whereIsNeedCheck()->where('queue_id', '!=', $this->argument('queue'))->inRandomOrder()->first();

        if(!$wallet) {
            return 10;
        }

        $lock = Cache::lock('wallet.'.$wallet->id, 45);

        if($lock->get()) {
            $startTime = microtime(true);

            $this->info("Starting parse wallet {$wallet->id}.");

            $result = ['total' => 0];

            foreach($this->currencyBuilder->allEnabled() as $currency) {
                $result['total_'.$currency->getSlug()] = 0;
            }

            foreach($wallet->addresses as $currency => $addresses) {
                $addresses = array_values($addresses);
                $currency = $this->currencyBuilder->get($currency);

                if(!$currency->isEnabled()) {
                    continue;
                }

                $result[$currency->getSlug()] = $currency->getResult($addresses);

                foreach($result[$currency->getSlug()] as $value) {
                    $value = is_array($value) ? array_sum($value) : $value;

                    $result['total'] += $value;
                    $result['total_'.$currency->getSlug()] += $value;
                }
            }

            $wallet->previously_result = $wallet->latest_result;
            $wallet->latest_result = $result;
            $wallet->next_check_at = Carbon::now()->addMinutes($wallet->user->check_period);
            $wallet->save();

            $this->info(
                $this->prependTime($startTime, $wallet->id, 'Wallet updated.')
            );

            AmountChanged::dispatchSync($wallet, $result);

            (new Statistic)->put(Statistic::PARSE_KEY, microtime(true) - $startTime);

            $lock->release();

            $sleep = 1;
        }
        else {
            $this->info("Skipped {$wallet->id} because already in parse.");
            $sleep = 5;
        }

        return $sleep;

        /*$currencyBuilder = new CurrencyBuilder;
        $statistic = new Statistic;
        $execTimes = [];

        Wallet::whereIsNeedCheck()
            ->where('queue_id', $this->argument('queue'))
            ->orderBy('next_check_at')->limit(100)->with('user')->get()
            ->each(function(Wallet $wallet) use ($currencyBuilder, &$execTimes): void {
                $startTime = microtime(true);
                $this->info("Starting parse wallet {$wallet->id}.");

                $anotherWallet = Wallet::where('mnemonic', $wallet->mnemonic)->where('id', '!=', $wallet->id)
                    ->whereNotNull('latest_result')->where('updated_at', '>=', Carbon::now()->subMinutes($wallet->user->check_period / 2))
                    ->orderByDesc('updated_at')->first();

                if($anotherWallet) {
                    $this->info(
                        $this->prependTime($startTime, "Another result found in database.")
                    );

                    $result = $anotherWallet->latest_result;
                }
                else {
                    $this->info(
                        $this->prependTime($startTime, "Result not found in database. Fetch APIs...")
                    );
                    $result = ['total' => 0];

                    foreach($wallet->addresses as $currency => $addresses) {
                        $addresses = array_values($addresses);
                        $currency = $currencyBuilder->get($currency);

                        if(!$currency->isEnabled()) {
                            continue;
                        }

                        $this->info(
                            $this->prependTime($startTime, 'Fetch '.$currency->getName().' data...')
                        );

                        $result[$currency->getSlug()] = $currency->getResult($addresses);

                        $this->info(
                            $this->prependTime($startTime, $currency->getName().' fetched.')
                        );

                        foreach($result[$currency->getSlug()] as $value) {
                            $result['total'] += is_array($value) ? array_sum($value) : $value;
                        }

                        $this->info(
                            $this->prependTime($startTime, $currency->getName().' processed.')
                        );
                    }
                }

                $wallet->previously_result = $wallet->latest_result;
                $wallet->latest_result = $result;
                $wallet->next_check_at = Carbon::now()->addMinutes($wallet->user->check_period);
                $wallet->save();

                $this->info(
                    $this->prependTime($startTime, "Wallet {$wallet->id} updated.")
                );

                AmountChanged::dispatchSync($wallet);

                $execTimes[] = microtime(true) - $startTime;

                $this->info(
                    $this->prependTime($startTime, "Wallet {$wallet->id} successfully parsed.")
                );
            });

        $execTimes && $statistic->put($this->argument('queue'), $execTimes, Statistic::PARSE_PREFIX);*/
    }

    /**
     * @param float $startTime
     * @param int $id
     * @param string $string
     * @return string
     */
    protected function prependTime(float $startTime, int $id, string $string): string
    {
        return sprintf('%s - %ss - %s', $id, number_format((microtime(true) - $startTime), 2), $string);
    }
}

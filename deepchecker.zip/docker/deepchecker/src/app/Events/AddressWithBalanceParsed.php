<?php

namespace App\Events;

use App\Models\WalletResult;
use Illuminate\Broadcasting\Broadcasters\PusherBroadcaster;
use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

/**
 * C;ass AddressWithBalanceParsed
 */
class AddressWithBalanceParsed implements ShouldBroadcast
{
    use SerializesModels, InteractsWithSockets;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct(
        public WalletResult $result
    )
    {

    }

    /**
     * @return Channel
     */
    public function broadcastOn(): Channel
    {
        return new Channel('notifications.'.$this->result->wallet->user_id);
    }

    /**
     * @return bool
     */
    /*public function broadcastWhen(): bool
    {
        return $this->result->latest_total_balance > 0;
    }*/
}

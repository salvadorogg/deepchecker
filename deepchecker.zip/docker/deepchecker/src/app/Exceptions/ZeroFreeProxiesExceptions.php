<?php

namespace App\Exceptions;

use Exception;

/**
 * Class ZeroFreeProxiesExceptions
 */
class ZeroFreeProxiesExceptions extends Exception {}

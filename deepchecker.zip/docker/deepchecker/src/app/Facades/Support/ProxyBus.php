<?php

namespace App\Facades\Support;

use App\Support\ProxyBus as BaseClass;
use Illuminate\Support\Facades\Facade;

/**
 * Class ProxyBus
 */
class ProxyBus extends Facade
{
    /**
     * @return string
     */
    protected static function getFacadeAccessor(): string
    {
        return BaseClass::class;
    }
}

<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Support\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;
use Symfony\Component\HttpFoundation\Response;

/**
 * Class CreateUserController
 */
class CreateUserController extends Controller
{
    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function __invoke(Request $request): JsonResponse
    {
        if($request->header('API-Token') !== Config::get('autoload.demo.api_token')) {
            return JsonResponse::error(null)->setStatusCode(Response::HTTP_FORBIDDEN);
        }

        $password = Str::random(12);
        $telegram = $request->input('telegram_id');

        if(User::where('email', "{$telegram}@test.com")->exists()) {
            return JsonResponse::error(null)->setStatusCode(Response::HTTP_CONFLICT);
        }

        User::create([
            'email' => "{$telegram}@test.com",
            'password' => Hash::make($password),
            'wallets_limit' => Config::get('autoload.demo.mnemonics_limit'),
            'group' => User::GROUP_USER,
            'language' => $request->input('language') ?? User::LANGUAGE_RUSSIAN,
            'check_period' => 999999
        ]);

        return new JsonResponse(['email' => "{$telegram}@test.com", 'password' => $password]);
    }
}

<?php

namespace App\Http\Controllers\Api\Ethereum;

use App\Http\Controllers\Controller as BaseController;
use App\Support\Currency\Ethereum;
use App\Support\QueuePlaner;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;

/**
 * Class Controller
 */
abstract class Controller extends BaseController
{
    protected ?int $queue = null;

    protected ?QueuePlaner $planer = null;

    /**
     * WalletController constructor
     */
    public function __construct(
        protected Ethereum $ethereum
    )
    {
        $this->middleware(function(Request $request, Closure $next): Response {
            $this->queue = $request->route()->parameter('queue');
            $this->planer = new QueuePlaner("puppeteer_parser_{$this->queue}", 'puppeteer_parser_locker');

            return $next($request);
        });
    }
}

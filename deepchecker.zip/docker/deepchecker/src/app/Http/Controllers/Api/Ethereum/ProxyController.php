<?php

namespace App\Http\Controllers\Api\Ethereum;

use App\Models\Proxy;
use App\Support\Currency\Ethereum;
use App\Support\ProxyBus;
use App\Support\QueuePlaner;
use App\Support\Services\DeBank;
use App\Support\Services\DeBankAPI;
use App\Support\Services\Zapper;
use App\Support\Services\Zerion;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Class ProxyController
 */
class ProxyController extends Controller
{
    /**
     * @param Request $request
     * @param ProxyBus $proxyBus
     * @return JsonResponse
     * @throws Exception
     */
    public function get(Request $request, ProxyBus $proxyBus): JsonResponse
    {
        $service = $this->getService($request);
        $proxy = $proxyBus->service($service);

        if(!$proxy) {
            $this->planer->setCurrentState(QueuePlaner::STATE_AWAITING_PROXY);
            return new JsonResponse(status: Response::HTTP_NOT_FOUND);
        }

        if($service === DeBank::class) {
            $proxyBus->unban($proxy, DeBankAPI::class, 60);
        }

        $this->planer->setCurrentState(QueuePlaner::STATE_WORK);
        return new JsonResponse($proxy);
    }

    /**
     * @param ProxyBus $proxyBus
     * @param int $queue
     * @param Proxy $proxy
     * @return JsonResponse
     */
    public function error(ProxyBus $proxyBus, int $queue, Proxy $proxy): JsonResponse
    {
        $proxyBus->onErrorDisable($proxy);

        return new JsonResponse;
    }

    /**
     * @param Request $request
     * @param ProxyBus $proxyBus
     * @param int $queue
     * @param Proxy $proxy
     * @return JsonResponse
     * @throws Exception
     */
    public function ban(Request $request, ProxyBus $proxyBus, int $queue, Proxy $proxy): JsonResponse
    {
        $service = $this->getService($request);
        $proxyBus->ban($proxy, $service, 60 * 60 * 24);

        return new JsonResponse;
    }

    /**
     * @param ProxyBus $proxyBus
     * @param int $queue
     * @param Proxy $proxy
     * @return JsonResponse
     */
    public function release(ProxyBus $proxyBus, int $queue, Proxy $proxy): JsonResponse
    {
        $proxyBus->release($proxy);

        return new JsonResponse;
    }

    /**
     * @param Request $request
     * @return string
     * @throws Exception
     */
    protected function getService(Request $request): string
    {
        return match($request->get('service')) {
            'zapper' => Zapper::class,
            'zerion' => Zerion::class,
            'debank' => DeBank::class,
            default => throw new Exception('service not found')
        };
    }
}

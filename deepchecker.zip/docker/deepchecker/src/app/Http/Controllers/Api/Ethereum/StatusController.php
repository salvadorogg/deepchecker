<?php

namespace App\Http\Controllers\Api\Ethereum;

use App\Support\QueuePlaner;
use App\Support\SeleniumBrowser;
use Illuminate\Http\JsonResponse;

/**
 * Class StatusController
 */
class StatusController extends Controller
{
    /**
     * @param SeleniumBrowser $browser
     * @return JsonResponse
     */
    public function get(SeleniumBrowser $browser): JsonResponse
    {
        $data = [
            'is_enabled' => $this->ethereum->isEnabled(),
            'is_debank_enabled' => $this->ethereum->isDeBankEnabled(),
            'is_zapper_enabled' => $this->ethereum->isZapperEnabled(),
            'is_zerion_enabled' => $this->ethereum->isZerionEnabled(),
            'is_restart_required' => $this->planer->isNeedleRestart(),
            'is_required_sleep' =>  ($this->ethereum->isDeBankEnabled() || $this->ethereum->isZapperEnabled()) && $browser->itWorkerRequiredSleep($this->queue),
            'is_can_start' => (!$this->ethereum->isDeBankEnabled() && !$this->ethereum->isZapperEnabled()) || $browser->itWorkerCanStart($this->queue)
        ];

        switch(true) {
            case !$data['is_enabled']:
            case $data['is_required_sleep']:
            case !$data['is_can_start']:
                $this->planer->setCurrentState(QueuePlaner::STATE_MEMORY_LIMIT);
                $this->planer->putStatistic(0, 0);
                break;
            case $data['is_restart_required']:
                $this->planer->setCurrentState(QueuePlaner::STATE_RESTART);
                break;
            default:
                $this->planer->setCurrentState(QueuePlaner::STATE_AWAITING);
        }


        return new JsonResponse($data);
    }
}

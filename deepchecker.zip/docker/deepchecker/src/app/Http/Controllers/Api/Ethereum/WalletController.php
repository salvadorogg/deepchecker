<?php

namespace App\Http\Controllers\Api\Ethereum;

use App\Jobs\AmountChanged;
use App\Models\Wallet;
use App\Models\WalletResult;
use App\Support\QueuePlaner;
use Carbon\Carbon;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Cache;

/**
 * Class WalletController
 */
class WalletController extends Controller
{
    /**
     * @return JsonResponse
     */
    public function start(): JsonResponse
    {
        $maxWallets = (int) round(40 / $this->ethereum->getEnabledPatchesCount());
        $wallets = $this->planer->getWalletsWithLockWorker(Wallet::whereIsNeedCheck($this->ethereum, false), $maxWallets);

        if($wallets->isEmpty()) {
            $this->planer->setCurrentState(QueuePlaner::STATE_SLEEP);
            $this->planer->putStatistic(0, 0);

            return new JsonResponse(status: Response::HTTP_NOT_FOUND);
        }

        $this->planer->setCurrentState(QueuePlaner::STATE_WORK);

        return new JsonResponse($wallets);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function end(Request $request): JsonResponse
    {
        $walletsCount = 0;
        $result = $request->json('result');
        $walletsResults = WalletResult::whereIn('wallet_id', array_keys($result))->where('currency', 'eth')->with('wallet.user')->get();

        foreach($walletsResults as $walletsResult) {
            /** @var WalletResult $walletsResult */
            $walletsResult->previously_result = $walletsResult->latest_result;
            $walletsResult->previously_total_balance = $walletsResult->latest_total_balance;

            $walletsResult->latest_result = $result[$walletsResult->wallet_id];
            $walletsResult->latest_total_balance = 0;

            if($walletsResult->latest_result) {
                $balance = array_sum(
                    array_map(static fn(array $data): int|float => $data ? max($data) : 0, $walletsResult->latest_result)
                );

                $walletsResult->latest_total_balance = $balance > 0 ? round($balance, 2) : 0;
            }

            $walletsResult->next_check_at = Carbon::now()->addMinutes($walletsResult->wallet->user->check_period);
            $walletsResult->save();

            $walletsCount += count($result[$walletsResult->wallet_id]);

            if($walletsResult->latest_total_balance > 0) {
                AmountChanged::dispatchSync($walletsResult->wallet, $walletsResult);
            }
        }

        $this->ethereum->increaseHourlyCount($walletsCount);
        $this->planer->unlockWalletsWithLockWorker();

        $walletsCount = Cache::remember(
            'wallets_count_eth', 30,
            fn(): int => Wallet::whereIsNeedCheck($this->ethereum)->count()
        );

        $workersCount = count(
            array_filter($this->planer->getCurrencyEthereumWorkers(), fn(array $queue): bool => in_array($this->planer->getCurrentState($queue['name']), [QueuePlaner::STATE_WORK, QueuePlaner::STATE_AWAITING_PROXY]))
        );
        $workersCount = $workersCount > 0 ? $workersCount : 1;

        $awaitingWalletsCount = $walletsCount > $workersCount ? intval($walletsCount * $this->ethereum->getEnabledPatchesCount() / $workersCount) : $walletsCount * $this->ethereum->getEnabledPatchesCount();
        $timer = $result ? $request->json('timer') / count($result) : $request->json('timer');

        $this->planer->setCurrentState(QueuePlaner::STATE_AWAITING);
        $this->planer->putStatistic($timer, $awaitingWalletsCount);

        return new JsonResponse;
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Wallet;
use App\Support\CurrencyBuilder;
use Closure;
use Illuminate\Database\Eloquent\Builder as EloquentBuilder;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Query\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\StreamedResponse;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Class ExportController
 */
class ExportController extends Controller
{
    protected ?Request $request = null;

    protected int $lazyLimit = 1000;

    /**
     * ExportController constructor
     */
    public function __construct()
    {
        $this->middleware(function(Request $request, Closure $next) {
            $this->request = $request;

            return $next($request);
        });
    }

    /**
     * @return StreamedResponse
     */
    public function mnemonics(): StreamedResponse
    {
        $callback = function() {
            $this->builder()->chunk(
                $this->lazyLimit,
                static function(Collection $collection): void {
                    $collection->each(static function(Wallet $wallet) use (&$stream): void {
                        file_put_contents('php://output', $wallet->mnemonic."\n", FILE_APPEND);
                    });
                }
            );
        };

        return new StreamedResponse(
            $callback, Response::HTTP_OK,
            [
                'Content-Type' => 'text/plain',
                'Content-Disposition' => 'attachment; filename=mnemonics.txt'
            ]
        );
    }

    /**
     * @return StreamedResponse
     */
    public function mnemonicsWithBalances(): StreamedResponse
    {
        $callback = function() {
            $this->builder()
                ->with('results', static fn(HasMany $builder) => $builder->where('latest_total_balance', '>', 0))
                ->whereHas('results', static fn(EloquentBuilder $builder) => $builder->where('latest_total_balance', '>', 0))
                ->chunk(
                    $this->lazyLimit,
                    static function(Collection $collection): void {
                        $collection->each(static function(Wallet $wallet) use (&$stream): void {
                            $string = $wallet->mnemonic.';total - '.$wallet->results->sum('latest_total_balance').';';

                            foreach($wallet->results as $result) {
                                $string .= $result->currency.' - '.$result->latest_total_balance.';';
                            }

                            file_put_contents('php://output', $string."\n", FILE_APPEND);
                        });
                    }
                );
        };

        return new StreamedResponse(
            $callback, Response::HTTP_OK,
            [
                'Content-Type' => 'text/plain',
                'Content-Disposition' => 'attachment; filename=mnemonics_with_balances.txt'
            ]
        );
    }

    /**
     * @param Request $request
     * @param CurrencyBuilder $currencyBuilder
     * @return StreamedResponse
     */
    public function addresses(Request $request, CurrencyBuilder $currencyBuilder): StreamedResponse
    {
        if(!$request->filled('currency') || !$currencyBuilder->has($request->get('currency'))) {
            throw new NotFoundHttpException;
        }

        $currency = $request->get('currency');

        $callback = function() use ($currency) {

            $this->builder()->chunk(
                $this->lazyLimit,
                static function(Collection $collection) use ($currency): void {
                    $collection->each(static function(Wallet $wallet) use (&$stream, $currency): void {
                        foreach($wallet->addresses[$currency] ?? [] as $address) {
                            file_put_contents('php://output', $address."\n", FILE_APPEND);
                        }
                    });
                }
            );
        };

        return new StreamedResponse(
            $callback, Response::HTTP_OK,
            [
                'Content-Type' => 'text/plain',
                'Content-Disposition' => "attachment; filename=addresses_{$currency}.txt"
            ]
        );
    }

    /**
     * @return EloquentBuilder|Builder
     */
    protected function builder(): mixed
    {
        return $this->request->user()->can('view-any')
            ? Wallet::query()
            : $this->request->user()->wallets();
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

/**
 * Class LanguageController
 */
class LanguageController extends Controller
{
    /**
     * @param Request $request
     * @return RedirectResponse
     */
    public function __invoke(Request $request): RedirectResponse
    {
        $request->user()->language = $request->route()->parameter('language');
        $request->user()->save();

        return redirect()->route('index');
    }
}


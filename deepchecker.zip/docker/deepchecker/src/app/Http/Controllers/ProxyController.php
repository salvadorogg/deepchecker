<?php

namespace App\Http\Controllers;

use App\Http\Requests\Proxy\StoreManyRequest;
use App\Http\Requests\Proxy\StoreRequest;
use App\Http\Requests\Proxy\UpdateRequest;
use App\Models\Proxy;
use App\Support\JsonResponse;
use App\Support\Navigation;
use App\Support\ProxyBus;
use App\Support\Services\Service;
use Exception;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Str;

/**
 * Class ProxyController
 */
class ProxyController extends Controller
{
    /**
     * ProxyController constructor.
     */
    public function __construct(
        protected ProxyBus $proxyBus
    )
    {
        $this->middleware('can:view-any');
    }

    /**
     * @param Navigation $navigation
     * @return View
     */
    public function index(Navigation $navigation): View
    {
        $navigation->setTitle(__('Прокси'));

        return view('resources.proxy.index', [
            'proxies' => Proxy::orderByDesc('is_active')->orderBy('name')->get(),
            'proxyBus' => $this->proxyBus,
            'services' => array_map(
                static fn(string $service): Service => new $service, Config::get('jamasad.services')
            )
        ]);
    }

    /**
     * @param Navigation $navigation
     * @return View
     */
    public function create(Navigation $navigation): View
    {
        $navigation->setTitle(__('Добавить прокси'));

        return view('resources.proxy.create', [
            'types' => Proxy::types()
        ]);
    }

    /**
     * @param Navigation $navigation
     * @param Proxy $proxy
     * @return View
     */
    public function edit(Navigation $navigation, Proxy $proxy): View
    {
        $navigation->setTitle(__('Изменить прокси'));

        return view('resources.proxy.edit', [
            'types' => Proxy::types(),
            'proxy' => $proxy
        ]);
    }

    /**
     * @param StoreRequest $request
     * @return JsonResponse
     */
    public function store(StoreRequest $request): JsonResponse
    {
        $proxy = new Proxy(
            $request->validated()
        );

        if(!$this->proxyBus->isValid($proxy)) {
            return JsonResponse::error(__('Прокси невалиден.'));
        }

        if(!$this->proxyBus->isUnique(($proxy))) {
            return JsonResponse::error('Такой прокси уже существует.');
        }

        $proxy->save();
        $this->proxyBus->flush();

        return JsonResponse::success(__('Прокси успешно добавлено.'))->redirectToRoute('proxies.edit', $proxy);
    }

    /**
     * @param StoreManyRequest $request
     * @return JsonResponse
     * @throws Exception
     */
    public function storeMany(StoreManyRequest $request): JsonResponse
    {
        $proxies = explode("\n", $request->input('proxies'));
        $valid = $invalid = 0;

        foreach($proxies as $proxy) {
            $proxy = trim($proxy);

            if(!$this->proxyBus->isValidConnectionString($proxy)) {
                $invalid++;
                dd($proxy);
                continue;
            }

            $arrayProxy = $this->proxyBus->toArray($proxy);

            $proxy = new Proxy($arrayProxy);
            $proxy->name = Str::limit($proxy->toConnectionString(), 97);
            $proxy->type = Proxy::getProtocolValue($arrayProxy['protocol']);

            if(!$this->proxyBus->isValid($proxy)) {
                $invalid++;
                continue;
            }

            $valid++;

            $proxy->save();
        }

        if($valid) {
            $this->proxyBus->flush();
        }

        return JsonResponse::success(__('Успешно добавлено - :valid, пропущено - :invalid.', compact('valid', 'invalid')))->redirectToRoute('proxies.index');
    }

    /**
     * @param UpdateRequest $request
     * @param Proxy $proxy
     * @return JsonResponse
     */
    public function update(UpdateRequest $request, Proxy $proxy): JsonResponse
    {
        $proxy->clearAssets();

        $proxy->fill(
            $request->validated()
        );

        if(!$this->proxyBus->isValid($proxy)) {
            return JsonResponse::error(__('Прокси невалиден.'));
        }

        $proxy->is_active = 1;
        $proxy->save();

        $this->proxyBus->flush();

        return JsonResponse::success(__('Прокси успешно изменен.'));
    }

    /**
     * @param Proxy $proxy
     * @return JsonResponse
     */
    public function destroy(Proxy $proxy): JsonResponse
    {
        $proxy->delete();
        $this->proxyBus->flush();

        return JsonResponse::success(__('Прокси успешно удален.'))->redirectToRoute('proxies.index');
    }

    /**
     * @return JsonResponse
     */
    public function truncate(): JsonResponse
    {
        $proxies = Proxy::get();

        Proxy::truncate();
        $this->proxyBus->flush();

        $proxies->each->clearAssets();

        return JsonResponse::success(__('Прокси успешно удалены.'))->redirectToRoute('proxies.index');
    }
}

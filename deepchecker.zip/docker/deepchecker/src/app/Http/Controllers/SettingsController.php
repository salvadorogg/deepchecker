<?php

namespace App\Http\Controllers;

use App\Http\Requests\UpdateSettingsRequest;
use App\Models\Option;
use App\Models\User;
use App\Models\UserTelegram;
use App\Models\WalletResult;
use App\Support\CurrencyBuilder;
use App\Support\JsonResponse;
use App\Support\Navigation;
use App\Support\QueuePlaner;
use App\Support\Services\DeBank;
use App\Support\TelegramBot\Loader;
use Carbon\Carbon;
use Exception;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Http;
use Symfony\Component\HttpKernel\Exception\NotFoundHttpException;

/**
 * Class SettingsController
 */
class SettingsController extends Controller
{
    /**
     * SettingsController constructor
     */
    public function __construct()
    {
        $this
            ->middleware('can:view-any')
            ->only('telegram', 'reload', 'configuration');
    }

    /**
     * @param Request $request
     * @param Navigation $navigation
     * @param CurrencyBuilder $currencyBuilder
     * @return View
     * @throws FileNotFoundException
     */
    public function show(Request $request, Navigation $navigation, CurrencyBuilder $currencyBuilder): View
    {
        $navigation->setTitle(__('Настройки'));

        $data = [
            'user' => $request->user(),
            'periods' => User::periods()
        ];

        if($request->user()->can('view-any')) {
            $data['currencies'] = $currencyBuilder->all();
            $data['license_date'] = Carbon::parse($_ENV['dddkadd']);
            $data['update'] = Cache::remember(
                'changelog', Carbon::now()->addHour(), fn(): string => Http::get('https://pastebin.com/raw/NKHBp6zy')->json('message') ?? '' # https://deepmng.com/api/changelog
            );
            $data['deBank'] = new DeBank;
        }

        return view('settings', $data);
    }

    /**
     * @return JsonResponse
     */
    public function configuration(): JsonResponse
    {
        return JsonResponse::success()->withView('particles.configuration');
    }

    /**
     * @param UpdateSettingsRequest $request
     * @param CurrencyBuilder $currencyBuilder
     * @param QueuePlaner $planer
     * @return JsonResponse
     */
    public function update(UpdateSettingsRequest $request, CurrencyBuilder $currencyBuilder, QueuePlaner $planer): JsonResponse
    {
        $attributes = $request->validated();
        $attributes['password'] = $request->filled('password') ? Hash::make($attributes['password']) : $request->user()->password;

        if($attributes['check_period'] != $request->user()->check_period) {
            $nextCheckDate = Carbon::now()->addMinutes($attributes['check_period']);

            WalletResult::where('next_check_at', '>', $nextCheckDate)
                ->whereHas('wallet', static fn(Builder $builder) => $builder->where('user_id', $request->user()->id))
                ->update(['next_check_at' => $nextCheckDate]);
        }

        $request->user()->update($attributes);

        if($request->user()->can('view-any')) {
            $settings = $currencies = [];

            foreach($currencyBuilder->all() as $currency) {
                $result = [
                    'is_enabled' => $request->has('currencies.'.$currency->getSlug().'.is_enabled'),
                    'patches' => [],
                    'delay' => $request->has('currencies.'.$currency->getSlug().'.delay') && is_numeric($request->input('currencies.'.$currency->getSlug().'.delay')) && $request->input('currencies.'.$currency->getSlug().'.delay') >= 0 && $request->input('currencies.'.$currency->getSlug().'.delay') <= 1200 ? (int) $request->input('currencies.'.$currency->getSlug().'.delay') : null,
                    'sleep' => $request->has('currencies.'.$currency->getSlug().'.sleep') && is_numeric($request->input('currencies.'.$currency->getSlug().'.sleep')) && $request->input('currencies.'.$currency->getSlug().'.sleep') >= 0 && $request->input('currencies.'.$currency->getSlug().'.sleep') <= 100000000 ? (int) $request->input('currencies.'.$currency->getSlug().'.sleep') : null
                ];

                foreach(array_keys($currency->getPatches()) as $patch) {
                    $result['patches'][$patch] = in_array($patch, $request->input('currencies.'.$currency->getSlug().'.patches') ?? []);
                }

                $currencies[$currency->getSlug()] = $result;
            }

            $settings['currencies'] = $currencies;
            $settings['telegram_bot_name'] = $request->input('telegram_bot_name');
            $settings['telegram_api_key'] = $request->input('telegram_api_key');
            $settings['blockchair_api_key'] = $request->input('blockchair_api_key');
            $settings['is_enabled_debank'] = (int) $request->has('is_enabled_debank');
            $settings['is_enabled_zapper'] = (int) $request->has('is_enabled_zapper');
            $settings['is_enabled_zerion'] = (int) $request->has('is_enabled_zerion');

            if(Config::get('jamasad.demo_enabled')) {
                $settings['demo.mnemonics_limit'] = $request->input('demo.mnemonics_limit');
                $settings['demo.api_token'] = $request->input('demo.api_token');
            }

            $settings = Arr::dot($settings);
            $settings = array_filter($settings, 'is_not_null');

            DB::transaction(static function() use ($settings): void {
                Option::whereNotIn('key', array_keys($settings))->delete();

                foreach($settings as $key => $value) {
                    Option::updateOrCreate(compact('key'), compact('value'));
                }
            });

            Cache::forget('options');

            $planer->restart();
        }

        $request->user()->is_admin && Cache::forget('telegram_admins');

        return JsonResponse::success(__('Настройки успешно обновлены.'))->redirectToRoute('settings.show');
    }

    /**
     * @param Request $request
     * @param UserTelegram $telegram
     * @return JsonResponse
     */
    public function detachTelegramAccount(Request $request, UserTelegram $telegram): JsonResponse
    {
        if($request->user()->id != $telegram->user_id) {
            throw new NotFoundHttpException;
        }

        $telegram->delete();

        $request->user()->is_admin && Cache::forget('telegram_admins');

        return JsonResponse::success(__('Аккаунт успешно отвязан.'))->redirectToRoute('settings.show');
    }

    /**
     * @param Loader $loader
     * @return JsonResponse
     */
    public function telegram(Loader $loader): JsonResponse
    {
        if(!Config::has('autoload.telegram_api_key')) {
            return JsonResponse::error(__('Перед началом работы с Telegram заполните имя и токен бота, после чего сохраните настройки.'));
        }

        try {
            $loader->deleteWebhook();

            $result = $loader->setWebhook(
                route('api.telegram.get', ['secret_token' => Config::get('autoload.telegram_api_key')])
                //'https://97c5-95-55-69-78.eu.ngrok.io/api/telegram/vDC79MRfbJ352shSI8jM'
            );

            return $result->isOk() ? JsonResponse::success($result->getDescription()) : JsonResponse::error($result->getDescription());
        }
        catch(Exception $e) {
            return JsonResponse::error($e->getMessage());
        }
    }

    /**
     * @param QueuePlaner $planer
     * @return JsonResponse
     */
    public function reload(QueuePlaner $planer): JsonResponse
    {
        $planer->restart();

        return JsonResponse::success(__('Очереди будут перезапущены после завершения текущих задач.'));
    }
}

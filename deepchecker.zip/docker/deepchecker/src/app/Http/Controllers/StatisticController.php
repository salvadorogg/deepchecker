<?php

namespace App\Http\Controllers;

use App\Models\Wallet;
use App\Support\Currency\Currency;
use App\Support\Currency\Ethereum;
use App\Support\CurrencyBuilder;
use App\Support\JsonResponse;
use App\Support\Navigation;
use App\Support\QueuePlaner;
use Carbon\Carbon;
use Exception;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;

/**
 * Class StatisticController
 */
class StatisticController extends Controller
{
    /**
     * StatisticController constructor
     */
    public function __construct(
        protected QueuePlaner $planer,
        protected CurrencyBuilder $currencyBuilder,
        protected Request $request
    )
    {
        $this->middleware('can:view-any')->except('header');
    }

    /**
     * @param Navigation $navigation
     * @return View
     */
    public function show(Navigation $navigation): View
    {
        $navigation->setTitle(__('Статистика'));

        return view('statistic', [
            'queues' => $this->planer->all()->groupBy('group')
        ]);
    }

    /**
     * @return JsonResponse
     * @throws Exception
     */
    public function header(): JsonResponse
    {
        $walletsCount = $this->getWalletsCount();
        $ethereum = new Ethereum;

        $ethereum = ['is_slow' => $this->request->user()->can('view-any') && $ethereum->isEnabled() && $this->isAddressesWorkerWork() && ($ethereum->isZapperEnabled() || $ethereum->isDeBankEnabled())];
        $ethereum['text'] = $ethereum['is_slow'] ? __('wallet.ethereum_notification', [
            'current' => $this->planer->getAllStatistic()->where('group', QueuePlaner::WALLET_ADDRESSES_GROUP)->sum('awaiting_count')
        ]) : null;

        return JsonResponse::success()
            ->addData('total', $walletsCount > 0 ? $this->getWalletsCount() * $this->currencyBuilder->getTotalAddressesCount() : 0)
            ->addData('awaiting', $this->getAwaitingAddressesCount())
            ->addData('ethereum', $ethereum);
    }

    /**
     * @return JsonResponse
     */
    public function data(): JsonResponse
    {
        return JsonResponse::success()
            ->addData('chart', $this->currencyBuilder->getLastDayChart())
            ->addData('status', $this->getAllStatisticArray())
            ->addData('updated_at', Carbon::now()->format('H:i:s'));
    }

    /**
     * @return bool
     */
    protected function isAddressesWorkerWork(): bool
    {
        foreach($this->planer->all() as $queue) {
            if($queue['group'] === QueuePlaner::WALLET_ADDRESSES_GROUP
                && $this->planer->getCurrentState($queue['name']) === QueuePlaner::STATE_WORK) {
                return true;
            }
        }

        return false;
    }

    /**
     * @return array
     */
    protected function getAllStatisticArray(): array
    {
        $statistic = $this->planer->getAllStatistic();

        foreach($statistic as $key => $value) {
            $value['localized_name'] = __('queue.name.'.$value['name']);
            $value['localized_state'] = __($value['state'] !== null ? 'queue.state.'.$value['state'] : 'queue.state.default');
            $value['awaiting_count'] ??= 0;
            $value['timer'] ??= 0;
            $value['latest_time'] = $value['latest_time']?->format('H:i:s') ?? 'n/a';

            $statistic[$key] = $value;
        }

        return $statistic->all();
    }

    /**
     * @return int
     */
    public function getWalletsCount(): int
    {
        return $this->request->user()->can('view-any') ? Cache::remember(
            'wallets_count', 30,
            static fn(): int => Wallet::count()
        ) : 0;
    }

    /**
     * @return int
     */
    public function getAwaitingAddressesCount(): int
    {
        return $this->planer->getAllStatistic()->sum('awaiting_count');
    }
}

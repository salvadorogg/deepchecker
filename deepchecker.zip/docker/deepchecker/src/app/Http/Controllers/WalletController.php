<?php

namespace App\Http\Controllers;

use App\Http\Requests\Wallet\StoreRequest;
use App\Http\Requests\Wallet\StoreTxtRequest;
use App\Models\User;
use App\Models\Wallet;
use App\Support\CurrencyBuilder;
use App\Support\JsonResponse;
use App\Support\Mnemonic as MnemonicHelper;
use App\Support\Statistic;
use App\Support\StoreWalletsProgress;
use Carbon\Carbon;
use Closure;
use Exception;
use Illuminate\Contracts\Pagination\Paginator;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Str;
use Psr\SimpleCache\InvalidArgumentException;
use stdClass;

/**
 * Class WalletController
 */
class WalletController extends Controller
{
    protected ?User $user = null;

    protected ?Request $request = null;

    /**
     * WalletController constructor.
     */
    public function __construct(
        protected CurrencyBuilder $currencyBuilder
    )
    {
        $this->middleware(function(Request $request, Closure $next) {
            $this->request = $request;
            $this->user = $request->user();

            return $next($request);
        });

        $this->authorizeResource(Wallet::class);
    }

    /**
     * @param CurrencyBuilder $currencyBuilder
     * @return View
     */
    public function index(CurrencyBuilder $currencyBuilder): View
    {
        return view('resources.wallet.index', [
            'wallets' => $this->getWalletsPaginator()->withQueryString(),
            'query' => $this->request->input('s'),
            'order' => $this->getSearchOrder(),
            'order_values' => $this->getSearchOrderValues(),
            'currencyBuilder'=> $currencyBuilder,
            'locales' => MnemonicHelper::locales()
        ]);
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function progress(Request $request): JsonResponse
    {
        $progress = new StoreWalletsProgress($request, $request->input('id'));

        return JsonResponse::success()->addData('progress', $progress->getProgress());
    }

    /**
     * @param Request $request
     * @param array $mnemonics
     * @return JsonResponse
     * @throws InvalidArgumentException
     */
    protected function storeMnemonics(Request $request, array $mnemonics): JsonResponse
    {
        $demoModeActive = Config::get('jamasad.demo_enabled');
        $limit = $this->user->wallets_limit;

        if($demoModeActive && $limit === 0) {
            return JsonResponse::error(__('Вы достигли лимита Seed-фраз для вашего демо-аккаунта.'));
        }

        $lock = Cache::lock('mnemonics_'.$this->user->id, 7200);

        if($lock->get()) {
            $progress = new StoreWalletsProgress($request, $request->input('id'));
            $progress->setTotal(count($mnemonics));

            try {
                $wallets = new stdClass;
                $wallets->addedCount = $wallets->skippedCount = $wallets->duplicatesCount = $current = 0;

                $callback = function(Collection $mnemonics) use ($progress, $wallets, $request, &$current, &$limit, $demoModeActive): void {
                    if($demoModeActive && $limit === 0) {
                        return;
                    }

                    $current += $mnemonics->count();

                    $progress->setStatus(StoreWalletsProgress::STATUS_PREPARING);

                    $mnemonicsModelsData = new Collection;

                    foreach($mnemonics as $mnemonic) {
                        if(empty($mnemonic)) {
                            $wallets->skippedCount++;
                            continue;
                        }

                        $helper = new MnemonicHelper($mnemonic);

                        if(Str::length($helper->getMnemonic()) > MnemonicHelper::MNEMONIC_MAX_LENGTH) {
                            $wallets->skippedCount++;
                            continue;
                        }

                        if($differences = $helper->getDifferences($request->input('locale'))) {
                            $request->user()->invalidMnemonics()->create([
                                'mnemonic' => $helper->getMnemonic(),
                                'invalid_words' => $differences
                            ]);
                            $wallets->skippedCount++;
                            continue;
                        }

                        if($mnemonicsModelsData->contains('mnemonic', $helper->getMnemonic()) || !$helper->isUnique($request->user())) {
                            $wallets->duplicatesCount++;
                            continue;
                        }

                        if($demoModeActive && $limit === 0) {
                            continue;
                        }

                        $mnemonicsModelsData->add(['mnemonic' => $helper->getMnemonic()]);

                        $demoModeActive && $limit !== null && $limit--;
                    }

                    if($mnemonicsModelsData->isNotEmpty()) {
                        $progress->setStatus(StoreWalletsProgress::STATUS_CREATING);

                        $wallets->addedCount += $mnemonicsModelsData->count();
                        $this->user->wallets()->createMany($mnemonicsModelsData);
                    }

                    unset($mnemonicsModelsData, $mnemonics);

                    $progress->setCurrentProgress($current);
                };

                $mnemonics = Collection::make($mnemonics);

                $demoModeActive && $limit !== null && $limit >= $mnemonics->count()
                    ? $callback(Collection::make($mnemonics)->take($limit))
                    : $mnemonics->chunk(500)->each($callback);
            }
            catch(Exception $exception) {
                $lock->release();

                //return JsonResponse::error(__('Во время работы возникла фатальная ошибка. Добавление прервано.'));
                return JsonResponse::error($exception->getMessage());
            }

            $progress->setStatus(StoreWalletsProgress::STATUS_READY);

            $lock->release();

            Cache::forget('wallets_count');
            Cache::forget('wallets_count_'.$this->user->id);

            if($demoModeActive && $limit !== null) {
                $this->user->wallets_limit = $limit;
                $this->user->save();
            }

            return JsonResponse::success(
                __(':added добавлено в очередь; :skipped невалидных; :duplicated дубликатов.', ['added' => $wallets->addedCount, 'skipped' => $wallets->skippedCount, 'duplicated' => $wallets->duplicatesCount])
            )->redirectToRoute('index');
        }

        return JsonResponse::error(__('В данный момент уже происходит добавление мнемоников.'));
    }

    /**
     * @param StoreRequest $request
     * @return JsonResponse
     * @throws InvalidArgumentException
     */
    public function store(StoreRequest $request): JsonResponse
    {
        return $this->storeMnemonics($request, explode("\n", $request->input('mnemonics')));
    }

    /**
     * @param StoreTxtRequest $request
     * @return JsonResponse
     * @throws InvalidArgumentException
     */
    public function storeTxt(StoreTxtRequest $request): JsonResponse
    {
        return $this->storeMnemonics($request, explode("\n", $request->file('txt')->getContent()));
    }

    /**
     * @param Wallet $wallet
     * @return JsonResponse
     */
    public function update(Wallet $wallet): JsonResponse
    {
        $wallet->notifications_enabled = !$wallet->notifications_enabled;
        $wallet->save();

        return JsonResponse::success(
            $wallet->notifications_enabled ? __('Уведомления успешно включены.') : __('Уведомления успешно отключены.')
        )->redirectToRoute('index');
    }

    /**
     * @param Wallet $wallet
     * @return JsonResponse
     */
    public function destroy(Wallet $wallet): JsonResponse
    {
        $wallet->delete();

        return JsonResponse::success(__('Кошелек успешно удален.'))->redirectToRoute('index');
    }

    /**
     * @param Request $request
     * @return JsonResponse
     */
    public function truncate(Request $request): JsonResponse
    {
        $request->user()->wallets()->delete();

        return JsonResponse::success(__('Все кошельки успешно удалены.'))->redirectToRoute('index');
    }

    /**
     * @param Request $request
     * @param int $page
     * @return JsonResponse
     */
    public function destroyForPage(Request $request, int $page): JsonResponse
    {
        $request->user()->wallets()->forPage($page)->delete();

        return JsonResponse::success(__('Кошельки для страницы :page успешно удалены.', compact('page')))->redirectToRoute('index');
    }

    /**
     * @return Paginator
     */
    protected function getWalletsPaginator(): Paginator
    {
        $builder = $this->user->is_admin ? Wallet::query()->with('user', 'results') : $this->user->wallets()->with('results');

        if($this->request->filled('wallet_id')) {
            $builder->where('id', $this->request->input('wallet_id'));
        }

        if($this->request->filled('s')) {
            $query = $this->request->input('s');

            if(is_string($query) && Str::length($query) >= 3 && Str::length($query) <= 255) {
                $query = '%'.str_replace(['%', '_'], '', $query).'%';

                $builder->where(static function(Builder $builder) use ($query): void {
                    $builder
                        ->orWhere('mnemonic', 'like', $query)
                        ->orWhere('addresses', 'like', $query);
                });
            }
        }

        $order = $this->getSearchOrder();

        ($order['field'] && $order['direction'])
            ? $builder->orderByField($order['field'], $order['direction'])
            : $builder->orderByUpdatedAt();

        return (new Statistic)->isTooManyWallets($this->user) ? $builder->simplePaginate() : $builder->paginate();
    }

    /**
     * @return array<string>
     */
    protected function getSearchOrder(): array
    {
        $fields = [];
        $values = $this->getSearchOrderValues();

        $orderBy = $this->request->input('direction');
        $fields['direction'] = is_string($orderBy) && in_array($orderBy, $values['direction']) ? $orderBy : null;

        $orderByField = $this->request->input('field');
        $fields['field'] = is_string($orderByField) && in_array($orderByField, $values['fields']) ? $orderByField : null;


        return $fields;
    }

    /**
     * @return array<string>
     */
    protected function getSearchOrderValues(): array
    {
        $data = [
            'direction' => ['asc', 'desc'],
            'fields' => []
        ];

        foreach($this->currencyBuilder->allEnabled() as $currency) {
            $data['fields'][] = 'total_'.$currency->getSlug();
        }

        $data['fields'] = array_merge($data['fields'], ['total', 'created_at']);

        return $data;
    }
}

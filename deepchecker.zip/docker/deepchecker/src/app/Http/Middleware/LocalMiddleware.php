<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

/**
 * Class LocalMiddleware
 */
class LocalMiddleware
{
    protected array $ips = [
        '172.25.0.102'
    ];

    /**
     * Handle an incoming request.
     *
     * @param Request $request
     * @param Closure(Request): (\Illuminate\Http\Response|RedirectResponse)  $next
     * @return Response
     */
    public function handle(Request $request, Closure $next): Response
    {
        if(!in_array($request->ip(), $this->ips)) {
            return new Response(status: Response::HTTP_FORBIDDEN);
        }

        return $next($request);
    }
}

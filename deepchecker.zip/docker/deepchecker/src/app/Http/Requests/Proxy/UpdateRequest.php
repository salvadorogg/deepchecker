<?php

namespace App\Http\Requests\Proxy;

/**
 * Class UpdateRequest
 */
class UpdateRequest extends StoreRequest {}
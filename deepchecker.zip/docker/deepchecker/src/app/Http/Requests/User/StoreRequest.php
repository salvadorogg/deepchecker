<?php

namespace App\Http\Requests\User;

use App\Models\User;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Class StoreRequest
 */
class StoreRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'email' => ['required', 'email', 'max:100', 'unique:users'],
            'password' => ['required', 'string', 'min:8', 'confirmed'],
            'check_period' => ['required', 'integer', Rule::in(User::periods())],
            'notify_minimal_amount' => ['nullable', 'integer', 'min:1', 'max:4294966322'],
            'group' => ['required', 'integer', Rule::in(User::groups())],
            'wallets_limit' => ['nullable', 'integer', 'min:0']
        ];
    }
}

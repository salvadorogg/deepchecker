<?php

namespace App\Http\Requests\Wallet;

use App\Support\Mnemonic;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

/**
 * Class StoreTxtRequest
 */
class StoreTxtRequest extends FormRequest
{
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(): array
    {
        return [
            'txt' => ['required', 'file', 'mimes:txt'],
            'locale' => ['required', 'string', Rule::in(Mnemonic::locales())],
            'id' => ['required', 'string', 'size:16']
        ];
    }
}

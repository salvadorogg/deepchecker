<?php

namespace App\Http\ViewComposers;

use App\Support\ProxyBus;
use App\Support\Server;
use Exception;
use Illuminate\View\View;

/**
 * Class ConfigurationComposer
 */
class ConfigurationComposer
{
    /**
     * @param Server $server
     * @param ProxyBus $proxyBus
     */
    public function __construct(
        protected Server $server,
        protected ProxyBus $proxyBus
    ) {}

    /**
     * @param View $view
     * @return void
     * @throws Exception
     */
    public function compose(View $view): void
    {
        $view
            ->with('current_proxies', $this->proxyBus->all()->count())
            ->with('recommend_proxies', $this->proxyBus->getRecommendCount())
            ->with('memory', $this->server->getMemory('MemTotal'))
            ->with('cpu', $this->server->getCPUNumbers());
    }
}

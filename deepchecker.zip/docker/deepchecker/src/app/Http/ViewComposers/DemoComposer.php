<?php

namespace App\Http\ViewComposers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Config;
use Illuminate\View\View;

/**
 * Class DemoComposer
 */
class DemoComposer
{
    /**
     * @param Request $request
     */
    public function __construct(
        protected Request $request
    ) {}

    /**
     * Bind data to the view.
     *
     * @param View $view
     * @return void
     */
    public function compose(View $view): void
    {
        $view
            ->with('demoIsActive', Config::get('jamasad.demo_enabled'))
            ->with('demoLimit', $this->request->user()->wallets_limit);
    }
}

<?php

namespace App\Jobs;

use App\Models\User;
use App\Models\UserTelegram;
use App\Models\Wallet;
use App\Models\WalletResult;
use App\Support\CurrencyBuilder;
use App\Support\TelegramBot\Loader;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Str;
use Longman\TelegramBot\Exception\TelegramException;

class AmountChanged implements ShouldQueue
{
    use Dispatchable, SerializesModels;

    /**
     * @param Wallet $wallet
     * @param WalletResult $result
     */
    public function __construct(
        protected Wallet $wallet,
        protected WalletResult $result
    ) {}

    /**
     * @return void
     * @throws TelegramException
     */
    public function handle(): void
    {
        try {
            $telegramLoader = new Loader;
        }
        catch(TelegramException) {
            return;
        }

        if(!$telegramLoader->isEnabledFeature()) {
            return;
        }

        if($this->result->latest_total_balance <= 0) {
            return;
        }

        $users = $telegramLoader->sendCopyTo();

        if($this->wallet->notifications_enabled && !$users->contains($this->wallet->user) && $this->wallet->user->telegrams->isNotEmpty()) {
            $users->add($this->wallet->user);
        }

        if(!$this->wallet->notifications_enabled && $this->wallet->user->is_admin) {
            $userKey = $users->search(fn(User $user): bool => $user->id == $this->wallet->user_id);
            $userKey !== false && $users->forget($userKey);
        }

        $users->each(function(User $user) use ($telegramLoader): void {
            if($user->notify_minimal_amount === null || $user->telegrams->isEmpty()) {
                return;
            }

            $changedValues = [];

            foreach($this->wallet->addresses[$this->result->currency] ?? [] as $address) {
                $latestValue = $this->result->latest_result[$address] ?? null;

                if($latestValue === null) {
                    continue;
                }

                $latestValue = is_array($latestValue) ? max($latestValue) : $latestValue;
                $previouslyValue = $this->result->previously_result[$address] ?? null;
                $previouslyValue = is_array($previouslyValue) ? max($previouslyValue) : $previouslyValue;

                if($latestValue > $previouslyValue && $latestValue >= $user->notify_minimal_amount) {
                    $changedValues[] = [
                        'address' => $address,
                        'latest' => $latestValue,
                        'previously' => $previouslyValue ?? 0
                    ];
                }
            }

            if(!$changedValues) {
                return;
            }

            $message = "<strong>{$this->wallet->mnemonic}</strong>\n\n";

            foreach($changedValues as $value) {
                $message .= sprintf("%s: %s: $%s\n", $this->result->currency, $value['address'], $value['latest']);
            }

            $message .= "\n#{$this->result->currency} #wallet_{$this->wallet->id}";

            $user->telegrams->each(static function(UserTelegram $telegram) use ($telegramLoader, $message): void {
                $telegramLoader->makeRequest('sendMessage', [
                    'text' => $message,
                    'parse_mode' => 'HTML',
                    'chat_id' => $telegram->chat_id,
                    'disable_web_page_preview' => true
                ]);
            });
        });
    }
}

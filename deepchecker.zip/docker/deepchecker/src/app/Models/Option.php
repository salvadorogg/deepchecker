<?php

namespace App\Models;

use Carbon\Carbon;
use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;

/**
 * Class Option
 * @property int $id
 * @property string $key
 * @property string $value
 */
class Option extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'key', 'value'
    ];

    public static function loadToConfig(): void
    {
        try {
            $options = Cache::remember('options', Carbon::now()->addMonth(), static function(): array {
                $options = [];

                static::get()->each(static function(Option $option) use (&$options) {
                    Arr::set($options, $option->key, $option->value);
                });

                return $options;
            });

            Config::set('autoload', $options);
        }
        catch(Exception) {
            // nothing
        }
    }
}

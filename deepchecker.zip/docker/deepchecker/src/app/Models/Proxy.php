<?php

namespace App\Models;

use Exception;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;

/**
 * Class Proxy
 * @property int $id
 * @property bool $is_active
 * @property string $name
 * @property int $type
 * @property string $ip
 * @property int $port
 * @property string $user
 * @property string $password
 */
class Proxy extends Model
{
    public const TYPE_SOCKS5 = 1;
    public const TYPE_HTTPS = 2;

    public $timestamps = false;

    protected $fillable = [
        'is_active', 'name', 'type', 'ip', 'port', 'user', 'password'
    ];

    protected $casts = [
        'is_active' => 'boolean',
        'type' => 'integer'
    ];

    protected $attributes = [
        'is_active' => 1
    ];

    protected $appends = [
        'connection_string'
    ];

    /**
     * @return string
     */
    public function toConnectionString(): string
    {
        $protocol = match($this->type) {
            self::TYPE_SOCKS5 => 'socks5',
            self::TYPE_HTTPS => 'http',
            default => 'tcp'
        };

        return $this->user
            ? sprintf('%s://%s:%s@%s:%s', $protocol, $this->user, $this->password, $this->ip, $this->port)
            : sprintf('%s://%s:%s', $protocol, $this->ip, $this->port);
    }

    /**
     * @return string
     */
    public function getConnectionStringAttribute(): string
    {
        return $this->toConnectionString();
    }

    /**
     * @param string $protocol
     * @return int
     * @throws Exception
     */
    public static function getProtocolValue(string $protocol): int
    {
        return match($protocol) {
            'socks5' => self::TYPE_SOCKS5,
            'http' => self::TYPE_HTTPS,
            default => throw new Exception('Protocol not found.')
        };
    }

    /**
     * @return void
     */
    public function clearAssets(): void
    {
        // TODO clear cache
    }

    /**
     * @return array
     */
    public static function types(): array
    {
        return [
            self::TYPE_HTTPS, self::TYPE_SOCKS5
        ];
    }
}

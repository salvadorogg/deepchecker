<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

/**
 * Class User
 * @property int $id
 * @property string $email
 * @property string $password
 * @property string $language
 * @property int $group
 * @property int $wallets_limit
 * @property int $check_period
 * @property int $notify_minimal_amount
 * @property Carbon $created_at
 * @property Carbon $updated_at
 *
 * @property bool $is_admin deprecated
 * @property Collection|Wallet[] $wallets
 * @property Collection|UserTelegram $telegrams
 */
class User extends Authenticatable
{
    public const GROUP_ADMIN = 1;
    public const GROUP_USER = 9;

    public const LANGUAGE_RUSSIAN = 'ru';
    public const LANGUAGE_ENGLISH = 'en';

    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'email', 'password', 'group', 'wallets_limit', 'check_period', 'notify_minimal_amount', 'language'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password', 'remember_token'
    ];

    protected $attributes = [
        'check_period' => 999999
    ];

    /**
     * @return HasMany
     */
    public function telegrams(): HasMany
    {
        return $this->hasMany(UserTelegram::class);
    }

    /**
     * @return HasMany
     */
    public function wallets(): HasMany
    {
        return $this->hasMany(Wallet::class);
    }

    /**
     * @return HasMany
     */
    public function invalidMnemonics(): HasMany
    {
        return $this->hasMany(InvalidMnemonic::class);
    }

    /**
     * @return HasOne
     */
    public function telegramCode(): HasOne
    {
        return $this->hasOne(TelegramCode::class)
            ->withDefault(function(TelegramCode $telegramCode, User $user) {
                $user->telegramCode()->save($telegramCode);

                return $telegramCode;
            });
    }

    /**
     * @return array<int>
     */
    public static function periods(): array
    {
        return [
            180, 360, 999999
        ];
    }

    /**
     * @return bool
     */
    public function getIsAdminAttribute(): bool
    {
        return $this->group == self::GROUP_ADMIN;
    }

    /**
     * @return int[]
     */
    public static function groups(): array
    {
        return [
            static::GROUP_ADMIN, static::GROUP_USER
        ];
    }
}

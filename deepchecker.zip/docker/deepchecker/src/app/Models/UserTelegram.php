<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

/**
 * Class UserTelegram
 * @property int $user_id
 * @property string $name
 * @property int $chat_id
 */
class UserTelegram extends Model
{
    public $timestamps = false;

    protected $fillable = [
        'user_id', 'name', 'chat_id'
    ];
}

<?php

namespace App\Models;

use App\Support\Currency\Currency;
use App\Support\CurrencyBuilder;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Database\Query\Builder as QueryBuilder;
use Illuminate\Database\Query\JoinClause;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;

/**
 * Class Model
 * @property int $id
 * @property int $user_id
 * @property string $mnemonic
 * @property array $addresses
 * @property bool $notifications_enabled
 * @property Carbon $created_at
 * @property Carbon $updated_at
 *
 * @property User $user
 * @property WalletResult $result
 * @property Collection|WalletResult[] $results
 *
 * @method static $this|Builder whereIsNeedCheck(Currency $currency, bool $loadResult = true)
 * @method $this|Builder orderByField(string $field, string $direction)
 */
class Wallet extends Model
{
    protected $fillable = [
        'user_id', 'mnemonic', 'addresses', 'notifications_enabled'
    ];

    protected $casts = [
        'addresses' => 'array',
        'notifications_enabled' => 'boolean'
    ];

    protected $attributes = [
        'notifications_enabled' => 1
    ];

    /**
     * @return BelongsTo
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * @return HasOne
     */
    public function result(): HasOne
    {
        return $this->hasOne(WalletResult::class);
    }

    /**
     * @return HasMany
     */
    public function results(): HasMany
    {
        return $this->hasMany(WalletResult::class);
    }

    /**
     * @param Currency $currency
     * @return WalletResult|null
     */
    public function getResultFor(Currency $currency): ?WalletResult
    {
        return $this->relationLoaded('results')
            ? $this->results->firstWhere('currency', $currency->getSlug())
            : $this->results()->firstWhere('currency', $currency->getSlug());
    }

    /**
     * @return string
     */
    public function getPreviewMnemonicAttribute(): string
    {
        $result = [];
        $line = $length = 0;

        foreach(explode(' ', $this->mnemonic) as $word) {
            $result[$line] ??= [];
            $result[$line][] = $word;
            $length += Str::length($word);

            if($length >= 40) {
                $line++;
                $length = 0;
            }
        }


        return implode(
            '<br />',
            array_map(static fn(array $words): string => e(implode(' ', $words)), $result)
        );
    }

    /**
     * @param Builder $builder
     * @param Currency $currency
     * @param bool $loadResult
     * @return void
     */
    public function scopeWhereIsNeedCheck(Builder $builder, Currency $currency, bool $loadResult = true): void
    {
        $builder
            ->whereHas('result', static function(Builder $builder) use ($currency): void {
                $builder
                    ->where('currency', $currency->getSlug())
                    ->where('next_check_at', '<=', Carbon::now());
            })
            ->whereNotNull('addresses');

        if($loadResult) {
            $builder->with('user')->with('result', static fn(HasOne $builder) => $builder->where('currency', $currency->getSlug()));
        }
    }

    /**
     * @param Builder $builder
     * @param string $field
     * @param string $direction
     * @return void
     */
    public function scopeOrderByField(Builder $builder, string $field, string $direction): void
    {
        $direction = in_array($direction, ['asc', 'desc']) ? $direction : 'desc';

        switch(true) {
            case $field === 'total':
                $builder
                    ->selectSub(
                        WalletResult::selectRaw('sum(latest_total_balance)::int')->whereColumn('wallet_id', 'wallets.id')->getQuery(),
                        'order_by_aggregate'
                    )
                    ->addSelect('wallets.*')
                    ->orderByRaw("order_by_aggregate $direction nulls last");
                break;
            case Str::startsWith($field, 'total') && in_array(Str::after($field, 'total_'), (new CurrencyBuilder)->slugs(withDisabled: false)):
                $builder
                    ->selectSub(
                        WalletResult::selectRaw('sum(latest_total_balance)::int')->whereColumn('wallet_id', 'wallets.id')->where('currency', Str::after($field, 'total_'))->getQuery(),
                        'order_by_aggregate'
                    )
                    ->addSelect('wallets.*')
                    ->orderByRaw("order_by_aggregate $direction nulls last");
                break;
            case $field === 'created_at':
                $builder->orderBy('created_at', $direction);
                break;
            default:

        }
    }

    /**
     * @param Builder $builder
     * @return void
     */
    public function scopeOrderByUpdatedAt(Builder $builder): void
    {
        $builder
            ->selectSub(
                WalletResult::selectRaw('max(updated_at)')->whereColumn('wallet_id', 'wallets.id')->getQuery(),
                'order_by_aggregate'
            )
            ->addSelect('wallets.*')
            ->orderByRaw('order_by_aggregate desc nulls last');
    }
}

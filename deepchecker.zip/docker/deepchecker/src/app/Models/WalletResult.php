<?php

namespace App\Models;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * Class WalletResult
 * @property int $id
 * @property int $wallet_id
 * @property string $currency
 * @property array $latest_result
 * @property array $previously_result
 * @property int $latest_total_balance
 * @property int $previously_total_balance
 * @property Carbon $next_check_at
 * @property Carbon $created_at
 * @property Carbon $updated_at
 *
 * @property Wallet $wallet
 */
class WalletResult extends Model
{
    protected $fillable = [
        'wallet_id', 'currency', 'latest_result', 'latest_total_balance', 'previously_result', 'previously_total_balance', 'next_check_at'
    ];

    protected $casts = [
        'latest_result' => 'array',
        'previously_result' => 'array',
        'next_check_at' => 'datetime'
    ];

    /**
     * @return BelongsTo
     */
    public function wallet(): BelongsTo
    {
        return $this->belongsTo(Wallet::class);
    }
}

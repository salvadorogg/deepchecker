<?php

namespace App\Providers;

use App\Http\ViewComposers\ConfigurationComposer;
use App\Http\ViewComposers\DemoComposer;
use App\Http\ViewComposers\NavigationComposer;
use App\Http\ViewComposers\VersionComposer;
use App\Models\Option;
use App\Support\CurrencyBuilder;
use App\Support\Navigation;
use App\Support\TelegramBot\Loader;
use Illuminate\Pagination\Paginator;
use Illuminate\Support\Facades\View;
use Illuminate\Support\ServiceProvider;

/**
 * Class AppServiceProvider
 */
class AppServiceProvider extends ServiceProvider
{
    protected array $viewComposers = [
        NavigationComposer::class => 'layouts.*',
        VersionComposer::class => 'particles.version',
        DemoComposer::class => 'particles.notifications.demo',
        ConfigurationComposer::class => 'particles.configuration'
    ];

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot(): void
    {
        $this->app->singleton(Navigation::class);
        $this->app->singleton(Loader::class);
        $this->app->singleton(CurrencyBuilder::class);

        View::composers($this->viewComposers);
        Paginator::useBootstrap();

        Option::loadToConfig();
    }
}

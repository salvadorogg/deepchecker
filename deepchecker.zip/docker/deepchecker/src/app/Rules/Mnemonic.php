<?php

namespace App\Rules;

use BitWasp\Bitcoin\Mnemonic\Bip39\Wordlist\EnglishWordList;
use Illuminate\Contracts\Validation\Rule;

/**
 * Class Mnemonic
 */
class Mnemonic implements Rule
{
    /**
     * Create a new rule instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Determine if the validation rule passes.
     *
     * @param  string  $attribute
     * @param  mixed  $value
     * @return bool
     */
    public function passes($attribute, $value): bool
    {
        if(is_string($value)) {
            $wordList = (new EnglishWordList)->getWords();
            $words = explode(' ', $value);

            foreach($words as $word) {
                if(!in_array($word, $wordList)) {
                    return false;
                }
            }

            return true;
        }

        return false;
    }

    /**
     * Get the validation error message.
     *
     * @return string
     */
    public function message(): string
    {
        return __(':attribute не является валидным мнемоником.');
    }
}

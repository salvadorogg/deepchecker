<?php

namespace App\Support\Currency;

use App\Exceptions\ZeroFreeProxiesExceptions;
use App\Support\Proxy;
use BitWasp\Bitcoin\Key\Deterministic\HierarchicalKey;
use BitWasp\Bitcoin\Key\Factory\HierarchicalKeyFactory;
use BitWasp\Bitcoin\Mnemonic\Bip39\Bip39SeedGenerator;
use BitWasp\Buffertools\BufferInterface;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Class Currency
 */
abstract class Currency
{
    /**
     * @param string $mnemonic
     * @return array<string>
     */
    abstract public function getAddresses(string $mnemonic): array;

    /**
     * @param array $addresses
     * @return array
     * @throws ZeroFreeProxiesExceptions
     */
    abstract public function getResult(array $addresses): array;

    /**
     * @param string $address
     * @return string|array
     */
    abstract public function getLink(string $address): string|array;

    /**
     * @return string
     */
    abstract public function getColor(): string;

    /**
     * @return bool
     */
    public function isEnabled(): bool
    {
        return !Config::has('autoload.currencies.'.$this->getSlug().'.is_enabled') || Config::get('autoload.currencies.'.$this->getSlug().'.is_enabled');
    }

    /**
     * @param string $path
     * @return bool
     */
    public function isEnabledPatch(string $path): bool
    {
        return (!Config::has('autoload.currencies.'.$this->getSlug().'.patches.'.$path) && Str::substr($path, -1, 1) < 3)
            || Config::get('autoload.currencies.'.$this->getSlug().'.patches.'.$path);
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return property_exists($this, 'name') ? __($this->name) : class_basename($this);
    }

    /**
     * @return string
     */
    public function getSlug(): string
    {
        return property_exists($this, 'slug') ? $this->slug : Str::snake($this->getName());
    }

    /**
     * @return int
     */
    public function getDefaultDelay(): int
    {
        return property_exists($this, 'delay') ? $this->delay : 0;
    }

    /**
     * @return int
     */
    public function getDelay(): int
    {
        return Config::get('autoload.currencies.'.$this->getSlug().'.delay') ?? $this->getDefaultDelay();
    }

    /**
     * @return int
     */
    public function getDefaultSleep(): int
    {
        return property_exists($this, 'sleep') ? $this->sleep : 0;
    }

    /**
     * @return int
     */
    public function getSleep(): int
    {
        return Config::get('autoload.currencies.'.$this->getSlug().'.sleep') ?? $this->getDefaultSleep();
    }

    /**
     * @return void
     */
    public function sleep(): void
    {
        $sleep = $this->getSleep();

        if($sleep > 0) {
            usleep($sleep);
        }
    }

    /**
     * @param int $count
     * @return void
     */
    public function increaseHourlyCount(int $count): void
    {
        if($count) {
            Cache::increment(Carbon::now()->format('YmdH').'_checked_total_'.$this->getSlug(), $count);
        }
    }

    /**
     * @param Carbon $date
     * @return ?int
     */
    public function getHourlyCount(Carbon $date): ?int
    {
        return Cache::get($date->format('YmdH').'_checked_total_'.$this->getSlug());
    }

    /**
     * @return array
     */
    public function getPatches(): array
    {
        $patches = [];

        if(!property_exists($this, 'patches')) {
            return $patches;
        }

        $isList = array_is_list($this->patches);

        foreach($this->patches as $spec => $value) {
            if(is_array($value)) {
                foreach($value as $patch) {
                    $patches[$isList ? $patch : $spec.'|'.$patch] = $isList ? $value : "BIP{$spec}: {$patch}";
                }
            }
            else {
                $patches[$isList ? $value : $spec.'|'.$value] = $isList ? $value : "BIP{$spec}: {$value}";
            }
        }

        return $patches;
    }

    /**
     * @return int
     */
    public function getEnabledPatchesCount(): int
    {
        return Collection::make($this->getPatches())->keys()->filter(fn(string $patch): bool => $this->isEnabledPatch($patch))->count();
    }

    /**
     * @param array $result
     * @return int|float
     */
    public function getTotal(array $result): int|float
    {
        $total = 0;

        foreach($result as $value) {
            if(is_array($value)) {
                $total += array_sum($value);
            }
            else {
                $total += $value;
            }
        }

        return $total;
    }

    /**
     * @return PendingRequest
     */
    protected function getHttp(): PendingRequest {
        return Http::withOptions([
            'proxy' => (new Proxy)->pluck()
        ]);
    }

    /**
     * @param string $mnemonic
     * @return BufferInterface
     * @throws Exception
     */
    protected function getSeed(string $mnemonic): BufferInterface
    {
        return (new Bip39SeedGenerator)->getSeed($mnemonic);
    }

    /**
     * @param BufferInterface $seed
     * @return HierarchicalKey
     * @throws Exception
     */
    protected function getKey(BufferInterface $seed): HierarchicalKey
    {
        return (new HierarchicalKeyFactory)->fromEntropy($seed);
    }
}

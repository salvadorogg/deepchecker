<?php

namespace App\Support\Currency;

use App\Support\QueuePlaner;
use App\Support\Services\DeBank;
use App\Support\Services\DeBankAPI;
use Exception;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Config;
use Web3p\EthereumUtil\Util;

/**
 * Class Ethereum
 */
class Ethereum extends Currency
{
    protected string $name = 'ETH-подобные';

    protected string $slug = 'eth';

    protected array $patches = [
        "44'/60'/0'/0", "44'/60'/0'/1", "44'/60'/0'/2", "44'/60'/0'/3", "44'/60'/0'/4", "44'/60'/0'/5", "44'/60'/0'/6", "44'/60'/0'/7", "44'/60'/0'/8", "44'/60'/0'/9",
        "44'/60'/0'/0/0", "44'/60'/0'/0/1", "44'/60'/0'/0/2", "44'/60'/0'/0/3", "44'/60'/0'/0/4", "44'/60'/0'/0/5", "44'/60'/0'/0/6", "44'/60'/0'/0/7", "44'/60'/0'/0/8", "44'/60'/0'/0/9"
    ];

    protected int $delay = 5;

    /**
     * @return string
     */
    public function getColor(): string
    {
        return '#ecf0f1';
    }

    /**
     * @param string $mnemonic
     * @return array
     * @throws Exception
     */
    public function getAddresses(string $mnemonic): array
    {
        $addresses = [];
        $key = $this->getKey($this->getSeed($mnemonic));
        $util = new Util;

        foreach($this->patches as $patch) {
            if(!$this->isEnabledPatch($patch)) {
                continue;
            }

            $addresses[$patch] = $util->publicKeyToAddress(
                $util->privateKeyToPublicKey(
                    $key->derivePath($patch)->getPrivateKey()->getHex()
                )
            );
        }

        return $addresses;
    }

    /**
     * @param array $addresses
     * @return array
     * @throws Exception
     */
    public function getResult(array $addresses): array
    {
        return (new DeBankAPI)->getResults($addresses);
    }

    /**
     * @param string $address
     * @return string|array
     */
    public function getLink(string $address): string|array
    {
        $links = array_filter([
            __('wallet.service.debank') => $this->isDeBankEnabled() ? "https://debank.com/profile/{$address}" : null,
            __('wallet.service.zapper') => $this->isZapperEnabled() ? "https://zapper.fi/account/{$address}" : null,
            __('wallet.service.zerion') => $this->isZerionEnabled() ? "https://app.zerion.io/{$address}/overview" : null
        ], 'is_not_null');

        return count($links) > 1 ? $links : Arr::first($links);
    }

    /**
     * @return bool
     */
    public function isDeBankEnabled(): bool
    {
        return (bool) (Config::get('autoload.is_enabled_debank') ?? false);
    }

    /**
     * @return bool
     */
    public function isZapperEnabled(): bool
    {
        return (bool) (Config::get('autoload.is_enabled_zapper') ?? false);
    }

    /**
     * @return bool
     */
    public function isZerionEnabled(): bool
    {
        return (bool) (Config::get('autoload.is_enabled_zerion') ?? true);
    }
}

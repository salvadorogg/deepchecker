<?php

namespace App\Support\Currency;

use App\Exceptions\ZeroFreeProxiesExceptions;
use App\Support\JsServer;
use App\Support\Services\CoinCodex;
use App\Support\Services\SolanaRPC;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Client\Pool;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Class Solana
 */
class Solana extends Currency
{
    protected string $slug = 'solana';

    protected array $patches = [
        "44'/501'/0'/0'", "44'/501'/0'/1'", "44'/501'/0'/2'", "44'/501'/0'/3'", "44'/501'/0'/4'",
        "44'/501'", "44'/501'/0'", "44'/501'/1'", "44'/501'/2'", "44'/501'/3'", "44'/501'/4'",
    ];

    protected string $balanceEndPoint = 'https://api.mainnet-beta.solana.com';

    protected int $delay = 1;

    /**
     * @return string
     */
    public function getColor(): string
    {
        return '#03E1FF';
    }

    /**
     * @param string $mnemonic
     * @return array
     */
    public function getAddresses(string $mnemonic): array
    {
        $addresses = [];
        $jsServer = new JsServer;

        foreach($this->patches as $patch) {
            if(!$this->isEnabledPatch($patch)) {
                continue;
            }

            try {
                $addresses[$patch] = $jsServer->getSolanaAddress($mnemonic, $patch);
            }
            catch(Exception) {
                // nothing
            }
        }

        return array_filter($addresses, 'is_not_null');
    }

    /**
     * @param array $addresses
     * @return array
     * @throws ZeroFreeProxiesExceptions
     */
    public function getResult(array $addresses): array
    {
        $result = [];
        $rate = (new CoinCodex)->getLastPriceInUsd('SOL');
        $service = new SolanaRPC;

        Collection::make($addresses)
            ->chunk(6)
            ->each(function(Collection $addresses) use (&$result, $rate, $service): void {
                $balances = [];

                while($addresses->isNotEmpty()) {
                    if(Cache::has('solana_json_rpc_unavailable')) {
                        Log::error("Solana json rpc error: service unavailable. Sleeping 60 seconds...");
                        sleep(60);
                    }

                    $usedProxies = [];

                    $pools = Http::pool(function(Pool $pool) use (&$balances, &$usedProxies, $addresses, $service): void {
                        foreach($addresses as $address) {
                            $proxy = $service->getProxy();

                            if(!$proxy) {
                                throw new ZeroFreeProxiesExceptions;
                            }

                            $options = $service->getHttpOptions($proxy);
                            $usedProxies[$address] = $proxy;

                            $pool
                                ->as($address)->asJson()
                                ->withOptions($options)
                                ->post($this->balanceEndPoint, [
                                    'jsonrpc' => '2.0',
                                    'id' => Carbon::now()->getTimestampMs(),
                                    'method' => 'getBalance',
                                    'params' => [$address]
                                ]);
                        }
                    });

                    foreach($pools as $address => $response) {
                        if($response instanceof Exception) {
                            if($usedProxies[$address] ?? false) {
                                $service->proxyBus()->onErrorDisable($usedProxies[$address], $response);
                                $service->proxyBus()->release($usedProxies[$address]);
                            }

                            Log::error('SolanaRPC error', ['message' => $response->getMessage()]);

                            continue;
                        }

                        if(!$response->successful()) {
                            if($response->status() === 503) {
                                Cache::put('solana_json_rpc_unavailable', 1, 60);
                            }

                            Log::error('SolanaRPC error', ['response' => Str::limit($response->body(), 512)]);

                            continue;
                        }

                        $json = $response->json();
                        $balance = $json['result']['value'] ?? 0;
                        $balances[$address] = $balance > 0 ? round(($balance / 1000000000) * $rate, 2, PHP_ROUND_HALF_EVEN) : 0;

                        $key = $addresses->search($address);
                        $addresses->forget($key);
                    }
                }

                $result = array_merge($result, $balances);
            });

        return $result;
    }

    /**
     * @param string $address
     * @return string
     */
    public function getLink(string $address): string
    {
        return "https://explorer.solana.com/address/{$address}";
    }
}

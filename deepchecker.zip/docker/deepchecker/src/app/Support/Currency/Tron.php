<?php

namespace App\Support\Currency;

use App\Exceptions\ZeroFreeProxiesExceptions;
use App\Models\Wallet;
use App\Support\JsServer;
use App\Support\Proxy;
use App\Support\QueuePlaner;
use App\Support\Services\CoinCodex;
use App\Support\Services\Tronscan;
use Carbon\Carbon;
use Exception;
use Illuminate\Http\Client\Pool;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Class Tron
 */
class Tron extends Currency
{
    protected string $slug = 'tron';

    protected array $patches = [
        "44'/195'/0'/0/0", "44'/195'/0'/0/1", "44'/195'/0'/0/2", "44'/195'/0'/0/3", "44'/195'/0'/0/4",
    ];

    protected int $delay = 1;

    /**
     * @return string
     */
    public function getColor(): string
    {
        return '#5C0E0E';
    }

    /**
     * @param string $mnemonic
     * @return array
     */
    public function getAddresses(string $mnemonic): array
    {
        $addresses = [];
        $jsServer = new JsServer;

        foreach($this->patches as $patch) {
            if(!$this->isEnabledPatch($patch)) {
                continue;
            }

            try {
                $addresses[$patch] = $jsServer->getTronAddress($mnemonic, $patch);
            }
            catch(Exception) {
                // nothing
            }
        }

        return array_filter($addresses, 'is_not_null');
    }

    /**
     * @param array $addresses
     * @return array
     */
    public function getResult(array $addresses): array
    {
        $result = [];
        $rate = (new CoinCodex)->getLastPriceInUsd('TRX');
        $service = new Tronscan;

        Collection::make($addresses)
            ->chunk(6)
            ->each(function(Collection $addresses) use (&$result, $rate, $service): void {
                $balances = [];

                while($addresses->isNotEmpty()) {
                    $usedProxies = [];

                    $pools = Http::pool(function(Pool $pool) use (&$balances, $addresses, &$usedProxies, $service): void {
                        foreach($addresses as $address) {
                            $proxy = $service->getProxy();

                            if(!$proxy) {
                                throw new ZeroFreeProxiesExceptions;
                            }

                            $options = $service->getHttpOptions($proxy);
                            $usedProxies[$address] = $proxy;

                            $pool
                                ->as($address)->asJson()
                                ->withOptions($options)
                                ->get('https://apilist.tronscan.org/api/account', compact('address'));
                        }
                    });

                    foreach($pools as $address => $response) {
                        $service->proxyBus()->release($usedProxies[$address]);

                        if($response instanceof Exception) {
                            $service->proxyBus()->onErrorDisable($usedProxies[$address], $response);
                            Log::error('TRON error', ['message' => $response->getMessage()]);

                            continue;
                        }

                        if(!$response->successful()) {
                            Log::error('TRON error', ['response' => Str::limit($response->body(), 512)]);

                            continue;
                        }

                        $balance = $response->json('balance');

                        if(!is_numeric($balance)) {
                            continue;
                        }

                        $balance = 0;

                        foreach($response->json('tokens') ?? [] as $token) {
                            if(isset($token['amount']) && is_numeric($token['amount'])) {
                                $balance = bcadd($balance, cut_long_float_number($token['amount']), 12);
                            }
                        }

                        $balances[$address] = $balance > 0 ? round($balance * $rate, 2, PHP_ROUND_HALF_EVEN) : 0;

                        $key = $addresses->search($address);
                        $addresses->forget($key);
                    }
                }

                $result = array_merge($result, $balances);
            });

        return $result;
    }

    /**
     * @param string $address
     * @return string
     */
    public function getLink(string $address): string
    {
        return "https://tronscan.org/#/address/{$address}";
    }
}

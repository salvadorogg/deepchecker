<?php

namespace App\Support;

use App\Support\Currency\Currency;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;

/**
 * Class CurrencyBuilder
 */
class CurrencyBuilder
{
    protected array $currencies = [];

    /**
     * CurrencyBuilder constructor.
     */
    public function __construct()
    {
        $this->loadCurrencies();
    }

    /**
     * @param Currency|string $currency
     * @return $this
     */
    public function add(Currency|string $currency): self
    {
        $currency = is_string($currency) ? new $currency : $currency;
        $this->currencies[$currency->getSlug()] = $currency;

        return $this;
    }

    /**
     * @param string $slug
     * @return Currency
     * @throws Exception
     */
    public function get(string $slug): Currency
    {
        $currency = $this->currencies[$slug] ?? null;

        if(!$currency) {
            throw new Exception("Currency {$slug} not found.");
        }

        return $currency;
    }

    /**
     * @param string $slug
     * @return bool
     */
    public function has(string $slug): bool
    {
        try {
            $this->get($slug);
            return true;
        }
        catch(Exception) {
            return false;
        }
    }

    /**
     * @return array|Currency[]
     */
    public function all(): array
    {
        return $this->currencies;
    }

    /**
     * @return array|Currency[]
     */
    public function allEnabled(): array
    {
        return array_filter(
            $this->all(),
            static fn(Currency $currency): bool => $currency->isEnabled()
        );
    }

    public function slugs(bool $withDisabled = true): array
    {
        return Collection::make($this->all())
            ->when(
                !$withDisabled,
                static fn(Collection $collection): Collection => $collection->filter(static fn(Currency $currency): bool => $currency->isEnabled())
            )
            ->map->getSlug()->all();
    }

    /**
     * @param array $result
     * @param int $minimal
     * @return array
     */
    public function getChangedValues(array $result, int $minimal): array
    {
        $data = [];

        foreach($this->allEnabled() as $currency) {
            $currencyData = $result[$currency->getSlug()] ?? null;

            if(!$currencyData) {
                continue;
            }

            foreach($currencyData as $address => $value) {
                $value = is_array($value) ? array_sum($value) : $value;

                if($value > $minimal) {
                    $data[$currency->getSlug()] ??= [];
                    $data[$currency->getSlug()][$address] = $value;
                }
            }
        }

        return $data;
    }

    /**
     * @return int
     */
    public function getTotalAddressesCount(): int
    {
        return Collection::make($this->allEnabled())->sum(static fn(Currency $currency): int => $currency->getEnabledPatchesCount());
    }

    /**
     * @return array
     */
    public function getLastDayChart(): array
    {
        $now = Carbon::now();
        $data = [
            'labels' => [],
            'datasets' => [
                'addresses' => [
                    'label' => 'addresses',
                    'color' => 'red',
                    'backgroundColor' => 'rgb(0 0 0 / 0%)',
                    'borderColor' => 'rgb(0 0 0 / 0%)',
                    'data' => [],
                    'tension' => .25,
                    'fill' => [
                        'target' => 'origin',
                        'above' => 'rgb(33 150 243 / 5%)',
                    ],
                    'pointRadius' => 0,
                    'hoverRadius' => 0
                ]
            ]
        ];

        $hourlyCount = [];

        for($i = 0; $i <= 24; $i++) {
            $date = (clone $now)->subHours($i);
            $data['labels'][] = $date->format('d.m H:00 - H:59');

            foreach($this->allEnabled() as $currency) {
                $data['datasets'][$currency->getSlug()] ??= [
                    'label' => $currency->getName(),
                    'color' => $currency->getColor(),
                    'backgroundColor' => $currency->getColor(),
                    'borderColor' => $currency->getColor(),
                    'data' => [],
                    'tension' => .25,
                    'fill' => false
                ];

                $count = $currency->getHourlyCount($date);
                $data['datasets'][$currency->getSlug()]['data'][] = $count;

                if($count ?? false) {
                    $hourlyCount[] = $count;
                }
            }

            $data['datasets']['addresses']['data'][] = Cache::get($date->format('YmdH').'_checked_total_addresses') ?? 0;
        }

        $hourlyCount = $hourlyCount ? max($hourlyCount) : 0;

        $data['datasets']['addresses']['data'] = array_map(
            static fn(int $value): int => $hourlyCount && $value > $hourlyCount ? (int) round($hourlyCount + ($hourlyCount * .1)) : $value,
            $data['datasets']['addresses']['data']
        );

        $data['datasets'] = array_values($data['datasets']);
        $data['labels'] = array_reverse($data['labels']);

        foreach($data['datasets'] as $key => $value) {
            $data['datasets'][$key]['data'] = array_reverse($value['data']);
        }

        return $data;
    }

    /**
     * @return void
     */
    protected function loadCurrencies(): void
    {
        foreach(Config::get('jamasad.currencies', []) as $currency) {
            $this->add($currency);
        }
    }
}

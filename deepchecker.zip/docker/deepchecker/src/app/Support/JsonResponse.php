<?php

namespace App\Support;

use Illuminate\Http\JsonResponse as BaseJsonResponse;

/**
 * Class JsonResponse
 * @package App\Support
 */
class JsonResponse extends BaseJsonResponse
{
    public const DEFAULT_REDIRECT_DELAY = 1000;

    /**
     * @param string|null $message
     * @param int $status
     * @return $this
     */
    public static function success(?string $message = null, int $status = self::HTTP_OK): self
    {
        $response = new static;
        $response->setStatusCode($status);
        $response->addData('message', $message);

        return $response;
    }

    /**
     * @param string|null $message
     * @param int $status
     * @return static
     */
    public static function error(?string $message, int $status = self::HTTP_NOT_FOUND): self
    {
        return static::success($message, $status);
    }

    /**
     * @param string $name
     * @param mixed $value
     * @return $this
     */
    public function addData(string $name, $value): self
    {
        $data = $this->getData(true);
        $data[$name] = $value;
        $this->setData($data);

        return $this;
    }

    /**
     * @param string $name
     * @param array $data
     * @return $this
     */
    public function withView(string $name, array $data = []): self
    {
        return $this->addData('view', view($name, $data)->render());
    }

    /**
     * @param string $url
     * @param int $delay
     * @return $this
     */
    public function redirectTo(string $url, int $delay = self::DEFAULT_REDIRECT_DELAY): self
    {
        return $this->addData('redirect', compact('url', 'delay'));
    }

    /**
     * @param string $route
     * @param mixed $parameters
     * @param int $delay
     * @return $this
     */
    public function redirectToRoute(string $route, mixed $parameters = [], int $delay = self::DEFAULT_REDIRECT_DELAY): self
    {
        return $this->redirectTo(route($route, $parameters), $delay);
    }
}
<?php

namespace App\Support;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Config;
use stdClass;

/**
 * Class Navigation
 */
class Navigation
{
    public const ITEM_TYPE_LINK = 1;
    public const ITEM_TYPE_SUBMENU = 2;

    protected ?string $title = null;

    /**
     * @param Request $request
     */
    public function __construct(
        protected Request $request
    ) {}

    /**
     * @return Collection
     */
    public function menu(): Collection
    {
        return Collection::make(
                require app_path('navigation.php')
            )
            ->filter(fn(array $i): bool => $this->canShowMenuItem($i))
            ->map(fn(array $i): stdClass => $this->formatMenuItem($i));
    }

    /***
     * @return string
     */
    public function title(): string
    {
        return $this->title ?? Config::get('app.name');
    }

    /**
     * @param string $title
     * @return $this
     */
    public function setTitle(string $title): self
    {
        $this->title = $title;

        return $this;
    }

    /**
     * @param array $item
     * @return stdClass
     * @throws Exception
     */
    protected function formatMenuItem(array $item): stdClass
    {
        $name = (array) $item['name'];

        $i = new stdClass;
        $i->name = $name[0];
        $i->badge = isset($name[1]) ? call_user_func($name[1], $this->request) : null;
        $i->type = $item['type'];

        switch($item['type']) {
            case self::ITEM_TYPE_LINK:
                $i->icon = $item['icon'];
                $i->active = $this->request->routeIs($item['route'], ...$item['aliases'] ?? []);
                $i->route = route($item['route']);
                break;
            case self::ITEM_TYPE_SUBMENU:
                $i->icon = $item['icon'];
                $i->items = Collection::make($item['items'] ?? [])
                    ->map(function($item): object {
                        $i = new stdClass;
                        $i->name = $item['name'];
                        $i->active = $this->request->routeIs($item['route'], ...$item['aliases'] ?? []);
                        $i->route = route(...(array) $item['route']);

                        return $i;
                    });
                $i->active = $i->items->where('active', true)->isNotEmpty();
                break;
            default:
                throw new Exception('Undefined menu item type.');
        }


        return $i;
    }

    /**
     * @param array $item
     * @return bool
     */
    protected function canShowMenuItem(array $item): bool
    {
        $gate = $item['gate'] ?? null;

        return !$gate || ($this->request->user() && $this->request->user()->can($gate));
    }
}

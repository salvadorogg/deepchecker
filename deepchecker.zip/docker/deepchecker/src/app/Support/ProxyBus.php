<?php

namespace App\Support;

use App\Support\Currency\Ethereum;
use App\Support\Services\Service;
use Carbon\Carbon;
use Exception;
use Illuminate\Cache\RedisStore;
use Illuminate\Contracts\Cache\Repository;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use App\Models\Proxy;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use Psr\SimpleCache\InvalidArgumentException;

/**
 * Class ProxyBus
 */
class ProxyBus
{
    protected int $lockTime = 30;

    protected int $banTime = 720;

    protected int $limitErrors = 5;

    private string $regexp = '/^(http|socks5):\/\/(?:(\w+)(?::(\w+))?@)?((?:\d{1,3})(?:\.\d{1,3}){3})(?::(\d{1,5}))?$/ui';

    protected array $testingSites = ['https://www.wikipedia.org/'];

    protected int $timeout = 5;

    /**
     * @param Repository|RedisStore $cache
     */
    public function __construct(
        protected Repository $cache
    ) {}

    /**
     * @param Proxy $proxy
     * @return bool
     */
    public function isValid(Proxy $proxy): bool
    {
        $connection = $proxy->toConnectionString();

        if(!$this->isValidConnectionString($connection)) {
            return false;
        }

        foreach($this->testingSites as $site) {
            try {
                Http::withOptions([
                    'proxy' => $connection,
                    'timeout' => $this->timeout
                ])->throw()->head($site);
            }
            catch(Exception) {
                return false;
            }
        }

        return true;
    }

    /**
     * @param Proxy $proxy
     * @return bool
     */
    public function isUnique(Proxy $proxy): bool
    {
        return Proxy::where(static function(Builder $builder) use ($proxy): void {
            $builder
                ->where('ip', $proxy->ip)
                ->where('port', $proxy->port);

            if($proxy->id !== null) {
                $builder->where('id', '!=', $proxy->id);
            }
        })->doesntExists();
    }

    /**
     * @param string $connection
     * @return bool
     */
    public function isValidConnectionString(string $connection): bool
    {
        return preg_match($this->regexp, $connection);
    }

    /**
     * @param string $connection
     * @return array
     */
    public function toArray(string $connection): array
    {
        preg_match($this->regexp, $connection, $matches);

        return [
            'protocol' => $matches[1],
            'ip' => $matches[4],
            'port' => $matches[5],
            'user' => $matches[2] ?: null,
            'password' => $matches[3] ?: null
        ];
    }

    /**
     * @return Collection|Proxy[]
     */
    public function all(): Collection
    {
        return $this->cache->remember(
            'proxies', 60 * 60 * 24,
            static fn(): Collection => Proxy::where('is_active', 1)->get()
        );
    }

    /**
     * @return bool
     */
    public function flush(): bool
    {
        return $this->cache->forget('proxies');
    }

    /**
     * @param int|null $lockTime
     * @return Proxy|null
     */
    public function get(?int $lockTime = null): ?Proxy
    {
        return $this->all()->firstWhere(fn(Proxy $proxy): bool => $this->lock($proxy, $lockTime));
    }

    /**
     * @param Service|string $service
     * @return Proxy|null
     */
    public function service(Service|string $service): ?Proxy
    {
        $service = is_string($service) ? new $service($this) : $service;

        $proxies = $this->all();

        if($proxies->isNotEmpty()) {
            $proxy = $proxies
                ->filter(fn(Proxy $proxy): bool => !$this->isBanned($proxy, $service))
                ->sortBy(fn(Proxy $proxy): int => $this->getLatestUsage($proxy, $service) ?? mt_rand(1, 500), SORT_NUMERIC)
                ->firstWhere(fn(Proxy $proxy): bool => $this->lock($proxy));

            if($proxy) {
                $this->setLatestUsage($proxy, $service);
                $this->increaseDailyUsage($proxy, $service);
                return $proxy;
            }
        }

        return null;
    }

    /**
     * @param Proxy $proxy
     * @param int|null $lockTime
     * @return bool
     */
    public function lock(Proxy $proxy, ?int $lockTime = null): bool
    {
        return $this->cache->lock("proxies_locked_{$proxy->id}", $lockTime ?? $this->lockTime)->get();
    }

    /**
     * @param Proxy $proxy
     * @return void
     */
    public function release(Proxy $proxy): void
    {
        $this->cache->lock("proxies_locked_{$proxy->id}", $lockTime ?? $this->lockTime)->forceRelease();
    }

    /**
     * @param Proxy $proxy
     * @param Service|string $service
     * @param int|null $banTime
     * @return void
     */
    public function ban(Proxy $proxy, Service|string $service, ?int $banTime = null): void
    {
        $service = is_string($service) ? $service : get_class($service);
        $this->cache->put("proxies_banned_{$service}_{$proxy->id}", 1, $banTime ?? $this->banTime);
    }

    /**
     * @param Proxy $proxy
     * @param Service|string $service
     * @param int|null $delay
     * @return bool
     */
    public function unban(Proxy $proxy, Service|string $service, ?int $delay = null): bool
    {
        $service = is_string($service) ? $service : get_class($service);

        if($delay !== null) {
            if($this->isBanned($proxy, $service)) {
                $this->cache->put("proxies_banned_{$service}_{$proxy->id}", 1, $delay);
            }

            return true;
        }

        return $this->cache->forget("proxies_banned_{$service}_{$proxy->id}");
    }

    /**
     * @param Proxy $proxy
     * @param Service|string $service
     * @return bool
     */
    public function isBanned(Proxy $proxy, Service|string $service): bool
    {
        $service = is_string($service) ? new $service($this) : $service;
        $serviceName = get_class($service);

        try {
            return $this->cache->has("proxies_banned_{$serviceName}_{$proxy->id}")
                && (!$service->getDailyLimit() || $service->getDailyLimit() > $this->getDailyUsage($proxy, $service));
        }
        catch(InvalidArgumentException) {
            return true;
        }
    }

    /**
     * @param Proxy $proxy
     * @param Exception|null $exception
     * @return void
     */
    public function onErrorDisable(Proxy $proxy, ?Exception $exception = null): void
    {
        if($exception === null || Str::contains($exception->getMessage(), 'cURL error')) {
            $this->cache->increment("proxies_error_count_{$proxy->id}");
            /*$count = $this->cache->increment("proxies_error_count_{$proxy->id}");

            if($count >= $this->limitErrors) {
                $proxy->is_active = 0;
                $proxy->save();

                $this->cache->forget("proxies_error_count_{$proxy->id}");
                $this->flush();
            }*/
        }
    }

    /**
     * @param Proxy $proxy
     * @return int
     */
    public function getErrorsCount(Proxy $proxy): int
    {
        try {
            return $this->cache->get("proxies_error_count_{$proxy->id}") ?? 0;
        }
        catch(InvalidArgumentException) {
            return 0;
        }
    }

    /**
     * @param Proxy $proxy
     * @return bool
     */
    public function hasTooManyErrors(Proxy $proxy): bool
    {
        return $this->getErrorsCount($proxy) >= $this->limitErrors;
    }

    /**
     * @param Proxy $proxy
     * @return void
     */
    public function lockForEnabling(Proxy $proxy): void
    {
        $this->cache->put("proxies_enabling_locked_{$proxy->id}", 1, 60 * 60);
        $this->cache->forget("proxies_error_count_{$proxy->id}");
    }

    /**
     * @param Proxy $proxy
     * @return bool
     */
    public function hasLockedEnabling(Proxy $proxy): bool
    {
        try {
            return $this->cache->has("proxies_enabling_locked_{$proxy->id}");
        }
        catch(InvalidArgumentException) {
            return false;
        }
    }

    /**
     * @param Proxy $proxy
     * @param Service|string $service
     * @return void
     */
    public function setLatestUsage(Proxy $proxy, Service|string $service): void
    {
        $service = is_string($service) ? $service : get_class($service);
        $this->cache->put("proxies_latest_usage_{$service}_{$proxy->id}", Carbon::now()->getTimestamp(), 60 * 12);
    }

    /**
     * @param Proxy $proxy
     * @param Service|string $service
     * @return int|null
     */
    public function getLatestUsage(Proxy $proxy, Service|string $service): ?int
    {
        $service = is_string($service) ? $service : get_class($service);

        try {
            return $this->cache->get("proxies_latest_usage_{$service}_{$proxy->id}");
        }
        catch(InvalidArgumentException) {
            return 0;
        }
    }

    /**
     * @param Proxy $proxy
     * @param Service|string $service
     * @return int
     * @throws InvalidArgumentException
     */
    public function getDailyUsage(Proxy $proxy, Service|string $service): int
    {
        $service = is_string($service) ? $service : get_class($service);
        return $this->cache->get(Carbon::now()->format('Ymd')."proxies_daily_usage_{$service}_{$proxy->id}") ?? 0;
    }

    /**
     * @return int
     * @throws Exception
     */
    public function getRecommendCount(): int
    {
        $currencyBuilder = new CurrencyBuilder;
        $ethereum = new Ethereum;

        $count = count($currencyBuilder->allEnabled()) * 10;

        if($ethereum->isEnabled()) {
            $browser = new SeleniumBrowser;

            $count -= 10;

            $factor = max($ethereum->isDeBankEnabled() ? 6 : 0, $ethereum->isZapperEnabled() ? 10 : 0);
            $factor += $ethereum->isZerionEnabled() ? 2 : 0;

            $count += $factor * count($browser->queues());
        }

        return max($count, 20);
    }

    /**
     * @param Proxy $proxy
     * @param Service $service
     * @return void
     */
    protected function increaseDailyUsage(Proxy $proxy, Service $service): void
    {
        $serviceName = get_class($service);
        $this->cache->increment(Carbon::now()->format('Ymd')."proxies_daily_usage_{$serviceName}_{$proxy->id}");
    }
}

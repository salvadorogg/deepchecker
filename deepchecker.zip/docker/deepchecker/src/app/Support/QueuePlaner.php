<?php

namespace App\Support;

use App\Models\Wallet;
use App\Support\Currency\Currency;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;

/**
 * Class QueuePlaner
 */
class QueuePlaner
{
    public const STATE_AWAITING = 0;
    public const STATE_WORK = 1;
    public const STATE_SLEEP = 3;
    public const STATE_RESTART = 4;
    public const STATE_ERROR = 5;
    public const STATE_MEMORY_LIMIT = 6;
    public const STATE_AWAITING_PROXY = 7;

    public const CURRENCY_PARSE_GROUP = 'currency_parse';
    public const CURRENCY_ETHEREUM_GROUP = 'ethereum_browser_parse';
    public const WALLET_ADDRESSES_GROUP = 'addresses_parse';

    protected array $queues;

    /**
     * QueuePlaner constructor
     */
    public function __construct(
        protected ?string $queueName = null,
        protected ?string $lockName = null
    )
    {
        $this->queues = array_merge(
            $this->getCurrencyParseWorkers(),
            $this->getCurrencyEthereumWorkers(),
            $this->getWalletAddressesWorkers()
        );
    }

    public function restart(): void
    {
        foreach($this->queues as $queue) {
            Cache::put($queue['name'].'_restart_planned', 1, 60 * 60 * 24);
        }
    }

    /**
     * @param ?string $queue
     * @return bool
     */
    public function isNeedleRestart(?string $queue = null): bool
    {
        $queue ??= $this->queueName;

        $needle = Cache::has($queue.'_restart_planned');
        $needle && Cache::forget($queue.'_restart_planned');

        return $needle;
    }

    /**
     * @return Collection
     */
    public function all(): Collection
    {
        return new Collection($this->queues);
    }

    /**
     * @param int $state
     * @param string|null $queue
     * @return void
     */
    public function setCurrentState(int $state, ?string $queue = null): void
    {
        $queue ??= $this->queueName;

        Cache::put($queue.'_state', $state, 60 * 60 * 24);
    }

    /**
     * @param string|null $queue
     * @return int|null
     */
    public function getCurrentState(?string $queue = null): ?int
    {
        $queue ??= $this->queueName;

        return Cache::get($queue.'_state');
    }

    /**
     * @param int|float $timer
     * @param int $awaitingCount
     * @param string|null $queue
     * @return void
     */
    public function putStatistic(int|float $timer, int $awaitingCount, ?string $queue = null): void
    {
        $queue ??= $this->queueName;

        $statistic = $this->getStatistic($queue);
        $timers = Collection::make($statistic['timers'] ?? [])->reverse()->take(25)->reverse()->add($timer)->all();

        Cache::put($queue.'_statistic', [
            'timers' => $timers,
            'latest_time' => Carbon::now(),
            'awaiting_count' => $awaitingCount
        ], 60 * 60 * 24);
    }

    /**
     * @param string|null $queue
     * @return array|null
     */
    public function getStatistic(?string $queue = null): ?array
    {
        $queue ??= $this->queueName;

        return Cache::get($queue.'_statistic');
    }

    /**
     * @return Collection
     */
    public function getAllStatistic(): Collection
    {
        $queues = [];

        foreach($this->all() as $queue) {
            $state = $this->getCurrentState($queue['name']);

            if($state === null) {
                continue;
            }

            $statistic = [
                'name' => $queue['name'],
                'group' => $queue['group'],
                'state' => $state,
                'latest_time' => null,
                'timer' => null,
                'awaiting_count' => 0
            ];

            $latest = $this->getStatistic($queue['name']);

            if($latest) {
                $statistic['latest_time'] = $latest['latest_time'];
                $statistic['timer'] = round(array_sum($latest['timers']) / count($latest['timers']), 2, PHP_ROUND_HALF_EVEN);
                $statistic['awaiting_count'] = $latest['awaiting_count'];
            }

            $queues[] = $statistic;
        }

        return new Collection($queues);
    }

    /**
     * @param string|null $lockName
     * @return array
     */
    public function getLockedWallets(?string $lockName = null): array
    {
        $lockName ??= $this->lockName;

        while(true) {
            $lock = Cache::lock("{$lockName}_locker", 60 * 10);

            if($lock->get()) {
                $list = Cache::get("{$lockName}_list") ?? [];

                $lock->release();

                return array_values($list);
            }

            usleep(500000);
        }
    }

    /**
     * @param Wallet $wallet
     * @param int $seconds
     * @param string|null $queueName
     * @param string|null $lockName
     * @return bool
     */
    public function lockWallet(Wallet $wallet, int $seconds = 60 * 10, ?string $queueName = null, ?string $lockName = null): bool
    {
        $lockName ??= $this->lockName;
        $queueName ??= $this->queueName;

        while(true) {
            $lock = Cache::lock("{$lockName}_locker", 60 * 10);

            if($lock->get()) {
                $walletLock = Cache::lock("{$lockName}_wallet_{$wallet->id}", $seconds);

                if($walletLock->get()) {
                    $list = Cache::get("{$lockName}_list") ?? [];
                    $list[$queueName] = $wallet->id;

                    Cache::put("{$lockName}_list", $list, 60 * 10);

                    $lock->release();

                    return true;
                }

                $lock->release();

                return false;
            }

            usleep(500000);
        }
    }

    /**
     * @param Wallet|int $wallet
     * @param string|null $queueName
     * @param string|null $lockName
     * @return void
     */
    public function unlockWallet(Wallet|int $wallet, ?string $queueName = null, ?string $lockName = null): void
    {
        $lockName ??= $this->lockName;
        $queueName ??= $this->queueName;

        while(true) {
            $lock = Cache::lock("{$lockName}_locker", 60 * 10);

            if($lock->get()) {
                $list = Cache::get("{$lockName}_list") ?? [];

                if(isset($list[$queueName])) {
                    unset($list[$queueName]);
                }

                $wallet = $wallet instanceof Wallet ? $wallet->id : $wallet;

                Cache::put("{$lockName}_list", $list, 60 * 10);
                Cache::lock("{$lockName}_wallet_{$wallet}")->forceRelease();

                $lock->release();

                return;
            }

            usleep(500000);
        }
    }

    /**
     * @param Builder $builder
     * @param int $limit
     * @param string|null $queueName
     * @param string|null $lockName
     * @return Collection|Wallet[]
     */
    public function getWalletsWithLockWorker(Builder $builder, int $limit = 1, ?string $queueName = null, ?string $lockName = null): Collection
    {
        $lockName ??= $this->lockName;
        $queueName ??= $this->queueName;

        while(true) {
            $lock = Cache::lock("{$lockName}_locker", 60 * 10);

            if($lock->get()) {
                $lockedWallets = Cache::get("{$lockName}_current_wallets") ?? [];

                if($lockedWallets[$queueName] ?? false) {
                    unset($lockedWallets[$queueName]);
                }

                $lockedWalletsIds = array_merge(...array_values($lockedWallets));

                $collection = $builder->whereNotIn('id', $lockedWalletsIds)->limit($limit)->get();

                $lockedWallets[$queueName] = $collection->pluck('id')->all();

                Cache::put("{$lockName}_current_wallets", $lockedWallets, 60 * 24);

                $lock->release();

                return $collection;
            }

            usleep(500000);
        }
    }

    /**
     * @param string|null $queueName
     * @param string|null $lockName
     * @return bool
     */
    public function unlockWalletsWithLockWorker(?string $queueName = null, ?string $lockName = null): bool
    {
        $lockName ??= $this->lockName;
        $queueName ??= $this->queueName;

        while(true) {
            $lock = Cache::lock("{$lockName}_locker", 60 * 10);

            if($lock->get()) {
                $lockedWallets = Cache::get("{$lockName}_current_wallets") ?? [];

                if($lockedWallets[$queueName] ?? false) {
                    unset($lockedWallets[$queueName]);
                }

                Cache::put("{$lockName}_current_wallets", $lockedWallets, 60 * 24);

                $lock->release();

                return true;
            }

            usleep(500000);
        }
    }

    /**
     * @return array
     */
    public function getCurrencyParseWorkers(): array
    {
        return array_map(
            static fn(Currency $currency): array => [
                'name' => 'queue_currency_parse_'.$currency->getSlug(),
                'group' => self::CURRENCY_PARSE_GROUP
            ],
            (new CurrencyBuilder)->all()
        );
    }

    /**
     * @return array
     */
    public function getWalletAddressesWorkers(): array
    {
        $data = [];

        for($i = 1; $i <= 7; $i++) {
            $data[] = [
                'name' => 'queue_addresses_parse_'.$i,
                'group' => self::WALLET_ADDRESSES_GROUP
            ];
        }

        return $data;
    }

    /**
     * @return array
     */
    public function getCurrencyEthereumWorkers(): array
    {
        $data = [];

        foreach((new SeleniumBrowser)->queues() as $queue) {
            $data[] = [
                'name' => 'puppeteer_parser_'.$queue,
                'group' => self::CURRENCY_ETHEREUM_GROUP
            ];
        }

        return $data;
    }
}

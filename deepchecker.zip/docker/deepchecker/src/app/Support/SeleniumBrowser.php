<?php

namespace App\Support;

use Facebook\WebDriver\Chrome\ChromeOptions;
use Facebook\WebDriver\Remote\DesiredCapabilities;
use Facebook\WebDriver\Remote\RemoteWebDriver;
use Illuminate\Support\Facades\Cache;

/**
 * Class SeleniumBrowser
 */
class SeleniumBrowser
{
    public const STATE_AWAITING = 1;
    public const STATE_SLEEP = 2;
    public const STATE_WORK = 3;
    public const STATE_ERROR = 4;
    public const STATE_RESTART = 5;
    public const STATE_MEMORY_LIMIT = 6;

    protected string $server = 'http://chrome:4444/wd/hub';

    /**
     * @return RemoteWebDriver
     */
    public function driver(): RemoteWebDriver
    {
        return RemoteWebDriver::create($this->server, $this->capabilities());
    }

    /**
     * @param array $extensions
     * @return RemoteWebDriver
     */
    public function driverWithExtensions(array $extensions): RemoteWebDriver
    {
        $options = $this->options();
        $options->addExtensions($extensions);

        return RemoteWebDriver::create($this->server, $this->capabilities($options));
    }

    /**
     * @return ChromeOptions
     */
    public function options(): ChromeOptions
    {
        $options = new ChromeOptions();
        $options->addArguments([
            '-headless=chrome',
            //'--incognito',
            //'--disable-gpu',
            '--user-agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36"',
            '--disable-blink-features=AutomationControlled',
            //'----disable-dev-shm-usage'
        ]);
        $options->setExperimentalOption('excludeSwitches', ['enable-automation']);
        $options->setExperimentalOption('useAutomationExtension', false);
        //$options->setExperimentalOption('w3c', false);

        return $options;
    }

    /**
     * @param ChromeOptions|null $options
     * @return DesiredCapabilities
     */
    public function capabilities(?ChromeOptions $options = null): DesiredCapabilities
    {
        $desiredCapabilities = DesiredCapabilities::chrome();
        $desiredCapabilities->setCapability(ChromeOptions::CAPABILITY, $options ?? $this->options());
        /*$desiredCapabilities->setCapability('w3c', false);
        $desiredCapabilities->setCapability('goog:loggingPrefs', ['performance' => 'INFO']);
        $desiredCapabilities->setCapability('goog:chromeOptions', ['perfLoggingPrefs' => ['enableNetwork' => true]]);*/

        return $desiredCapabilities;
    }

    /**
     * @param string $queue
     * @param int $state
     * @return void
     */
    public function setCurrentState(string $queue, int $state): void
    {
        Cache::put($queue.'_state', $state, 60 * 24);
    }

    /**
     * @return array
     */
    public function queues(): array
    {
        return range(1, 12);
    }

    /**
     * @param string $queue
     * @return int|null
     */
    public function getCurrentState(string $queue): ?int
    {
        return Cache::get($queue.'_state');
    }

    /**
     * @return array
     */
    public function getCurrentStates(): array
    {
        $states = [];

        foreach($this->queues() as $queue) {
            $states[$queue] = $this->getCurrentState('selenium_browser_'.$queue);
        }

        return $states;
    }

    /**
     * @param int $queue
     * @return bool
     */
    public function itWorkerCanStart(int $queue): bool
    {
        $server = new Server;
        $totalMemory = $server->getMemory('MemTotal');
        $totalCPUNumbers = $server->getCPUNumbers();

        return match(true) {
            $queue > 9 => $totalCPUNumbers >= 6 && $totalMemory >= 6000,
            default => $totalCPUNumbers >= 4 && $totalMemory >= 4000
        };
    }

    /**
     * @param int $queue
     * @return bool
     */
    public function itWorkerRequiredSleep(int $queue): bool
    {
        $planer = new QueuePlaner;

        foreach($planer->all() as $queue) {
            if($queue['group'] === QueuePlaner::WALLET_ADDRESSES_GROUP && $planer->getCurrentState($queue['name']) === QueuePlaner::STATE_WORK) {
                return true;
            }
        }

        return false;
    }
}


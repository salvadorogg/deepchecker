<?php

namespace App\Support;

use Illuminate\Support\Collection;

/**
 * Class Server
 */
class Server
{
    /**
     * @param string|null $name
     * @return array|string
     */
    public function getMemory(?string $name = null): array|string
    {
        $contents = file_get_contents('/proc/meminfo');
        preg_match_all('/(\w+):\s+(\d+)\s/', $contents, $matches);

        $data = array_combine($matches[1], $matches[2]);

        return $name === null
            ? array_map(fn(int $amount): int => $this->convertKbToMb($amount), $data)
            : $this->convertKbToMb($data[$name]);
    }

    /**
     * @return int
     */
    public function getCPUNumbers(): int
    {
        return (int) shell_exec('nproc');
    }

    /**
     * @return bool
     */
    public function isOptimalConfiguration(): bool
    {
        return $this->getCPUNumbers() >= 6 && $this->getMemory('MemTotal') >= 6000;
    }

    /**
     * @param int $amount
     * @return int
     */
    protected function convertKbToMb(int $amount): int
    {
        return $amount > 0 ? (int) round($amount / 1000, mode: PHP_ROUND_HALF_EVEN) : 0;
    }
}

<?php

namespace App\Support\Services;

use App\Exceptions\ZeroFreeProxiesExceptions;
use App\Support\Currency\Currency;
use App\Support\Proxy;
use App\Support\QueuePlaner;
use Exception;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Class Blockchair
 */
class Blockchair extends Service
{
    protected string $name = 'Blockchair API';

    /**
     * @param string $block
     * @param array $addresses
     * @return array
     * @throws ZeroFreeProxiesExceptions
     */
    public function getBalances(string $block, array $addresses): array
    {
        $result = [];

        Collection::make($addresses)
            ->shuffle()->chunk(50)
            ->each(function(Collection $collection) use (&$result, $block): void {
                while(true) {
                    $options = [];
                    $query = ['addresses' => $collection->implode(',')];

                    if(!Config::has('autoload.blockchair_api_key')) {
                        $proxy = $this->getProxy();

                        if(!$proxy) {
                            throw new ZeroFreeProxiesExceptions;
                        }

                        $options = $this->getHttpOptions($proxy);
                    }
                    else {
                        $query['key'] = Config::get('autoload.blockchair_api_key');
                    }

                    try {
                        $response = Http::withOptions($options)->get("https://api.blockchair.com/{$block}/addresses/balances", $query);

                        if(isset($proxy)) {
                            $this->proxyBus->release($proxy);
                        }

                        if(!$response->successful()) {
                            $status = $response->json('context.code') ?? $response->status();

                            Log::error('Blockchair error', ['response' => Str::limit($response->body(), 512)]);

                            if(in_array($status, [500, 503])) {
                                sleep(30);
                            }

                            if(in_array($status, [402, 429, 430]) && isset($proxy)) {
                                $this->proxyBus->ban($proxy, $this, 60 * 30);
                            }

                            continue;
                        }

                        $data = $response->json('data') ?? [];

                        foreach($collection as $address) {
                            $result[$address] = $data[$address] ?? 0;
                        }

                        return;
                    }
                    catch(Exception $exception) {
                        Log::error('Blockchair error', ['message' => $exception->getMessage()]);

                        if(isset($proxy)) {
                            $this->proxyBus->onErrorDisable($proxy, $exception);
                        }
                    }
                }
            });

        return $result;
    }
}

<?php

namespace App\Support\Services;

use Carbon\Carbon;
use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

/**
 * Class CoinCodex
 */
class CoinCodex extends Service
{
    /**
     * @param string $currency
     * @return int|float
     */
    public function getLastPriceInUsd(string $currency): int|float
    {
        $currency = Str::upper($currency);

        return Cache::remember(
            "coincodex_{$currency}_to_usd", 60 * 10,
            static function() use ($currency): int|float {
                try {
                    return Http::get("https://coincodex.com/api/coincodex/get_coin/{$currency}/")->throw()->json('last_price_usd');
                }
                catch(RequestException) {
                    return 1;
                }
            }
        );
    }
}

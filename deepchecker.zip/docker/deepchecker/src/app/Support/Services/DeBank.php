<?php

namespace App\Support\Services;

/**
 * Class DeBank
 */
class DeBank extends Service {}

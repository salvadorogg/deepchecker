<?php

namespace App\Support\Services;

use App\Exceptions\ZeroFreeProxiesExceptions;
use App\Models\Wallet;
use App\Support\Currency\Currency;
use App\Support\FakeHumanRequest;
use App\Support\Proxy;
use App\Support\QueuePlaner;
use Carbon\Carbon;
use Exception;
use Facebook\WebDriver\Cookie;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Class DeBankAPI
 */
class DeBankAPI extends Service
{
    protected string $name = 'DeBank API';

    use FakeHumanRequest;

    /**
     * @param array $addresses
     * @return array
     * @throws Exception
     */
    public function getResults(array $addresses): array
    {
        $result = [];

        foreach($addresses as $address) {
            while(true) {
                $proxy = $this->getProxy();

                if(!$proxy) {
                    throw new ZeroFreeProxiesExceptions;
                }

                $options = $this->getHttpOptions($proxy);

                try {
                    $response = Http::asJson()
                        ->withOptions($options)
                        ->get('https://api.debank.com/user/addr', ['addr' => $address]);
                }
                catch(Exception $exception) {
                    $this->proxyBus->onErrorDisable($proxy, $exception);
                    $this->proxyBus->release($proxy);
                    Log::error('DeBank error', ['message' => $exception->getMessage()]);
                    continue;
                }

                $this->proxyBus->release($proxy);

                if(!$response->successful()) {
                    if($response->status() === 429) {
                        $this->proxyBus->ban($proxy, $this);
                    }

                    Log::error('DeBank error', ['response' => Str::limit($response->body(), 512)]);
                    continue;
                }

                $value = $response->json('data.usd_value') ?? 0;
                $result[$address] = is_numeric($value) ? $this->round($value) : 0;
            }
        }

        return $result;
    }
}

<?php

namespace App\Support\Services;

use App\Models\Proxy;
use App\Support\ProxyBus;
use Illuminate\Support\Facades\App;

/**
 * Class Service
 */
abstract class Service
{
    protected ProxyBus $proxyBus;

    protected int $timeout = 5;

    /**
     * @param ProxyBus|null $proxyBus
     */
    public function __construct(?ProxyBus $proxyBus = null)
    {
        $this->proxyBus = $proxyBus ?? App::make(ProxyBus::class);
    }

    /**
     * @return string
     */
    public function getName(): string
    {
        return property_exists($this, 'name') ? $this->name : class_basename($this);
    }

    /**
     * @param Proxy $proxy
     * @return array|null
     */
    public function getHttpOptions(Proxy $proxy): ?array
    {
        return [
            'proxy' => $proxy->toConnectionString(),
            'timeout' => $this->timeout
        ];
    }

    /**
     * @return Proxy|null
     */
    public function getProxy(): ?Proxy
    {
        $sleep = 2500000;

        for($i = 0; $i < 25; $i++) {
            $proxy = $this->proxyBus->service($this);

            if($proxy) {
                return $proxy;
            }

            usleep($sleep);

            if($sleep < 60000000) {
                $sleep += 500000;
            }
        }

        return null;
    }

    /**
     * @return int
     */
    public function getDailyLimit(): int
    {
        return property_exists($this, 'dailyLimit') ? $this->dailyLimit : 0;
    }

    /**
     * @return ProxyBus
     */
    public function proxyBus(): ProxyBus
    {
        return $this->proxyBus;
    }

    /**
     * @param int|float $value
     * @return int
     */
    protected function round(int|float $value): int
    {
        return (int) round($value, mode: PHP_ROUND_HALF_EVEN);
    }
}

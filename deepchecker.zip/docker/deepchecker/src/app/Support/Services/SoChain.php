<?php

namespace App\Support\Services;

use App\Exceptions\ZeroFreeProxiesExceptions;
use App\Support\Currency\Currency;
use App\Support\Proxy;
use App\Support\QueuePlaner;
use Exception;
use Carbon\Carbon;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

/**
 * Class SoChain
 */
class SoChain extends Service
{
    public const DEFAULT_CURRENCY = 'USD';

    protected int $delay = 2;

    /**
     * @param string $from
     * @param string $to
     * @return int|float
     */
    public function getExchangeRate(string $from, string $to = self::DEFAULT_CURRENCY): int|float
    {
        return Cache::remember("so_chain_{$from}_{$to}", Carbon::now()->addMinutes(10), static function() use ($from, $to): int|float {
            $response = Http::get("https://sochain.com/api/v2/get_price/{$from}/$to");

            if(!$response->successful()) {
                return 1;
            }

            $json = $response->json();

            return $json['data']['prices'][0]['price'] ?? 1;
        });
    }

    /**
     * @param string $name
     * @param array $addresses
     * @return array
     * @throws ZeroFreeProxiesExceptions
     */
    public function getBalances(string $name, array $addresses): array
    {
        $result = [];

        foreach($addresses as $address) {
            while(true) {
                $proxy = $this->getProxy();

                if(!$proxy) {
                    throw new ZeroFreeProxiesExceptions;
                }

                $options = $this->getHttpOptions($proxy);

                try {
                    $response = Http::withOptions($options)->get("https://chain.so/api/v2/get_address_balance/{$name}/{$address}");
                }
                catch(Exception $exception) {
                    Log::error('SoChain error', ['message' => $exception->getMessage()]);
                    $this->proxyBus->onErrorDisable($proxy, $exception);
                    continue;
                }

                $this->proxyBus->release($proxy);

                if(!$response->successful()) {
                    if(in_array($response->status(), [500, 503])) {
                        sleep(10);
                        continue;
                    }

                    Log::info('SoChain error', ['response' => Str::limit($response->body(), 512)]);
                }

                $result[$address] = $response->json('data.confirmed_balance') ?? 0;
                break;
            }
        }

        return $result;
    }
}

<?php

namespace App\Support\Services;

/**
 * Class SolanaRPC
 */
class SolanaRPC extends Service {}

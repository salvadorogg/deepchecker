<?php

namespace App\Support\Services;

/**
 * Class Tronscan
 */
class Tronscan extends Service {}

<?php

namespace App\Support\Services;

/**
 * Class Zapper
 */
class Zapper extends Service
{
    protected int $dailyLimit = 1500;
}

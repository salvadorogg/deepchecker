<?php

namespace App\Support\Services;

/**
 * Class Zerion
 */
class Zerion extends Service
{
    protected int $dailyLimit = 75000;
}

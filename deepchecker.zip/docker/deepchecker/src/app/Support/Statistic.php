<?php

namespace App\Support;

use App\Models\User;
use App\Models\Wallet;
use Carbon\Carbon;
use Illuminate\Support\Facades\Cache;

/**
 * Class Statistic
 */
class Statistic
{
    public const ADDRESSES_KEY = 'addresses';
    public const PARSE_KEY = 'parser';

    protected QueuePlaner $planer;

    /**
     * Statistic constructor
     */
    public function __construct()
    {
        $this->planer = new QueuePlaner;
    }

    /**
     * @return int
     */
    public function get(): int
    {
        return 0;

        $execAddressesTime = Cache::get('statistic_timer_'.self::ADDRESSES_KEY);
        $execParseTime = Cache::get('statistic_timer_'.self::PARSE_KEY);

        $callback = static function() use ($execAddressesTime, $execParseTime): int {
            $addressesLength = Wallet::whereNull('addresses')->selectRaw('count(id) as aggregate')->get()->first()->aggregate;
            $parseLength = Wallet::whereIsNeedCheck()->selectRaw('count(id) as aggregate')->get()->first()->aggregate;

            return intval(
                (($execAddressesTime * $addressesLength / 10) + ($execParseTime * $parseLength / 5)) / 60
            );
        };

        return $this->isTooManyWallets()
            ? Cache::remember('statistic_timer_left', Carbon::now()->addMinutes(5), $callback)
            : $callback();
    }

    /**
     * @param User|null $user
     * @return bool
     */
    public function isTooManyWallets(?User $user = null): bool
    {
        return $this->walletsCount($user) >= 50000;
    }

    /**
     * @param User|null $user
     * @return int
     */
    public function walletsCount(?User $user = null): int
    {
        return Cache::remember(
            !$user || $user->is_admin ? 'wallets_count' : 'wallets_count_'.$user->id, Carbon::now()->addHour(),
            static fn(): int => !$user || $user->is_admin
                ? Wallet::selectRaw('count(id) as aggregate')->get()->first()->aggregate
                : $user->wallets()->selectRaw('count(id) as aggregate')->get()->first()->aggregate
        );
    }
}

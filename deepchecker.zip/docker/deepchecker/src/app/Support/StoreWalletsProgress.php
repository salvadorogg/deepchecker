<?php

namespace App\Support;

use Carbon\Carbon;
use Illuminate\Cache\TaggedCache;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Psr\SimpleCache\InvalidArgumentException;

/**
 * Class StoreWalletsProgress
 */
class StoreWalletsProgress
{
    public const STATUS_PREPARING = 1;
    public const STATUS_CREATING = 2;
    public const STATUS_READY = 3;

    /**
     * @param Request $request
     * @param string $id
     */
    public function __construct(
        protected Request $request,
        protected string $id
    ) {}

    /**
     * @param int $total
     * @return void
     * @throws InvalidArgumentException
     */
    public function setTotal(int $total): void
    {
        $this->cache()->put('total', $total, $this->storeCacheTtl());
    }

    /**
     * @param int $current
     * @return void
     * @throws InvalidArgumentException
     */
    public function setCurrentProgress(int $current): void
    {
        $this->cache()->put('current', $current, $this->storeCacheTtl());
    }

    /**
     * @param int $status
     * @return void
     * @throws InvalidArgumentException
     */
    public function setStatus(int $status): void
    {
        $this->cache()->put('status', $status, $this->storeCacheTtl());
    }

    /**
     * @return array
     */
    public function getProgress(): array
    {
        $status = $this->cache()->get('status');
        $total = $this->cache()->get('total') ?? 0;
        $current = $this->cache()->get('current') ?? 0;
        $ready = $status == self::STATUS_READY;

        switch($status) {
            case self::STATUS_CREATING:
            case self::STATUS_PREPARING:
                $status = __("wallet.progress.status.{$status}", compact('total', 'current'));
                $progress = $total && $current ? intval(100 / ($total / $current)) : 0;
                break;
            default:
                $status = __("wallet.progress.status.{$status}", compact('current'));
                $progress = 100;
        }

        return compact('status', 'progress', 'ready');
    }

    /**
     * @return TaggedCache
     */
    protected function cache(): TaggedCache
    {
        return Cache::tags($this->request->user()->id, $this->id);
    }

    /**
     * @return int
     */
    protected function storeCacheTtl(): int
    {
        return 7200;
    }
}

<?php

namespace App\Support\TelegramBot;

use App\Models\User;
use App\Support\TelegramBot\Commands\PairCommand;
use Carbon\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;
use Longman\TelegramBot\Exception\TelegramException;
use Longman\TelegramBot\Request;
use Longman\TelegramBot\Telegram;

/**
 * Class Loader
 * @package App\Support\TelegramBot
 * @mixin Telegram
 * @mixin Request
 */
class Loader
{
    protected array $commands = [
        PairCommand::class
    ];

    protected bool $requestLoaded = false;

    protected ?Telegram $telegram = null;

    /**
     * @throws TelegramException
     */
    public function __construct()
    {
        if(Config::has('autoload.telegram_api_key') && Config::has('autoload.telegram_bot_name')) {
            $this->telegram = new Telegram(
                Config::get('autoload.telegram_api_key'), Config::get('autoload.telegram_bot_name')
            );
        }
    }

    /**
     * @return void
     */
    public function loadRequestIfNotLoaded(): void
    {
        if($this->telegram !== null && !$this->requestLoaded) {
            Request::initialize($this->telegram);
            $this->requestLoaded = true;
        }
    }

    /**
     * @return Telegram
     */
    public function getTelegram(): Telegram
    {
        return $this->telegram;
    }

    /**
     * @param string $method
     * @param ...$arguments
     * @return mixed
     * @throws TelegramException
     */
    public function makeRequest(string $method, ...$arguments): mixed
    {
        $this->loadRequestIfNotLoaded();

        return $this->isEnabledFeature() ? Request::{$method}(...$arguments) : null;
    }

    /**
     * @param string $name
     * @param array $data
     * @return string
     */
    public function makeView(string $name, array $data = []): string
    {
        return str_replace('<br />', "\n", view($name, $data)->render());
    }

    /**
     * @return void
     */
    public function appendCommands(): void
    {
        foreach($this->commands as $command) {
            $this->telegram->addCommandClass($command);
        }
    }

    /**
     * @return bool
     */
    public function isEnabledFeature(): bool
    {
        return $this->telegram !== null;
    }

    /**
     * @return Collection
     */
    public function sendCopyTo(): Collection
    {
        return Cache::remember(
            'telegram_admins', Carbon::now()->addWeek(),
            static fn(): Collection => User::where('group', User::GROUP_ADMIN)->whereHas('telegrams')->with('telegrams')->get()
        );
    }

    /**
     * @param string $name
     * @param array $arguments
     * @return mixed
     */
    public function __call(string $name, array $arguments): mixed
    {
        return $this?->telegram->{$name}(...$arguments);
    }

    /**
     * @param string $name
     * @param array $arguments
     * @return mixed
     */
    public static function __callStatic(string $name, array $arguments): mixed
    {
        return Request::{$name}(...$arguments);
    }
}

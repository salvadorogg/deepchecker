<?php

namespace App\Support\Worker;

use App\Models\Wallet;
use App\Support\CurrencyBuilder;
use App\Support\Mnemonic;
use App\Support\QueuePlaner;
use Carbon\Carbon;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Str;
use phpseclib\Crypt\DES;

/**
 * Class AddressesWorker
 */
class AddressesWorker extends Worker
{
    protected string $lockerName = 'addresses_parser_locker';

    /**
     * @return void
     */
    public function handle(): void
    {
        if($this->command->argument('queue_id') > 5 && !$this->server->isOptimalConfiguration()) {
            $this->message('not enough resources. worker sleep');
            $this->planer->setCurrentState(QueuePlaner::STATE_MEMORY_LIMIT);
            sleep(3800);
        }

        $walletsBuilder = Wallet::whereNull('addresses');
        $walletsCount = $walletsBuilder->count();

        $this->statistic['awaiting_count'] = 0;
        $this->statistic['total_time'] = 0;

        if(!$walletsCount) {
            $this->planer->setCurrentState(QueuePlaner::STATE_SLEEP);
            sleep(60);
            return;
        }

        $wallets = $this->planer->getWalletsWithLockWorker($walletsBuilder, 5);

        if($wallets->isEmpty()) {
            $this->planer->setCurrentState(QueuePlaner::STATE_AWAITING);
            sleep(5);
            return;
        }

        $currentWalletsAddressesCount = 0;

        $this->start();

        foreach($wallets as $wallet) {
            $this->message("starting parse {$wallet->id}");
            $this->planer->setCurrentState(QueuePlaner::STATE_WORK);

            $mnemonic = new Mnemonic($wallet->mnemonic);

            try {
                $wallet->addresses = $mnemonic->getAllAddresses();
                $wallet->save();
                $this->createResults($wallet);
                $this->message("{$wallet->id} successfully parsed");
            }
            catch(Exception $exception) {
                $this->message($exception->getMessage());
            }

            $currentWalletsAddressesCount += array_sum(
                array_map('count', $wallet->addresses ?? [])
            );
        }

        $this->end();

        Cache::increment(Carbon::now()->format('YmdH').'_checked_total_addresses', $currentWalletsAddressesCount);

        $walletsCount -= $wallets->count();
        $this->statistic['awaiting_count'] = $walletsCount > 25 ? intval($walletsCount * $currentWalletsAddressesCount / 25) : $walletsCount * $currentWalletsAddressesCount;
        $this->statistic['total_time'] = $this->statistic['total_time'] / $currentWalletsAddressesCount;
    }

    /**
     * @param Wallet $wallet
     * @return void
     */
    protected function createResults(Wallet $wallet): void
    {
        foreach($wallet->addresses as $currency => $address) {
            $wallet->results()->create(['currency' => $currency, 'next_check_at' => Carbon::now()]);
        }
    }

    /**
     * @param Wallet $wallet
     * @return void
     */
    protected function saveLockedWallet(Wallet $wallet): void
    {
        Cache::put('addresses_worker_locked_wallet_'.$this->command->argument('queue_id'), $wallet->id, 60);
    }

    /**
     * @return void
     */
    protected function forgotLockedWallet(): void
    {
        Cache::forget('addresses_worker_locked_wallet_'.$this->command->argument('queue_id'));
    }
}

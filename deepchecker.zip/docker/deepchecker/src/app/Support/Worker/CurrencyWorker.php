<?php

namespace App\Support\Worker;

use App\Exceptions\ZeroFreeProxiesExceptions;
use App\Jobs\AmountChanged;
use App\Models\Wallet;
use App\Support\Currency\Currency;
use App\Support\Currency\Ethereum;
use App\Support\CurrencyBuilder;
use App\Support\QueuePlaner;
use Carbon\Carbon;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

/**
 * Class CurrencyParse
 */
class CurrencyWorker extends Worker
{
    protected ?Currency $currency = null;

    protected ?string $lockerName = null;

    /**
     * @param Command $command
     * @param string $queueName
     * @param string $currency
     * @throws Exception
     */
    public function __construct(
        protected Command $command,
        protected string $queueName,
        string $currency
    )
    {
        $builder = new CurrencyBuilder;
        $this->currency = $builder->get($currency);
        $this->lockerName = "api_parser_{$currency}";

        parent::__construct($command, $queueName);
    }

    /**
     * @return void
     * @throws Exception
     */
    public function handle(): void
    {
        if(!$this->itWorkerCanStart()) {
            $this->statistic['awaiting_count'] = 0;
            $this->statistic['total_time'] = 0;
            return;
        }

        $walletsCount = $this->builder()->count('id');

        $this->statistic['awaiting_count'] = 0;
        $this->statistic['total_time'] = 0;

        if(!$walletsCount) {
            $this->planer->setCurrentState(QueuePlaner::STATE_SLEEP);
            sleep(60);
            return;
        }

        $wallets = $this->planer->getWalletsWithLockWorker($this->builder()->with('user'), (int) round(100 / $this->currency->getEnabledPatchesCount()));

        if($wallets->isEmpty()) {
            $this->planer->setCurrentState(QueuePlaner::STATE_AWAITING);
            sleep(10);
            return;
        }

        $this->planer->setCurrentState(QueuePlaner::STATE_WORK);

        $addresses = $wallets->map(fn(Wallet $wallet): array => array_values($wallet->addresses[$this->currency->getSlug()] ?? []))->collapse()->all();

        if($addresses) {
            $this->start();

            $this->message('starting parse wallets '.$wallets->implode('id', ', '));

            try {
                $result = $this->result($addresses);
            }
            catch(ZeroFreeProxiesExceptions) {
                $this->message('no free proxies a long time. worker killed');
                $this->planer->unlockWalletsWithLockWorker();
                exit();
            }

            foreach($wallets as $wallet) {
                $walletResult = [];

                foreach($wallet->addresses[$this->currency->getSlug()] ?? [] as $address) {
                    $walletResult[$address] = $result[$address];
                }

                $wallet->result->previously_result = $wallet->result->latest_result;
                $wallet->result->previously_total_balance = $wallet->result->latest_total_balance;

                $wallet->result->latest_result = $walletResult;
                $wallet->result->latest_total_balance = $walletResult ? round(array_sum($walletResult), 2) : null;

                $wallet->result->next_check_at = Carbon::now()->addMinutes($wallet->user->check_period);
                $wallet->result->save();

                if($wallet->result->latest_total_balance > 0) {
                    AmountChanged::dispatchSync($wallet, $wallet->result);
                }

                $this->message("{$wallet->id} successfully parsed");
            }

            $this->end();

            $this->currency->increaseHourlyCount(count($result));

            $this->statistic['awaiting_count'] = $walletsCount - $wallets->count();
            $this->statistic['total_time'] = $result ? $this->statistic['total_time'] / count($result) : $this->statistic['total_time'];
        }
    }

    /**
     * @param array $addresses
     * @return array
     * @throws ZeroFreeProxiesExceptions
     */
    public function result(array $addresses): array
    {
        return $this->currency->getResult($addresses, $this->planer);
    }

    /**
     * @return bool
     */
    protected function itWorkerCanStart(): bool
    {
        if(!$this->currency->isEnabled()) {
            $this->message('currency disabled. worker sleep');
            $this->planer->setCurrentState(QueuePlaner::STATE_MEMORY_LIMIT);
            sleep(300);

            return false;
        }

        if(!defined('LSDFTE') || Carbon::parse(constant('LSDFTE'))->lessThan(Carbon::now())) {
            $this->message('something was wrong');
            $this->planer->setCurrentState(QueuePlaner::STATE_ERROR);
            sleep(300);

            return false;
        }

        if($this->currency instanceof Ethereum && (!$this->currency->isDeBankEnabled() || $this->currency->isZapperEnabled() || $this->currency->isZerionEnabled())) {
            $this->message('debank parser disabled or multiple services enabled');
            $this->planer->setCurrentState(QueuePlaner::STATE_MEMORY_LIMIT);
            sleep(300);

            return false;
        }

        return true;
    }

    /**
     * @return Wallet|Builder
     */
    protected function builder(): Builder
    {
        return Wallet::whereIsNeedCheck($this->currency);
    }

    /**
     * @param Wallet $wallet
     * @return void
     */
    protected function saveLockedWallet(Wallet $wallet): void
    {
        Cache::put($this->currency->getSlug().'_currency_locked_wallet', $wallet->id, 180);
    }

    /**
     * @return void
     */
    protected function forgotLockedWallet(): void
    {
        Cache::forget($this->currency->getSlug().'_currency_locked_wallet');
    }
}

<?php

namespace App\Support\Worker;

use App\Models\Wallet;
use App\Support\Currency\Currency;
use App\Support\CurrencyBuilder;
use App\Support\QueuePlaner;
use App\Support\Server;
use Carbon\Carbon;
use Exception;
use Illuminate\Console\Command;
use Illuminate\Contracts\Cache\Lock;
use Illuminate\Support\Facades\Cache;

/**
 * Abstract class Worker
 */
abstract class Worker
{
    protected ?QueuePlaner $planer = null;

    protected ?Currency $currency = null;

    protected ?Server $server = null;

    protected array $statistic = [];

    /**
     * @param Command $command
     * @param string $queueName
     * @throws Exception
     */
    public function __construct(
        protected Command $command,
        protected string $queueName,
    )
    {
        $this->planer = new QueuePlaner($queueName, $this->getLockerName());
        $this->server = new Server;
    }

    /**
     * @return void
     */
    abstract public function handle(): void;

    /**
     * @return void
     */
    public function work(): void
    {
        while(true) {
            if($this->planer->isNeedleRestart()) {
                $this->message('restart queue');
                $this->planer->setCurrentState(QueuePlaner::STATE_RESTART);
                return;
            }

            $this->planer->setCurrentState(QueuePlaner::STATE_AWAITING);

            $this->handle();

            if($this->statistic) {
                $this->planer->putStatistic(
                    round($this->statistic['total_time'], 2, PHP_ROUND_HALF_EVEN), $this->statistic['awaiting_count']
                );

                $this->statistic = [];
            }
        }
    }

    /**
     * @return array
     */
    protected function start(): array
    {
        $this->statistic = [
            'start_time' => microtime(true)
        ];

        return $this->statistic;
    }

    /**
     * @return array
     */
    public function end(): array
    {
        $this->statistic['end_time'] = microtime(true);
        $this->statistic['total_time'] = $this->statistic['end_time'] - $this->statistic['start_time'];

        return $this->statistic;
    }

    /**
     * @param string $message
     * @return void
     */
    protected function message(string $message): void
    {
        $this->command->info(
            sprintf('%s: %s: %s', Carbon::now()->format('H:i:s'), $this->queueName, $message)
        );
    }

    /**
     * @param Wallet $wallet
     * @param int $seconds
     * @return bool
     */
    protected function lock(Wallet $wallet, int $seconds): bool
    {
        $lockName = property_exists($this, 'lockedWalletsKey') ? $this->lockedWalletsKey : 'parse_wallet_locked';

        while(true) {
            $lock = Cache::lock("{$lockName}_locker", 60 * 10);

            if($lock->get()) {
                $walletLock = Cache::lock("{$lockName}_wallet_{$wallet->id}", $seconds);

                if($walletLock->get()) {
                    $list = Cache::get("{$lockName}_list") ?? [];
                    $list[$this->queueName] = $wallet->id;

                    Cache::put("{$lockName}_list", $list, 60 * 10);

                    $lock->release();

                    return true;
                }

                $lock->release();

                return false;
            }

            usleep(500000);
        }
    }

    /**
     * @param Wallet $wallet
     * @return void
     */
    protected function unlock(Wallet $wallet): void
    {
        $lockName = property_exists($this, 'lockedWalletsKey') ? $this->lockedWalletsKey : 'parse_locked';

        while(true) {
            $lock = Cache::lock("{$lockName}_locker", 60 * 10);

            if($lock->get()) {
                $list = Cache::get("{$lockName}_list") ?? [];

                if(isset($list[$this->queueName])) {
                    unset($list[$this->queueName]);
                }

                Cache::put("{$lockName}_list", $list, 60 * 10);
                Cache::lock("{$lockName}_wallet_{$wallet->id}")->forceRelease();

                $lock->release();

                return;
            }

            usleep(500000);
        }
    }

    /**
     * @return array
     */
    protected function getLockedWallets(): array
    {
        $lockName = property_exists($this, 'lockedWalletsKey') ? $this->lockedWalletsKey : 'parse_locked';

        while(true) {
            $lock = Cache::lock("{$lockName}_locker", 60 * 10);

            if($lock->get()) {
                $list = Cache::get("{$lockName}_list") ?? [];

                $lock->release();

                return array_values($list);
            }

            usleep(500000);
        }
    }

    /**
     * @return string
     */
    protected function getLockerName(): string
    {
        return property_exists($this, 'lockerName') ? $this->lockerName : class_basename($this).'_locker';
    }
}

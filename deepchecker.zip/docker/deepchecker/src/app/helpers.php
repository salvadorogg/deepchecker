<?php

use Illuminate\Support\Str;

if(!function_exists("array_is_list")) {
    function array_is_list(array $array): bool
    {
        $i = 0;

        foreach($array as $k => $v) {
            if($k !== $i++) {
                return false;
            }
        }

        return true;
    }
}

if(!function_exists('is_not_null')) {
    function is_not_null(mixed $value): bool
    {
        return !is_null($value);
    }
}

/**
 * @param string|int|float $number
 * @return string|int|float
 */
function cut_long_float_number(string|int|float $number): string|int|float
{
    $numberArray = explode('.', $number, 2);
    return Str::length($numberArray[1]) > 12
        ? sprintf('%d.%d', $numberArray[0], Str::limit($numberArray[1], 12, ''))
        : $number;
}

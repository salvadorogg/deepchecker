<?php

use App\Models\Wallet;
use App\Support\Navigation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;

return [
    [
        'type' => Navigation::ITEM_TYPE_LINK,
        'name' => [
            __('Дашборд'),
            static fn(Request $request): int => $request->user()->is_admin ? Cache::remember(
                'wallets_count', 30,
                static fn(): int => Wallet::count()
            ) : $request->user()->wallets()->count()
        ],
        'route' => 'index',
        'icon' => 'fas fa-wallet',
        'aliases' => ['wallets.edit', 'mnemonics.invalid']
    ],

    [
        'type' => Navigation::ITEM_TYPE_LINK,
        'name' => __('Пользователи'),
        'route' => 'users.index',
        'icon' => 'fas fa-users',
        'aliases' => ['users.create', 'users.edit'],
        'gate' => 'view-any'
    ],

    [
        'type' => Navigation::ITEM_TYPE_LINK,
        'name' => [
            __('Прокси'),
            static fn(Request $request): int => \App\Facades\Support\ProxyBus::all()->count()
        ],
        'route' => 'proxies.index',
        'icon' => 'fas fa-network-wired',
        'aliases' => ['proxies.create', 'proxies.edit'],
        'gate' => 'view-any'
    ],

    [
        'type' => Navigation::ITEM_TYPE_LINK,
        'name' => __('Статистика'),
        'route' => 'statistic.show',
        'icon' => 'fas fa-chart-pie',
        'gate' => 'view-any'
    ],

    [
        'type' => Navigation::ITEM_TYPE_LINK,
        'name' => __('Настройки'),
        'route' => 'settings.show',
        'icon' => 'fas fa-cogs'
    ],

    [
        'type' => Navigation::ITEM_TYPE_LINK,
        'name' => __('Поддержка'),
        'route' => 'support',
        'icon' => 'fas fa-life-ring',
        'gate' => 'view-any'
    ],

    [
        'type' => Navigation::ITEM_TYPE_LINK,
        'name' => __('Закончить сеанс'),
        'route' => 'logout',
        'icon' => 'fas fa-sign-out-alt'
    ]
];

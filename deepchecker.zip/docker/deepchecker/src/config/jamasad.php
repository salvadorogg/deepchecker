<?php

return [
    'currencies' => [
        \App\Support\Currency\Bitcoin::class,
        \App\Support\Currency\BitcoinCash::class,
        \App\Support\Currency\Dogecoin::class,
        \App\Support\Currency\Ethereum::class,
        \App\Support\Currency\Litecoin::class,
        \App\Support\Currency\Solana::class,
        \App\Support\Currency\Tron::class
    ],

    'services' => [
        \App\Support\Services\Blockchair::class,
        \App\Support\Services\SoChain::class,
        \App\Support\Services\DeBank::class,
        \App\Support\Services\DeBankAPI::class,
        \App\Support\Services\Zapper::class,
        \App\Support\Services\Zerion::class,
        \App\Support\Services\SolanaRPC::class,
        \App\Support\Services\Tronscan::class
    ],

    'demo_enabled' => env('DEMO_VERSION_ENABLED', false)
];

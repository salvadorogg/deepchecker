<?php

use App\Models\Proxy;

return [
    'type' => [
        Proxy::TYPE_HTTPS => 'HTTPS',
        Proxy::TYPE_SOCKS5 => 'SOCKS5'
    ]
];
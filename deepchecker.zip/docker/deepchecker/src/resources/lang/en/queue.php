<?php

use App\Support\QueuePlaner;

return [
    'state' => [
        QueuePlaner::STATE_WORK => 'Working',
        QueuePlaner::STATE_AWAITING => 'Awaiting',
        QueuePlaner::STATE_SLEEP => 'Sleeping',
        QueuePlaner::STATE_RESTART => 'Restarting',
        QueuePlaner::STATE_ERROR => 'Fatal error',
        QueuePlaner::STATE_MEMORY_LIMIT => 'Blocked',
        QueuePlaner::STATE_AWAITING_PROXY => 'Awaiting proxy',
        'default' => 'Loading...'
    ],

    'name' => [
        'queue_currency_parse_btc' => 'Bitcoin',
        'queue_currency_parse_bch' => 'BitcoinCash',
        'queue_currency_parse_doge' => 'DOGE',
        'queue_currency_parse_eth' => 'Ethereum',
        'queue_currency_parse_ltc' => 'Litecoin',
        'queue_currency_parse_solana' => 'Solana',
        'queue_currency_parse_tron' => 'TRON',
        'queue_addresses_parse_1' => 'Stream 1',
        'queue_addresses_parse_2' => 'Stream 2',
        'queue_addresses_parse_3' => 'Stream 3',
        'queue_addresses_parse_4' => 'Stream 4',
        'queue_addresses_parse_5' => 'Stream 5',
        'queue_addresses_parse_6' => 'Stream 6',
        'queue_addresses_parse_7' => 'Stream 7',
        'puppeteer_parser_1' => 'Stream 1',
        'puppeteer_parser_2' => 'Stream 2',
        'puppeteer_parser_3' => 'Stream 3',
        'puppeteer_parser_4' => 'Stream 4',
        'puppeteer_parser_5' => 'Stream 5',
        'puppeteer_parser_6' => 'Stream 6',
        'puppeteer_parser_7' => 'Stream 7',
        'puppeteer_parser_8' => 'Stream 8',
        'puppeteer_parser_9' => 'Stream 9',
        'puppeteer_parser_10' => 'Stream 10',
        'puppeteer_parser_11' => 'Stream 11',
        'puppeteer_parser_12' => 'Stream 12',
        'puppeteer_parser_13' => 'Stream 14',
        'puppeteer_parser_14' => 'Stream 14',
        'puppeteer_parser_15' => 'Stream 15'
    ],

    'group' => [
        'currency_parse' => 'Currency parsers API',
        'ethereum_browser_parse' => 'Ethereum parsers',
        'addresses_parse' => 'Addresses checkers'
    ]
];

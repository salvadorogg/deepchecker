<?php

use App\Models\User;

return [
    'group' => [
        User::GROUP_ADMIN => 'Administrator',
        User::GROUP_USER => 'User'
    ]
];

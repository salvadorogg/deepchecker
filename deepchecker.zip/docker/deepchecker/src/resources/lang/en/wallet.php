<?php

use App\Support\StoreWalletsProgress;

return [
    'period' => [
        180 => '3 hours',
        360 => '6 hours',
        999999 => 'Turn off recheck'
    ],

    'order' => [
        'direction' => [
            'asc' => 'Ascending',
            'desc' => 'Descending'
        ],

        'field' => [
            'total' => 'Balance',
            'created_at' => 'Creation date',
            'total_btc' => 'Bitcoin balance',
            'total_bch' => 'BitcoinCash balance',
            'total_doge' => 'Dogecoin balance',
            'total_eth' => 'Ethereum balance',
            'total_ltc' => 'Litecoin balance',
            'total_solana' => 'Solana balance',
            'total_tron' => 'Tron balance'
        ]
    ],

    'progress' => [
        'status' => [
            StoreWalletsProgress::STATUS_PREPARING => 'Preparing seed phrases: :current from :total',
            StoreWalletsProgress::STATUS_CREATING => 'Adding seed phrases: :current from :total',
            StoreWalletsProgress::STATUS_READY => 'Seed phrases added successfully'
        ]
    ],

    'address' => ':currency addresses',

    'ethereum_notification' => 'The speed of checking Ethereum addresses has been reduced until the conversion of seed phrases into addresses is completed. It remains to process: :current addresses.',

    'service' => [
        'debank' => 'DeBank',
        'zapper' => 'Zapper',
        'zerion' => 'Zerion'
    ]
];

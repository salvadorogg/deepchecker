<?php

use App\Support\QueuePlaner;

return [
    'state' => [
        QueuePlaner::STATE_WORK => 'Работает',
        QueuePlaner::STATE_AWAITING => 'Ожидает',
        QueuePlaner::STATE_SLEEP => 'Спит',
        QueuePlaner::STATE_RESTART => 'Рестарт',
        QueuePlaner::STATE_ERROR => 'Ошибка',
        QueuePlaner::STATE_MEMORY_LIMIT => 'Заморожен',
        QueuePlaner::STATE_AWAITING_PROXY => 'Ждет прокси',
        'default' => 'Загрузка...'
    ],

    'name' => [
        'queue_currency_parse_btc' => 'Bitcoin',
        'queue_currency_parse_bch' => 'BitcoinCash',
        'queue_currency_parse_doge' => 'DOGE',
        'queue_currency_parse_eth' => 'Ethereum',
        'queue_currency_parse_ltc' => 'Litecoin',
        'queue_currency_parse_solana' => 'Solana',
        'queue_currency_parse_tron' => 'TRON',
        'queue_addresses_parse_1' => 'Поток 1',
        'queue_addresses_parse_2' => 'Поток 2',
        'queue_addresses_parse_3' => 'Поток 3',
        'queue_addresses_parse_4' => 'Поток 4',
        'queue_addresses_parse_5' => 'Поток 5',
        'queue_addresses_parse_6' => 'Поток 6',
        'queue_addresses_parse_7' => 'Поток 7',
        'puppeteer_parser_1' => 'Поток 1',
        'puppeteer_parser_2' => 'Поток 2',
        'puppeteer_parser_3' => 'Поток 3',
        'puppeteer_parser_4' => 'Поток 4',
        'puppeteer_parser_5' => 'Поток 5',
        'puppeteer_parser_6' => 'Поток 6',
        'puppeteer_parser_7' => 'Поток 7',
        'puppeteer_parser_8' => 'Поток 8',
        'puppeteer_parser_9' => 'Поток 9',
        'puppeteer_parser_10' => 'Поток 10',
        'puppeteer_parser_11' => 'Поток 11',
        'puppeteer_parser_12' => 'Поток 12',
        'puppeteer_parser_13' => 'Поток 13',
        'puppeteer_parser_14' => 'Поток 14',
        'puppeteer_parser_15' => 'Поток 15'
    ],

    'group' => [
        'currency_parse' => 'API парсеры валют',
        'ethereum_browser_parse' => 'Парсеры Ethereum',
        'addresses_parse' => 'Обработчики адресов'
    ]
];

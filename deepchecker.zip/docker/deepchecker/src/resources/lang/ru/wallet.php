<?php

use App\Support\StoreWalletsProgress;

return [
    'period' => [
        180 => '3 часа',
        360 => '6 часов',
        999999 => 'Выключить повторную проверку'
    ],

    'order' => [
        'direction' => [
            'asc' => 'По возрастанию',
            'desc' => 'По убыванию'
        ],

        'field' => [
            'total' => 'Общий баланс',
            'created_at' => 'Дата создания',
            'total_btc' => 'Баланс Bitcoin',
            'total_bch' => 'Баланс BitcoinCash',
            'total_doge' => 'Баланс Dogecoin',
            'total_eth' => 'Баланс Ethereum',
            'total_ltc' => 'Баланс Litecoin',
            'total_solana' => 'Баланс Solana',
            'total_tron' => 'Баланс Tron'
        ]
    ],

    'progress' => [
        'status' => [
            StoreWalletsProgress::STATUS_PREPARING => 'Подготовка seed-фраз: :current из :total',
            StoreWalletsProgress::STATUS_CREATING => 'Добавление seed-фраз: :current из :total',
            StoreWalletsProgress::STATUS_READY => 'Seed-фразы успешно добавлены'
        ]
    ],

    'ethereum_notification' => 'Скорость проверки Ethereum-адресов снижена до окончания конвертации seed-фраз в адреса. Осталось обработать: :current адресов.',

    'service' => [
        'debank' => 'DeBank',
        'zapper' => 'Zapper',
        'zerion' => 'Zerion'
    ]
];

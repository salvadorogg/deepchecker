<!DOCTYPE html>
<html lang="{{ config('app.locale') }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $navigation->title() }}</title>
    <link rel="stylesheet" href="{{ mix('css/app.css') }}">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    {{--<div class="preloader flex-column justify-content-center align-items-center">
        DeepChecker
    </div>--}}

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Left navbar links -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>

            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#" aria-expanded="false">
                    <i class="fas fa-globe"></i>
                </a>
                <div class="dropdown-menu dropdown-menu-left p-0" style="left: inherit; right: 0;">
                    <a href="{{ route('language', 'ru') }}" class="dropdown-item {{ config('app.locale') == 'ru' ? 'active' : '' }}">
                        Russian
                    </a>
                    <a href="{{ route('language', 'en') }}" class="dropdown-item {{ config('app.locale') == 'en' ? 'active' : '' }}">
                        English
                    </a>
                </div>
            </li>

            <li class="nav-item dropdown d-none" data-ethereum-slow-noty>
                <a class="nav-link" data-toggle="tooltip" data-placement="bottom" title="" href="#" aria-expanded="false">
                    <svg fill="#bfc9d4" viewBox="0 0 512 512" width="30px" height="25px"><path d="M457.776 188.928h-52.048c-32.133-45.174-83.546-71.656-139.005-71.656-48.356 0-94.386 20.353-126.954 56.634L6.329 275.218c-12.175 9.244-5.606 28.743 9.675 28.743h80.024v74.766c0 8.836 7.164 16 16 16h70.677c8.836 0 16-7.164 16-16v-20.24c41.479 12.608 94.559 12.608 136.038 0v20.24c0 8.836 7.164 16 16 16h70.677c8.836 0 16-7.164 16-16v-74.766H496c8.836 0 16-7.164 16-16v-44.81c0-29.899-24.324-54.223-54.224-54.223zm-55.842 68.145c1.307 5.745 1.998 10.123 2.546 14.884H128.962a138.838 138.838 0 012.562-14.884h270.41zm-11.595-32h-63.24l18.823-51.04c18.702 13.029 33.965 30.541 44.417 51.04zm-72.911-66.256l-24.435 66.255h-52.538l-24.43-66.243c32.902-12.973 69.719-12.514 101.403-.012zm-129.883 15.268l18.805 50.988h-63.215a139.008 139.008 0 0144.41-50.988zm-85.393 68.56a172.364 172.364 0 00-5.367 29.317H63.537l38.615-29.317zm264.592 120.083v-27.554c0-11.794-12.385-19.57-23.023-14.376-41.017 20.036-112.975 20.037-153.992 0-10.641-5.197-23.023 2.589-23.023 14.376v27.554h-38.677v-58.766h277.392v58.766h-38.677zM480 271.961h-43.332c-1.625-17.404-5.974-34.748-12.938-51.034h34.046c12.254 0 22.224 9.969 22.224 22.223v28.811z"/></svg>
                </a>
            </li>

            @can('view-any')
                <li class="nav-item d-none d-sm-inline-block">
                    <span class="nav-link">@lang('Адресов:') <span data-adresses-total-count>0</span></span>
                </li>
            @endcan

            <li class="nav-item">
                <span class="nav-link">@lang('В очереди:') <span data-addresses-awaiting-count>0</span></span>
            </li>

        </ul>

        <!-- Right navbar links -->
        <ul class="navbar-nav ml-auto d-none d-lg-block">
            <!-- Notifications Dropdown Menu -->
            @hasSection('buttons')
                <div class="col-sm-12">
                    <div class="float-sm-right mt-3 mt-sm-0">
                        @yield('buttons')
                    </div>
                </div><!-- /.col -->
            @endif
        </ul>
    </nav>
    <!-- /.navbar -->

    @hasSection('buttons')
        <div class="mobile-buttons d-block d-lg-none py-2 position-fixed w-100 text-center">
            @yield('buttons')
        </div>
    @endif

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Brand Logo -->
        <div class="brand-link {{--text-center--}}">
            {{--<img src="dist/img/AdminLTELogo.png" alt="AdminLTE Logo" class="brand-image img-circle elevation-3" style="opacity: .8">--}}
            <span class="brand-text font-weight-light ml-3">{{ config('app.name') }}</span>
            {{--@include('particles.logo')--}}
        </div>

        <!-- Sidebar -->
        <div class="sidebar flex-wrapper-item">
            <!-- Sidebar Menu -->
            <nav class="mt-2 flex-top">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    @foreach($navigation->menu() as $item)
                        @switch($item->type)
                            @case(\App\Support\Navigation::ITEM_TYPE_LINK)
                                <li class="nav-item">
                                    <a href="{{ $item->route }}" class="nav-link {{ $item->active ? 'active' : '' }}">
                                        <i class="nav-icon {{ $item->icon }}"></i>
                                        <p>{{ $item->name }}</p>
                                        @if($item->badge !== null)
                                            <span class="badge badge-primary right">{{ $item->badge }}</span>
                                        @endif
                                    </a>
                                </li>
                                @break
                            @case(\App\Support\Navigation::ITEM_TYPE_SUBMENU)
                                <li class="nav-item {{ $item->active ? 'menu-open' : '' }}">
                                    <a href="#" class="nav-link {{ $item->active ? 'active' : '' }}">
                                        <i class="nav-icon {{ $item->icon }}"></i>
                                        <p>
                                            {{ $item->name }}
                                            <i class="right fas fa-angle-left"></i>
                                        </p>
                                    </a>
                                    <ul class="nav nav-treeview">
                                        @foreach($item->items as $i)
                                            <li class="nav-item">
                                                <a href="{{ $i->route }}" class="nav-link {{ $i->active ? 'active' : '' }}">
                                                    <i class="far fa-circle nav-icon"></i>
                                                    <p>{{ $i->name }}</p>
                                                </a>
                                            </li>
                                        @endforeach
                                    </ul>
                                </li>
                                @break
                        @endswitch
                    @endforeach
                </ul>
            </nav>
            <!-- /.sidebar-menu -->
        </div>
        <!-- /.sidebar -->
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">


        <!-- Main content -->
        <section class="content">
            <div class="container-fluid">
                @can('view-any')
                    @include('particles.version')
                    @include('particles.notifications.demo')
                @endcan

                @yield('content')

                {{--@hasSection('buttons')
                    <div class="card card-default">
                        <!-- form start -->
                        <div class="card-body text-left text-md-right">
                            @yield('buttons')
                        </div>
                        <!-- /.card-body -->
                    </div>
                @endif--}}
            </div><!-- /.container-fluid -->
        </section>

        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->
    <footer class="main-footer">
        <strong>Copyright &copy; {{ now()->year }} <a href="{{ config('app.url') }}" class="text-black-50">{{ config('app.name') }}</a>.</strong>
        <div class="float-right d-none d-sm-inline-block">
            {{ File::get(base_path('version.txt')) }}
        </div>
    </footer>

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <!-- Control sidebar content goes here -->
    </aside>
    <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<form class="d-none" method="post" data-action-form="destroy">@method('delete')</form>

@stack('footer')
<script src="{{ mix('js/app.js') }}"></script>
</body>
</html>

<table class="table text-center">
    <thead>
    <tr>
        <th style="width:25%;"></th>
        <th style="width:25%;">@lang('Минимальное зн-е')</th>
        <th style="width:25%;">@lang('Оптимальное зн-е')</th>
        <th style="width:25%;">@lang('Текущее зн-е')</th>
    </tr>
    </thead>
    <tbody>
    <tr>
        <td>CPU</td>
        <td>4 Cores</td>
        <td>6 Cores</td>
        <td>{{ $cpu }} Cores</td>
    </tr>
    <tr>
        <td>RAM</td>
        <td>4000Mb</td>
        <td>6000Mb</td>
        <td>{{ $memory }}Mb</td>
    </tr>
    <tr>
        <td>@lang('Рабочие прокси')</td>
        <td>10 @lang('шт')</td>
        <td>{{ $recommend_proxies < 20 ? '20' : $recommend_proxies }} @lang('шт')</td>
        <td>{{ $current_proxies }} @lang('шт')</td>
    </tr>
    </tbody>
</table>

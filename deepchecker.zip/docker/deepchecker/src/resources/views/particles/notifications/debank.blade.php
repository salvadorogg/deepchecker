@php($balance = (new \App\Support\Services\DeBank())->getBalance())
@if($balance !== null && $balance < 5000)
    <div class="card">
        <!-- /.card-header -->
        <div class="card-body">
            {!! __('Предупреждение: у вас подключен премиум-план DeBank, но лимит запросов приближается к нулю. Текущий остаток - :balance юнитов (1 адрес = 30 юнитов). <a href="https://open.debank.com" target="_blank">Пополните счет</a>, иначе будет использоваться бесплатный метод.', compact('balance')) !!}
        </div>
        <!-- /.card-body -->
    </div>
@endif

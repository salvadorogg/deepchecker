@if($demoIsActive && $demoLimit !== null)
    <div class="card">
        <!-- /.card-header -->
        <div class="card-body">
            @if($demoLimit > 0)
                {!! __('Вы используете демо-версию с ограниченным функционалом. В ней вы можете добавить максимум :limit seed-фраз а также не имеете доступа к некоторым функциям. За покупкой полной версии: <a href="https://t.me/buydeepchecker_bot" target="_blank">Telegram: @buydeepchecker_bot</a>.', ['limit' => $demoLimit]) !!}
            @else
                {!! __('Вы используете демо-версию с ограниченным функционалом. Вы исчерпали лимит по добавленным seed-фразам. За покупкой полной версии: <a href="https://t.me/buydeepchecker_bot" target="_blank">Telegram: @buydeepchecker_bot</a>.') !!}
            @endif
        </div>
        <!-- /.card-body -->
    </div>
@endif

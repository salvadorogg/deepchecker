@if($has_updates)
    <div class="card">
        <!-- /.card-header -->
        <div class="card-body">
            {!! __('Доступна новая версия <span class="badge badge-light">:version</span>. <a href="https://deepmng.com/download?key=:license_key&locale=:locale" target="_blank" class="text-reset text-bold">Скачайте обновление</a> и обновите скрипт до последней версии, используя инструкцию.', ['version' => $latest_version, 'license_key' => env('APP_LICENSE_KEY'), 'locale' => config('app.locale')]) !!}
        </div>
        <!-- /.card-body -->
    </div>
@endif

@extends('layouts.app')

@section('buttons')
    <a href="#" class="btn btn-primary" data-action="store">@lang('Добавить')</a>
@endsection

@section('content')
    <form action="{{ route('proxies.store') }}" method="post" data-action-form="store">
        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">@lang('Основное')</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="form-group">
                    <label>@lang('Название')</label>
                    <input type="text" class="form-control" name="name">
                </div>
            </div>
            <!-- /.card-body -->
        </div>

        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">@lang('Соединение')</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="form-group">
                    <label>@lang('Тип')</label>
                    <select class="form-control" name="type">
                        @foreach($types as $type)
                            <option value="{{ $type }}">@lang("proxy.type.{$type}")</option>
                        @endforeach
                    </select>
                </div>

                <div class="row">
                    <div class="col-md-8 form-group">
                        <label>@lang('IP')</label>
                        <input type="text" class="form-control" name="ip">
                    </div>

                    <div class="col-md-4 form-group">
                        <label>@lang('Порт')</label>
                        <input type="number" class="form-control" name="port">
                    </div>

                    <div class="col-md-6 form-group">
                        <label>@lang('Логин')</label>
                        <input type="text" class="form-control" name="user">
                    </div>

                    <div class="col-md-6 form-group">
                        <label>@lang('Пароль')</label>
                        <input type="text" class="form-control" name="password">
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
        </div>
    </form>
@endsection

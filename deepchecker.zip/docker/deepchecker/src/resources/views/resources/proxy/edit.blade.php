@extends('layouts.app')

@section('buttons')
    <a href="#" class="btn btn-primary" data-action="update">@lang('Изменить')</a>
    <a href="{{ route('proxies.destroy', $proxy) }}" class="btn btn-danger" data-action="destroy">@lang('Удалить')</a>
@endsection

@section('content')
    <form action="{{ route('proxies.update', $proxy) }}" method="post" data-action-form="update">
        @method('put')

        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">@lang('Основное')</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="form-group">
                    <label>@lang('Название')</label>
                    <input type="text" class="form-control" name="name" value="{{ $proxy->name }}">
                </div>
            </div>
            <!-- /.card-body -->
        </div>

        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">@lang('Соединение')</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="form-group">
                    <label>@lang('Тип')</label>
                    <select class="form-control" name="type">
                        @foreach($types as $type)
                            <option value="{{ $type }}" {{ $type == $proxy->type ? 'selected' : '' }}>@lang("proxy.type.{$type}")</option>
                        @endforeach
                    </select>
                </div>

                <div class="row">
                    <div class="col-md-8 form-group">
                        <label>@lang('IP')</label>
                        <input type="text" class="form-control" name="ip" value="{{ $proxy->ip }}">
                    </div>

                    <div class="col-md-4 form-group">
                        <label>@lang('Порт')</label>
                        <input type="number" class="form-control" name="port"  value="{{ $proxy->port }}">
                    </div>

                    <div class="col-md-6 form-group">
                        <label>@lang('Логин')</label>
                        <input type="text" class="form-control" name="user" value="{{ $proxy->user }}">
                    </div>

                    <div class="col-md-6 form-group">
                        <label>@lang('Пароль')</label>
                        <input type="text" class="form-control" name="password" value="{{ $proxy->password }}">
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
        </div>
    </form>
@endsection

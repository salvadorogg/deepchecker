@extends('layouts.app')

@section('buttons')
    <div class="btn-group" role="group">
        <button id="btnGroupDrop1" type="button" class="btn btn-primary dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
            @lang('Добавить')
        </button>
        <div class="dropdown-menu" aria-labelledby="btnGroupDrop1">
            <a class="dropdown-item" href="{{ route('proxies.create') }}">@lang('Одно')</a>
            <a class="dropdown-item" href="#" data-toggle="modal" data-target="#storeMany">@lang('Несколько')</a>
        </div>
    </div>
    <a href="#" class="btn btn-danger" data-action="truncate">@lang('Удалить все')</a>
@endsection

@section('content')
    <div class="row">
        <div class="col-md-3">
            <div class="info-box bg-default">
                <span class="info-box-icon"><i class="far fa-flag"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">@lang('Всего')</span>
                    <span class="info-box-number">{{ $proxies->count() }}</span>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="info-box bg-default">
                <span class="info-box-icon"><i class="far fa-thumbs-up"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">@lang('Рабочих')</span>
                    <span class="info-box-number">{{ $proxies->where('is_active', 1)->count() }}</span>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="info-box bg-default">
                <span class="info-box-icon"><i class="far fa-thumbs-down"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">@lang('Проблемных')</span>
                    <span class="info-box-number">{{ $proxies->where('is_active', 0)->count() }}</span>
                </div>
            </div>
        </div>

        <div class="col-md-3">
            <div class="info-box bg-default">
                <span class="info-box-icon"><i class="far fa-star"></i></span>
                <div class="info-box-content">
                    <span class="info-box-text">@lang('Рекомендуется')</span>
                    <span class="info-box-number">{{ $proxyBus->getRecommendCount() }}</span>
                </div>
            </div>
        </div>

        @foreach($proxies as $proxy)
            <div class="col-md-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-md-12 d-flex align-items-center">
                                        <span class="badge badge-info mr-1" data-clipboard-value="{{ $proxy->toConnectionString() }}" data-toggle="tooltip" data-placement="right" title="@lang('Скопировать в буфер обмена')">{{ $proxy->name ?? $proxy->toConnectionString()}}</span>
                                        @if($proxy->is_active && config('app.debug'))
                                            <span class="badge badge-{{ $proxyBus->getErrorsCount($proxy) ? 'danger' : 'info' }} d-none d-md-block">
                                                @lang('Ошибок: :count', ['count' => $proxyBus->getErrorsCount($proxy)])
                                            </span>
                                        @endif
                                    </div>

                                    <div class="col-md-12 mt-2">
                                        @if($proxy->is_active)
                                            <span class="badge badge-success">@lang('Работает')</span>

                                            @foreach($services as $service)
                                                <span class="badge badge-{{ $proxyBus->isBanned($proxy, $service) ? 'danger' : 'success' }}">{{ $service->getName() }}</span>
                                            @endforeach
                                        @else
                                            <span class="badge badge-danger">@lang('Не работает')</span>
                                        @endif
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4 d-flex justify-content-start justify-content-md-end align-items-center mt-3 mt-md-0">
                                <a href="{{ route('proxies.edit', $proxy) }}" class="btn btn-default btn-sm">@lang('Изменить')</a>
                                <a href="{{ route('proxies.destroy', $proxy) }}" class="btn btn-danger btn-sm ml-1" data-action="destroy">
                                    <i class="fas fa-trash-alt"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach

        <div class="col-md-12">
            <p class="small text-muted">@lang('*рекомендуемое количество указывает на то, сколько рабочих прокси требуется для работы парсеров всех активных валют в пики максимальной нагрузки без простоев на ожидание прокси')</p>
        </div>
    </div>
@endsection

@push('footer')
    <div class="modal fade" data-backdrop="static" id="storeMany" tabindex="-1" aria-labelledby="storeManyLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="storeManyLabel">@lang('Добавить несколько прокси')</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class="modal-body" method="post" action="{{ route('proxies.store_many') }}" data-action-form="store">
                    <div class="form-group">
                        <textarea class="form-control" name="proxies" rows="15" placeholder="http://user:password@127.0.0.1:465&#10;http://127.0.0.1:465"></textarea>
                        <small class="text-muted">{!! __('1 строка - 1 прокси. Формат - <code>тип://пользователь:пароль@ип:порт</code> для приватных и <code>тип://ип:порт</code> для публичных') !!}</small>
                    </div>
                </form>
                <div class="modal-footer">
                    <a href="#" class="btn btn-primary btn-block" data-action="store">@lang('Добавить')</a>
                </div>
            </div>
        </div>
    </div>

    <form method="post" action="{{ route('proxies.truncate') }}" data-action-form="truncate">@method('delete')</form>
@endpush

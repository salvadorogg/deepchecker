@extends('layouts.app')

@section('buttons')
    <a href="{{ route('users.create') }}" class="btn btn-primary">@lang('Добавить')</a>
@endsection

@section('content')
    <div class="card card-default">
        <!-- form start -->
        <div class="card-body table-responsive p-0">
            <table class="table table-hover text-nowrap">
                <thead>
                <tr>
                    <th>@lang('ID')</th>
                    <th>@lang('Email')</th>
                    <th>@lang('Группа')</th>
                    <th>@lang('Seed-фраз')</th>
                    <th>@lang('Создан')</th>
                    <th>@lang('Изменен')</th>
                    <th>@lang('Действия')</th>
                </tr>
                </thead>
                <tbody>
                @foreach($users as $user)
                    <tr>
                        <td>{{ $user->id }}</td>
                        <td>{{ $user->email }}</td>
                        <td>@lang("user.group.{$user->group}")</td>
                        <td>
                            {{ $user->wallets_count }}
                            @if(config('jamasad.demo_enabled') && $user->wallets_limit !== null)
                                / {{ $user->wallets_limit }}
                            @endif
                        </td>
                        <td>{{ $user->created_at->format('d.m.Y H:i') }}</td>
                        <td>{{ $user->updated_at->diffForHumans() }}</td>
                        <td>
                            <a href="{{ route('users.edit', $user) }}" class="btn btn-default btn-sm">@lang('Изменить')</a>
                            <a href="{{ route('users.destroy', $user) }}" class="btn btn-danger btn-sm ml-1" data-action="destroy">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>

    {{ $users->links() }}
@endsection

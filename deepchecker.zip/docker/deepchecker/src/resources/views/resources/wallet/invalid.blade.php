@extends('layouts.app')

@section('content')
    <div class="card">
        <!-- /.card-header -->
        <div class="card-body table-responsive p-0">
            <table class="table table-hover text-nowrap">
                <thead>
                <tr>
                    <th>@lang('Seed-фраза')</th>
                    <th>@lang('Дата')</th>
                </tr>
                </thead>
                <tbody>
                @foreach($mnemonics as $mnemonic)
                    <tr>
                        <td>
                            {!! $mnemonic->getFormattedString() !!}
                        </td>
                        <td class="align-middle">
                            {{ $mnemonic->created_at->format('d.m.Y H:i') }}
                        </td>
                    </tr>
                @endforeach
                </tbody>
            </table>
        </div>
        <!-- /.card-body -->
    </div>

    {{ $mnemonics->links() }}
@endsection

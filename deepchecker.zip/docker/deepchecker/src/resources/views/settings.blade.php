@extends('layouts.app')

@section('buttons')
    <a href="#" class="btn btn-primary" data-action="update">@lang('Обновить')</a>
    @can('view-any')
        @if(config()->has('autoload.telegram_api_key'))
            <a href="#" class="btn btn-warning" data-action="set-webhook">@lang('Привязать вебхук Telegram')</a>
        @endif

        <a href="#" class="btn btn-warning" data-action="reload">@lang('Перезапустить очереди')</a>
        <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#configuration" data-configuration-show>@lang('Конфигурация')</a>
    @endcan
@endsection

@section('content')
    <form class="settingsForm" action="{{ route('settings.update') }}" method="post" data-action-form="update">
        @method('put')

        @can('view-any')
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">@lang('Лицензия')</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <div class="card-body">
                    <p>{!! __('Лицензия активна до <span class="badge badge-light">:date</span>. Обратитесь в телеграм <a href="https://t.me/deepchecker_support" target="_blank" class="text-reset text-bold">@deepchecker_support</a> для продления лицензии.', ['date' => $license_date->format('d.m.Y H:i')]) !!}</p>
                </div>
                <!-- /.card-body -->
            </div>
        @endcan

        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">@lang('Контактные данные')</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="form-group">
                    <label>@lang('Email')</label>
                    <input type="email" class="form-control" name="email" value="{{ $user->email }}">
                </div>
            </div>
            <!-- /.card-body -->
        </div>

        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">@lang('Безопасность')</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6 form-group">
                        <label>@lang('Пароль')</label>
                        <input type="password" class="form-control" name="password" autocomplete="new-password">
                    </div>

                    <div class="col-md-6 form-group">
                        <label>@lang('Пароль еще раз')</label>
                        <input type="password" class="form-control" name="password_confirmation" autocomplete="new-password">
                    </div>
                </div>
            </div>
            <!-- /.card-body -->
        </div>

        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">@lang('Настройки кошельков')</h3>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body">
                <div class="form-group">
                    <label>@lang('Частота проверки')</label>
                    <select class="form-control" name="check_period">
                        @foreach($periods as $period)
                            <option value="{{ $period }}" {{ $period == $user->check_period ? 'selected' : '' }}>@lang("wallet.period.{$period}")</option>
                        @endforeach
                    </select>
                </div>

                @if(config('autoload.telegram_bot_name'))
                    <div class="form-group">
                        <label>@lang('Уведомлять, если баланс кошелька превысит')</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">$</span>
                            </div>
                            <input type="number" class="form-control" name="notify_minimal_amount" value="{{ $user->notify_minimal_amount }}">
                        </div>
                    </div>

                    @if($user->telegrams->count() < 20)
                        <p>@lang('Для привязки Telegram к профилю скопируйте сообщение ниже и отправьте его боту') <a href="https://t.me/{{ config('autoload.telegram_bot_name') }}" target="_blank" class="font-weight-bold">{{ '@'.config('autoload.telegram_bot_name') }}</a>.</p>

                        <div class="form-group">
                            <input type="text" class="form-control" value="/pair {{ $user->telegramCode->code }}" readonly data-clipboard-value="/pair {{ $user->telegramCode->code }}" data-toggle="tooltip" data-placement="bottom" title="@lang('Скопировать в буфер обмена')" />
                        </div>
                    @endif
                @endif
            </div>
            <!-- /.card-body -->
        </div>

        @if($user->telegrams->isNotEmpty())
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">@lang('Чаты Telegram')</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <div class="card-body">
                    <table class="table table-hover text-nowrap">
                        <thead>
                        <tr>
                            <th style="width: 70%;">@lang('Название')</th>
                            <th>@lang('Действия')</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($user->telegrams as $telegram)
                            <tr>
                                <td class="align-middle">{{ $telegram->name }}</td>
                                <td class="align-middle">
                                    <a href="{{ route('settings.detach_telegram', $telegram) }}" class="btn btn-danger btn-sm ml-1" data-action="destroy" data-toggle="tooltip" data-placement="top" title="@lang('Отвязать аккаунт')">
                                        <i class="fas fa-trash-alt"></i>
                                    </a>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
        @endif

        @can('view-any')
            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">@lang('Настройки валют')</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <div class="card-body">
                    <ul class="nav nav-pills" id="pills-tab-currencies" role="tablist">
                        @foreach($currencies as $currency)
                            <li class="nav-item">
                                <a class="nav-link {{ $loop->first ? 'active' : '' }}" id="pills-{{ $currency->getSlug() }}-tab" data-toggle="pill" href="#pills-{{ $currency->getSlug() }}" role="tab">
                                    {{ $currency->getName() }}
                                </a>
                            </li>
                        @endforeach
                    </ul>
                    <div class="tab-content" id="pills-tabContent">
                        @foreach($currencies as $currency)
                            <div class="tab-pane fade {{ $loop->first ? 'show active' : '' }} mt-3" id="pills-{{ $currency->getSlug() }}" role="tabpanel">
                                <div class="form-group">
                                    <div class="custom-control custom-switch">
                                        <input type="checkbox" class="custom-control-input" name="currencies[{{ $currency->getSlug() }}][is_enabled]" id="currencyEnabled{{ $currency->getSlug() }}" {{ $currency->isEnabled() ? 'checked' : '' }}>
                                        <label class="custom-control-label" for="currencyEnabled{{ $currency->getSlug() }}">
                                            @lang('Валюта включена')
                                            @if($currency->getSlug() !== 'eth')
                                                <span class="ml-2 text-muted"><i class="fas fa-network-wired"></i> @lang('валюта задействует до :count прокси', ['count' => 10])</span>
                                            @endif
                                        </label>
                                    </div>
                                </div>

                                @if($currency instanceof \App\Support\Currency\Ethereum)
                                    <div class="form-group">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="is_enabled_debank" name="is_enabled_debank" {{ $currency->isDeBankEnabled() ? 'checked' : '' }}>
                                            <label class="custom-control-label" for="is_enabled_debank">
                                                @lang('Получать информацию из DeBank')
                                                <span class="ml-2 text-muted"><i class="fas fa-network-wired"></i> @lang('источник задействует до :count прокси', ['count' => 72])</span>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="is_enabled_zapper" name="is_enabled_zapper" {{ $currency->isZapperEnabled() ? 'checked' : '' }}>
                                            <label class="custom-control-label" for="is_enabled_zapper">
                                                @lang('Получать информацию из Zapper')
                                                <span class="ml-2 text-muted"><i class="fas fa-network-wired"></i> @lang('источник задействует до :count прокси', ['count' => 120])</span>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="form-group">
                                        <div class="custom-control custom-switch">
                                            <input type="checkbox" class="custom-control-input" id="is_enabled_zerion" name="is_enabled_zerion" {{ $currency->isZerionEnabled() ? 'checked' : '' }}>
                                            <label class="custom-control-label" for="is_enabled_zerion">
                                                @lang('Получать информацию из Zerion')
                                                <span class="ml-2 text-muted"><i class="fas fa-network-wired"></i> @lang('источник задействует до :count прокси', ['count' => 24])</span>
                                            </label>
                                        </div>
                                    </div>
                                @endif

                                <div class="form-group mt-3">
                                    <label class="d-block">@lang('Доступные пути')</label>
                                    <select class="form-control d-block" name="currencies[{{ $currency->getSlug() }}][patches][]" multiple>
                                        @foreach($currency->getPatches() as $value => $name)
                                            <option value="{{ $value }}" {{ $currency->isEnabledPatch($value) ? 'selected' : '' }}>{{ $name }}</option>
                                        @endforeach
                                    </select>
                                </div>

                                <div class="form-group">
                                    <label class="d-block">@lang('Частота использования прокси')</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="currencies[{{ $currency->getSlug() }}][delay]" value="{{ $currency->getDelay() }}">
                                        <div class="input-group-append">
                                            <span class="input-group-text">@lang('секунд')</span>
                                        </div>
                                    </div>
                                    <small>@lang('Определяет то, как часто одна прокси может использоваться для сканирования адреса. Не редактируйте данный параметр если не уверены, что в этом есть необходимость. Рекомендуемое значение - :delay.', ['delay' => $currency->getDefaultDelay()])</small>
                                </div>

                                <div class="form-group">
                                    <label class="d-block">@lang('Задержка между запросами')</label>
                                    <div class="input-group">
                                        <input type="text" class="form-control" name="currencies[{{ $currency->getSlug() }}][sleep]" value="{{ $currency->getSleep() }}">
                                        <div class="input-group-append">
                                            <span class="input-group-text">@lang('микросекунд')</span>
                                        </div>
                                    </div>
                                    <small>@lang('Величина, отвечающая за то сколько времени процесс будет "отдыхать" между запросами. Уменьшение значения может привести к увеличению "красных" адресов. Не редактируйте данный параметр если не уверены, что в этом есть необходимость. Рекомендуемое значение - :sleep.', ['sleep' => $currency->getSleep()])</small>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
                <!-- /.card-body -->
            </div>

            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">@lang('Telegram')</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6 form-group">
                            <label>@lang('Имя бота')</label>
                            <input type="text" class="form-control" name="telegram_bot_name" value="{{ config('autoload.telegram_bot_name') }}">
                        </div>

                        <div class="col-md-6 form-group">
                            <label>@lang('Токен')</label>
                            <input type="text" class="form-control" name="telegram_api_key" value="{{ config('autoload.telegram_api_key') }}">
                        </div>
                    </div>
                </div>
                <!-- /.card-body -->
            </div>

            <div class="card card-default">
                <div class="card-header">
                    <h3 class="card-title">@lang('Blockchair')</h3>
                </div>
                <!-- /.card-header -->
                <!-- form start -->
                <div class="card-body">
                    <p>{!! __('Часть валют (Bitcoin, BitcoinCash) взаимодействуют с <a href="https://blockchair.com/api" target="_blank" class="link-black">blockchair.com</a> для получения данных о кошельках. Данное API ограничивает максимальное количество запросов в день. Если вы сталкиваетесь с большими задержками в работе парсеров Bitcoin/BitcoinCash - рекомендую <a href="https://blockchair.com/api/plans" target="_blank" class="link-black">увеличить ежедневный лимит</a>.') !!}</p>

                    <div class="form-group">
                        <label>@lang('API-ключ')</label>
                        <input type="text" class="form-control" name="blockchair_api_key" value="{{ config('autoload.blockchair_api_key') }}">
                    </div>
                </div>
                <!-- /.card-body -->
            </div>

            @if(config('jamasad.demo_enabled'))
                <div class="card card-default">
                    <div class="card-header">
                        <h3 class="card-title">API демо</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6 form-group">
                                <label>Стандартное количество мнемоников</label>
                                <input type="number" class="form-control" name="demo[mnemonics_limit]" value="{{ config('autoload.demo.mnemonics_limit') }}">
                            </div>

                            <div class="col-md-6 form-group">
                                <label>Секретный токен</label>
                                <input type="text" class="form-control" name="demo[api_token]" value="{{ config('autoload.demo.api_token') }}">
                            </div>
                        </div>
                    </div>
                    <!-- /.card-body -->
                </div>
        @endif

            <div class="card card-default">
                <div class="card-body">
                    {!! Str::markdown($update) !!}
                </div>
                <!-- /.card-body -->
            </div>
        @endcan
    </form>
@endsection

@push('footer')
    @can('view-any')
        <!-- Modal -->
        <div class="modal fade" id="configuration" tabindex="-1" aria-hidden="true" data-backdrop="static" data-route="{{ route('settings.configuration') }}">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">@lang('Конфигурация')</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body p-0">
                        <div class="d-flex justify-content-center my-5" data-loader>
                            <div class="spinner-border" role="status">
                                <span class="sr-only">Loading...</span>
                            </div>
                        </div>

                        <div class="table-responsive d-none" data-configuration></div>
                    </div>
                </div>
            </div>

            <div class="modal-dialog modal-lg mt-5">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">@lang('Требования для работы Selenium-потоков')</h5>
                    </div>
                    <div class="modal-body p-0">
                        <div class="table-responsive">
                            <table class="table text-center">
                                <thead>
                                <tr>
                                    <th style="width:25%;">@lang('Поток')</th>
                                    <th style="width:25%;">CPU</th>
                                    <th style="width:25%;">RAM</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                <tr>
                                    <td>14</td>
                                    <td>6 Cores</td>
                                    <td>6Gb</td>
                                </tr>
                                <tr>
                                    <td>13</td>
                                    <td>6 Cores</td>
                                    <td>6Gb</td>
                                </tr>
                                <tr>
                                    <td>12</td>
                                    <td>6 Cores</td>
                                    <td>6Gb</td>
                                </tr>
                                <tr>
                                    <td>11</td>
                                    <td>6 Cores</td>
                                    <td>6Gb</td>
                                </tr>
                                <tr>
                                    <td>10</td>
                                    <td>6 Cores</td>
                                    <td>6Gb</td>
                                </tr>
                                <tr>
                                    <td>9</td>
                                    <td>6 Cores</td>
                                    <td>6Gb</td>
                                </tr>
                                <tr>
                                    <td>8</td>
                                    <td>6 Cores</td>
                                    <td>6Gb</td>
                                </tr>
                                <tr>
                                    <td>7</td>
                                    <td>4 Cores</td>
                                    <td>4Gb</td>
                                </tr>
                                <tr>
                                    <td>6</td>
                                    <td>4 Cores</td>
                                    <td>4Gb</td>
                                </tr>
                                <tr>
                                    <td>5</td>
                                    <td>4 Cores</td>
                                    <td>4Gb</td>
                                </tr>
                                <tr>
                                    <td>4</td>
                                    <td>4 Cores</td>
                                    <td>4Gb</td>
                                </tr>
                                <tr>
                                    <td>3</td>
                                    <td>4 Cores</td>
                                    <td>4Gb</td>
                                </tr>
                                <tr>
                                    <td>2</td>
                                    <td>4 Cores</td>
                                    <td>4Gb</td>
                                </tr>
                                <tr>
                                    <td>1</td>
                                    <td>4 Cores</td>
                                    <td>4Gb</td>
                                </tr>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <form method="get" action="{{ route('settings.telegram') }}" data-action-form="set-webhook"></form>
        <form method="get" action="{{ route('settings.reload') }}" data-action-form="reload"></form>
    @endcan
@endpush

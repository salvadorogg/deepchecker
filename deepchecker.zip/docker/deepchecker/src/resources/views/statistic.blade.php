@extends('layouts.app')

@section('buttons')
    <a href="#" class="btn btn-warning" data-action="reload">@lang('Перезапустить очереди')</a>
@endsection

@section('content')
    <div data-statistic data-data-route="{{ route('statistic.data') }}">
        <div class="card card-default">
            <div class="card-header">
                <h3 class="card-title">@lang('Проверено адресов за 24 часа')</h3>
                <div class="card-tools">
                    <span class="badge badge-info m-auto"><span class="d-none d-md-inline">@lang('Последнее обновление:') </span><span data-updated-at></span></span>
                </div>
            </div>
            <!-- /.card-header -->
            <!-- form start -->
            <div class="card-body text-center">
                <canvas id="statistic" height="350px"></canvas>
            </div>
            <!-- /.card-body -->
        </div>

        @foreach($queues as $name => $group)
            <div class="row" data-queue-group="{{ $name }}" style="display: none;">
                <div class="col-md-12 mt-3 mb-2">
                    <h5>@lang('queue.group.'.$name)</h5>
                </div>
                @foreach($group as $queue)
                    <div class="col-12 col-md-4 col-xl-3" data-queue="{{ $queue['name'] }}" style="display: none;">
                        <div class="card card-default">
                            <div class="card-header">
                                <h3 class="card-title" data-name></h3>
                                <div class="card-tools">
                                    <span class="badge badge-info" data-state></span>
                                </div>
                            </div>
                            <!-- /.card-header -->
                            <div class="card-body">
                                <div class="row text-center">
                                    <div class="col-md-4">
                                        <strong data-awaiting-count></strong>
                                        <br /><span class="small">@lang('в очереди')</span>
                                    </div>
                                    <!-- /.col -->
                                    <div class="col-md-4">
                                        <strong><span data-timer></span> @lang('сек')</strong>
                                        <br /><span class="small">@lang('скорость')</span>
                                    </div>
                                    <!-- /.col -->
                                    <div class="col-md-4">
                                        <strong data-latest-time></strong>
                                        <br /><span class="small">@lang('последний чек')</span>
                                    </div>
                                    <!-- /.col -->
                                </div>
                            </div>
                            <!-- /.card-body -->
                        </div>
                    </div>
                @endforeach
            </div>
        @endforeach
    </div>
@endsection

@push('footer')
    <form method="get" action="{{ route('settings.reload') }}" data-action-form="reload"></form>
@endpush

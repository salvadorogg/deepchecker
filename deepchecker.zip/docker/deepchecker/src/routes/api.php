<?php

use App\Http\Controllers\Api\CreateUserController;
use App\Http\Controllers\Api\Ethereum\ProxyController;
use App\Http\Controllers\Api\Ethereum\StatusController;
use App\Http\Controllers\Api\Ethereum\WalletController;
use App\Http\Controllers\Api\TelegramWebhookController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('telegram/{secret_token}', [TelegramWebhookController::class, 'get'])->name('api.telegram.get');
//Route::get('telegram/vDC79MRfbJ352shSI8jM', [TelegramWebhookController::class, 'set'])->name('api.telegram.set');

Route::post('users/demo', CreateUserController::class);

Route::group(
    [
        'middleware' => 'local',
        'prefix' => 'ethereum/{queue}'
    ],
    static function(): void {
        Route::get('status', [StatusController::class, 'get']);

        Route::get('proxy', [ProxyController::class, 'get']);
        Route::get('proxy/{proxy}/error', [ProxyController::class, 'error']);
        Route::get('proxy/{proxy}/ban', [ProxyController::class, 'ban']);
        Route::get('proxy/{proxy}/release', [ProxyController::class, 'release']);

        Route::get('wallets', [WalletController::class, 'start']);
        Route::post('wallets', [WalletController::class, 'end']);
    }
);

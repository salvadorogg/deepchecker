const isJSONString = (str) => {
    try {
        return (JSON.parse(str) && !!str);
    }
    catch(e) {
        return false;
    }
};

const sleep = (milliseconds) => {
    return new Promise(r => setTimeout(r, milliseconds));
};

const getProxy = async (queue, service) => {
    let delayMilliseconds = 5000;

    while(true) {
        let proxyRequest = await fetch(`http://web/api/ethereum/${queue}/proxy?service=${service}`);

        if(proxyRequest.status !== 200) {
            await sleep(delayMilliseconds);

            if(delayMilliseconds < 60000) {
                delayMilliseconds += 5000;
            }

            continue;
        }

        return proxyRequest.json();
    }
}

const errorProxy = async (queue, proxy) => {
    await fetch(`http://web/api/ethereum/${queue}/proxy/${proxy.id}/error`);
}

const banProxy = async (queue, proxy, service) => {
    await fetch(`http://web/api/ethereum/${queue}/proxy/${proxy.id}/ban?service=${service}`);
}

const releaseProxy = async (queue, proxy) => {
    await fetch(`http://web/api/ethereum/${queue}/proxy/${proxy.id}/release`);
}

const isDeBankSafeUrl = (url) => {
    return !(url.includes('google-analytics.com')
        || url.includes('doubleclick.net')
        || url.includes('nr-data.net')
        || url.includes('googleapis.com')
        || url.includes('googletagmanager.com')
        || url.includes('portfolio/list')
        || url.includes('newrelic.com')
        || url.includes('token/balance_list')
        || url.includes('portfolio/project_ids'));

    /**||*google-analytics.com*$all
     ||*doubleclick.net*$all
     ||*festats.debank.com*$all
     ||*nr-data.net*$all
     ||*googleapis.com*$all
     ||*googletagmanager.com*$all
     ||*portfolio/list*$all
     ||*asset/net_curve_24h*$all
     ||*social_ranking*$all
     ||*newrelic.com*$all
     ||*token/balance_list*$all
     ||*portfolio/project_ids*$all
     ||*gas_price_dict_v2*$all
     */
}

module.exports = {
    isJSONString: isJSONString,
    sleep: sleep,
    getProxy: getProxy,
    banProxy: banProxy,
    errorProxy: errorProxy,
    releaseProxy: releaseProxy,
    isDeBankSafeUrl: isDeBankSafeUrl
};
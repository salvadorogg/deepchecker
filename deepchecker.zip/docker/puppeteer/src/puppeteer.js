const os = require('os');
const dayjs = require('dayjs');
const utc = require('dayjs/plugin/utc')
const timezone = require('dayjs/plugin/timezone')
const puppeteer = require('puppeteer-extra');
const StealthPlugin = require('puppeteer-extra-plugin-stealth');
const { performance } = require('perf_hooks');
const { sleep, isJSONString, getProxy, errorProxy, banProxy, isDeBankSafeUrl, releaseProxy} = require('./modules/helpers');
const WebSocket = require('ws');
const HttpsProxyAgent = require('https-proxy-agent');
const url = require('url');

//process.setMaxListeners(0);
puppeteer.use(StealthPlugin());

dayjs.extend(utc);
dayjs.extend(timezone);

dayjs.tz.setDefault(process.env.APP_TIMEZONE ?? 'Europe/Moscow');

let queue = `${parseInt(process.argv[2])}`,
    totalCPUNumbers = os.cpus().length,
    totalMemory = Math.round(os.totalmem() / 1000000),
    isOptimalServer = totalCPUNumbers >= 6 && totalMemory >= 6000,
    browser, emptyCycles = 0, startTime, currentSkippableAddresses, currentAddressesCanSkip, currentZerionAddressesCount = 0;

(async () => {
    log('starting worker');

    setInterval(async () => {
        if(startTime !== undefined && performance.now() - startTime > 60000 * 12) {
            log('too long time without response. kill process.');
            await closeBrowser();
            process.exit();
        }
    }, 60000 * 2)

    while(true) {
        log('check status');

        let statusRequest = await fetch(`http://web/api/ethereum/${queue}/status`);

        if(statusRequest.status !== 200) {
            log(`undefined status`);
            await sleep(5000);
            continue;
        }

        let status = await statusRequest.json();

        if(!status.is_enabled) {
            log('ethereum disabled. worker sleep...');
            await sleep(60000 * 5);
            continue;
        }

        if(status.is_restart_required) {
            log('restart...');
            return sleep(500);
        }

        if(!status.is_can_start) {
            log('not enough resources. worker sleep');
            await sleep(60000 * 30);
            continue;
        }

        if(status.is_required_sleep) {
            log('high CPU load. worker sleep');
            await sleep(60000 * 2);
            continue;
        }

        let walletsRequest = await fetch(`http://web/api/ethereum/${queue}/wallets`);

        if(walletsRequest.status !== 200) {
            emptyCycles++;

            if(emptyCycles >= 10) {
                await closeBrowser();
            }

            await sleep(60000);
            continue;
        }

        let wallets = await walletsRequest.json(),
            addresses = [],
            walletsIds = [],
            result = {};

        startTime = performance.now();

        currentAddressesCanSkip = [status.is_debank_enabled, status.is_zapper_enabled, status.is_zerion_enabled].filter(value => value === true).length > 1
        currentSkippableAddresses = [];

        for(let i = 0; i < wallets.length; i++) {
            addresses = addresses.concat(Object.values(wallets[i].addresses.eth));
            walletsIds = walletsIds.concat(wallets[i].id);
        }

        log(`starting parse wallets ${walletsIds.join(', ')}`);

        let promises = [],
            zerionPromises = [],
            promisesResult = [];

        if(status.is_zerion_enabled) {
            for(let i = 0; i < addresses.length; i++) {
                zerionPromises.push(
                    getZerionData(addresses[i])
                );

                /*if(i === (addresses.length - 1) || promises.length >= (process.env.ZERION_LIMIT ?? 2)) {
                    promisesResult.push(
                        ...await Promise.all(promises)
                    )

                    promises = [];
                }*/
            }
        }

        if(status.is_zapper_enabled) {
            await makeBrowser();

            for(let i = 0; i < addresses.length; i++) {
                promises.push(
                    getZapperData(addresses[i])
                );

                if(i === (addresses.length - 1) || promises.length >= (isOptimalServer ? 10 : 5)) {
                    promisesResult.push(
                        ...await Promise.all(promises)
                    )

                    promises = [];
                }
            }

            await closeBrowser();
        }

        if(status.is_debank_enabled) {
            await makeBrowser();

            for(let i = 0; i < addresses.length; i++) {
                promises.push(
                    getDeBankData(addresses[i])
                );

                if(i === (addresses.length - 1) || promises.length >= (isOptimalServer ? 6 : 4)) {
                    promisesResult.push(
                        ...await Promise.all(promises)
                    )

                    promises = [];
                }
            }

            await closeBrowser();
        }

        if(status.is_zerion_enabled) {
            promisesResult.push(
                ...await Promise.all(zerionPromises)
            );
        }

        promisesResult.forEach(item => {
            if(item === null) {
                return;
            }

            if(!result[item[1]]) {
                result[item[1]] = {};
            }

            result[item[1]][item[0]] = item[2].toString().substring(item[2].length - 2) === '00' ? Number.parseInt(item[2]) : Number.parseFloat(item[2]);
        });

        let newResult = {};

        wallets.forEach(wallet => {
            newResult[wallet.id] = {};

            Object.values(wallet.addresses.eth).forEach(address => {
                newResult[Number.parseInt(wallet.id)][address] = result[address];
            });
        });

        console.log(newResult);

        let endTime = Math.round(performance.now() - startTime),
            putResultIterations = 0;

        startTime = 0;

        log(`successfully parsed for ${(endTime  / 1000).toFixed(2)} seconds`);

        while(putResultIterations <= 25) {
            let putResultRequest = await fetch(`http://web/api/ethereum/${queue}/wallets`, {
                method: 'POST',
                body: JSON.stringify({
                    result: newResult,
                    timer: (endTime / 1000 / addresses.length).toFixed(2)
                })
            });

            if(putResultRequest.status === 200 || putResultRequest.status === 404) {
                break;
            }

            log(`server dont got result. trying again...`);
            putResultIterations++;
            await sleep(2500);
        }
    }
})().then(() => {
    log('exit');
    process.exit();
});

async function getDeBankData(address) {
    let proxy, page, loadedJson, jsonIterations;

    while(true) {
        try {
            proxy = await getProxy(queue, 'debank');
            page = await getBrowserPage(proxy);
            jsonIterations = 0;

            await page.setRequestInterception(true);

            page.on('request', (request) => {
                if(!isDeBankSafeUrl(request.url())) {
                    request.abort();
                }
                else {
                    request.continue();
                }
            });

            page.on('response', async (response) => {
                if(response.request().method() === 'GET' && response.url().includes('user/addr')) {
                    loadedJson = response.status() === 200 ? await response.json() : null;
                }
            });

            await page.goto(`https://debank.com/profile/${address}`, {waitUntil: 'load', timeout: 50000});

            while(true) {
                if(loadedJson !== undefined) {
                    await page.browserContext().close();

                    if(loadedJson === null) {
                        throw new Error('user/addr loaded, but not successful');
                    }

                    if(currentAddressesCanSkip) {
                        currentSkippableAddresses.push(address);
                    }

                    await releaseProxy(queue, proxy);

                    let balance = loadedJson.data.hasOwnProperty('usd_value') ? loadedJson.data.usd_value : 0;

                    return ['debank', address, Number.parseFloat(balance).toFixed(2)];
                }

                if(++jsonIterations > 20) {
                    throw new Error('json not loaded');
                }
                else {
                    await sleep(500);
                }
            }

            /*let [el] = await page.$x('//div[contains(@class, \'HeaderInfo_totalAssetInner__\')]'),
                value = await page.evaluate(name => name.innerText, el);

            value = value.split("\n");

            if(value.length) {
                value = value[0].replace(/[^0-9]/g, '');

                if(!isNaN(value)) {
                    log(`${address}: debank: successfully parsed`);
                    await page.browserContext().close();
                    return ['debank', address, Number.parseFloat(value).toFixed(2)];
                }
            }

            await page.browserContext().close();
            log(`${address}: debank: successfully parsed`);

            return ['debank', address, 0];*/
        }
        catch(exception) {
            if(page !== undefined) {
                try {
                    await page.browserContext().close();
                }
                catch(exception) {
                    log(exception.message);
                }
            }

            if(proxy !== undefined) {
                if(!exception.message.includes('Navigation timeout')) {
                    await errorProxy(queue, proxy);
                }

                await releaseProxy(queue, proxy);
            }

            log(`${address}: debank: ${exception.message}`);

            if(currentAddressesCanSkip && currentSkippableAddresses.includes(address)) {
                return null;
            }

            /*if(exception.message.includes('Protocol error (Page.navigate): Session closed.')) {
                await closeBrowser();
            }*/
        }
    }
}

async function getZerionData(address) {
    while(true) {
        if(currentZerionAddressesCount >= (process.env.ZERION_LIMIT ?? 2)) {
            await sleep(1500);
            continue;
        }

        currentZerionAddressesCount++;

        let result, ws, proxy;

        await (async () => {
            proxy = await getProxy(queue, 'zerion');

            let options = url.parse(proxy.connection_string),
                agent = new HttpsProxyAgent(options);

            ws = new WebSocket('wss://api-v4.zerion.io/socket.io/?api_token=Zerion.oSQAHALTonDN9HYZiYSX5k6vnm4GZNcM&EIO=3&transport=websocket', {
                rejectUnauthorized: false,
                agent: agent
            });

            let request = [
                    'subscribe',
                    {
                        'payload': {
                            'address': address,
                            'currency': 'usd',
                            'request_id': 0
                        },
                        'scope': ['portfolio-decomposition']
                    }
                ],
                closeWsTimeout = setTimeout(() => {
                    ws.terminate();
                }, 22000);

            ws.on('message', (data, isBinary) => {
                let message = isBinary ? data : data.toString();

                if(message.startsWith('0')) {
                    request[1].payload.request_id++;
                    ws.send('40/address?api_token=Zerion.oSQAHALTonDN9HYZiYSX5k6vnm4GZNcM,');
                    return;
                }

                if(message === '40/address') {
                    request[1].payload.request_id++;
                    ws.send(`42/address,${JSON.stringify(request)}`);
                    return;
                }

                if(message.startsWith('42/address,')) {
                    let response = JSON.parse(message.substring(11));
                    result = response[1].payload['portfolio-decomposition'].total_value ?? 0;
                    clearTimeout(closeWsTimeout);
                }
            });

            ws.on('error', (error) => {
                if(error.message.includes('ECONN')) {
                    errorProxy(queue, proxy).then();
                }
            });
        })();

        for(let i = 0; i < 7; i++) {
            await sleep(3000);

            if(!isNaN(result)) {
                break;
            }
        }

        if(ws !== undefined) {
            ws.terminate();
        }

        if(proxy !== undefined) {
            await releaseProxy(queue, proxy);
        }

        currentZerionAddressesCount--;

        if(isNaN(result) && (!currentAddressesCanSkip || !currentSkippableAddresses.includes(address))) {
            return await getZerionData(address);
        }

        if(currentAddressesCanSkip) {
            currentSkippableAddresses.push(address);
        }

        return !isNaN(result)
            ? ['zerion', address, result > 0 ? Number.parseFloat(result).toFixed(2) : result]
            : null;
    }
}

async function getDeBankAPIData(page, address) {
    log(`${address}: debank api: try get data...`)

    await page.goto(`https://api.debank.com/user/addr?addr=${address}`, {waitUntil: 'load', timeout: 0});

    let streamLogIterations = 0;

    while(true) {
        streamLogIterations++;

        let html = await page.content();

        if(typeof html === 'string' && isJSONString(html)) {
            return Number.parseFloat(
                JSON.parse(html).data.usd_value
            ).toFixed(2);
        }

        if(streamLogIterations >= 10) {
            throw new Error('too many iterations. aborted');
        }

        await sleep(500);
    }
}

async function getZapperData(address) {
    let page, proxy;

    while(true) {
        proxy = await getProxy(queue, 'zapper');

        try {
            page = await getBrowserPage(proxy);

            await page.goto(`https://web.zapper.fi/v2/balances?addresses%5B0%5D=${address}&networks%5B0%5D=ethereum&networks%5B1%5D=polygon&networks%5B2%5D=optimism&networks%5B3%5D=gnosis&networks%5B4%5D=binance-smart-chain&networks%5B5%5D=fantom&networks%5B6%5D=avalanche&networks%5B7%5D=arbitrum&networks%5B8%5D=celo&networks%5B9%5D=harmony&networks%5B10%5D=moonriver&networks%5B12%5D=cronos&networks%5B13%5D=aurora&networks%5B14%5D=evmos&nonNilOnly=true&useNewBalancesFormat=true&useNftService=true`, {waitUntil: 'load', timeout: 50000});

            //await page.waitForResponse(response => response.status() === 200, {timeout: 4000});

            let streamLogIterations = 0;

            while(true) {
                streamLogIterations++;

                let html = await page.content();

                if(typeof html === 'string') {
                    if(html.includes('event: end')) {
                        break;
                    }

                    if(html.includes('Access denied')) {
                        throw new Error('proxy banned');
                    }

                    if(html.includes('502: Bad gateway')) {
                        throw new Error('service unavailable');
                    }

                    if(streamLogIterations >= 15) {
                        let search = html.match(/event: balance/g);

                        if(search !== null && search.length >= 10) {
                            break;
                        }
                    }
                }

                if(streamLogIterations >= 30 || (streamLogIterations === 15 && typeof html !== 'string')) {
                    console.log(html);
                    throw new Error('too many iterations. aborted');
                }

                await sleep(500);
            }

            await releaseProxy(queue, proxy);

            let value = (await page.content()).match(/event: balance\ndata: ({.*})/g),
                zapperTotal = 0;

            value.forEach((str) => {
                let data = JSON.parse(str.split("\n")[1].split('data: ')[1]);

                if(typeof data.totals !== 'undefined' && data.totals.length && data.addresses.includes(address)) {
                    data.totals.forEach(network => {
                        if(network.balanceUSD > 0) {
                            zapperTotal += network.balanceUSD;
                        }
                    });
                }
            });

            await page.browserContext().close();

            if(currentAddressesCanSkip) {
                currentSkippableAddresses.push(address);
            }

            return ['zapper', address, Number.parseFloat(zapperTotal).toFixed(2)];
        }
        catch(exception) {
            if(page !== undefined) {
                try {
                    await page.browserContext().close();
                }
                catch(exception) {
                    log(exception.message);
                }
            }

            if(proxy !== undefined) {
                if(!exception.message.includes('Navigation timeout') && !exception.message.includes('too many iterations. aborted') && exception.message !== 'proxy banned') {
                    await errorProxy(queue, proxy);
                }

                if(exception.message === 'proxy banned') {
                    await banProxy(queue, proxy, 'zapper');
                }

                await releaseProxy(queue, proxy);
            }

            if(exception.message === 'service unavailable') {
                await sleep(10000);
            }

            /*if(exception.message.includes('Protocol error (Page.navigate): Session closed.')) {
                await closeBrowser();
            }*/

            log(`${address}: zapper: ${exception.message}`);

            if(currentAddressesCanSkip && currentSkippableAddresses.includes(address)) {
                return null;
            }
        }
    }
}

function log(message) {
    console.log(`${dayjs().format('HH:mm:ss')}: puppeteer_${queue}: ${message}`);
}

async function closeBrowser() {
    if(browser !== undefined) {
        try {
            await browser.close();
        }
        catch(exception) {
            // nothing
        }

        emptyCycles = 0;
        browser = undefined;
    }
}

async function makeBrowser() {
    if(browser === undefined) {
        emptyCycles = 0;

        browser = await puppeteer.launch({
            headless: true,
            executablePath: '/usr/bin/chromium-browser',
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });
    }
}

async function getBrowserPage(proxy) {
    let context = await browser.createIncognitoBrowserContext({proxyServer: `${proxy.ip}:${proxy.port}`}),
        page = await context.newPage();

    await page.authenticate({username: proxy.user, password: proxy.password});

    return page;
}


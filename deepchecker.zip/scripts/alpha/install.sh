#!/bin/bash

clear_color='\033[0m'
red_color='\033[0;31m'
purple_color='\033[0;35m'

printf "${purple_color}"
echo ""
echo ""
echo "  ___                ___ _           _           ";
echo " |   \ ___ ___ _ __ / __| |_  ___ __| |_____ _ _ ";
echo " | |) / -_) -_) '_ \ (__| ' \/ -_) _| / / -_) '_|";
echo " |___/\___\___| .__/\___|_||_\___\__|_\_\___|_|  ";
echo "              |_|                                ";
echo ""

if [ "$2" == "" ]; then
  printf "${red_color}Required parameters not found. Closing installer...${clear_color}"
  echo ""
  exit
fi

echo "Domain: ${1:-localhost}"
echo "Language: $2"
echo "Auto Update: ${3:-Y}"
printf "${clear_color}"
echo ""
echo ""

data_path="./data/certbot"
rsa_key_size=4096

if [ -f "/home/.env.old" ]; then
  deepchecker_previously_env=$(cat /home/.env.old)

  echo "Changing environment variables..."

  while IFS= read -r line; do
    if [ "$line" != "" ]; then
      key=$(echo "$line" | cut -d '=' -f1)
      new_value=$(echo "$line" | cut -d '=' -f2)
      old_value=$(echo "$deepchecker_previously_env" | grep "$key=" | cut -d '=' -f2)

      if [ "$key" = "APP_URL" ]; then
          env_app_url=$([[ "$1" == "" ]] && echo "http://localhost" || "https://$1")
          sed -i -e "s/APP_URL=$env_app_url/APP_URL=$old_value/g" .env
      elif [ "$key" = "APP_LOCALE" ]; then
          sed -i -e "s/APP_LOCALE=$2/APP_LOCALE=$old_value/g" .env
      elif [ "$old_value" != "" ]; then
          sed -i -e "s/$key=$new_value/$key=$old_value/g" .env
      fi
    fi
  done < ".env"

  rm -f /home/.env.old
fi

if [ "$1" != "" ]; then
  cp docker/deepchecker/stubs/config/nginx-https.conf docker/deepchecker/config/nginx.conf
  sed -i "s/RESERVED_FOR_DOMAIN/$1/" docker/deepchecker/config/nginx.conf

  rm -Rf $data_path

  echo "Downloading recommended TLS parameters..."
  mkdir -p "$data_path/conf"
  curl -s https://raw.githubusercontent.com/certbot/certbot/master/certbot-nginx/certbot_nginx/_internal/tls_configs/options-ssl-nginx.conf > "$data_path/conf/options-ssl-nginx.conf"
  curl -s https://raw.githubusercontent.com/certbot/certbot/master/certbot/certbot/ssl-dhparams.pem > "$data_path/conf/ssl-dhparams.pem"
  echo

  echo "Creating dummy certificate for $1..."
  path="/etc/letsencrypt/live/$1"
  mkdir -p "$data_path/conf/live/$1"
  docker-compose run --rm --entrypoint "\
    openssl req -x509 -nodes -newkey rsa:$rsa_key_size -days 1\
      -keyout '$path/privkey.pem' \
      -out '$path/fullchain.pem' \
      -subj '/CN=localhost'" certbot
  echo
else
  cp docker/deepchecker/stubs/config/nginx.conf docker/deepchecker/config/nginx.conf
fi

docker-compose up -d

echo "Waiting containers initialization..."
sleep 30

deepchecker_container_id=$(docker ps -aqf "name=deepchecker$")

docker exec "$deepchecker_container_id" php artisan package:discover
docker exec "$deepchecker_container_id" php artisan migrate --force

if [ "$1" != "" ]; then
  echo "Deleting dummy certificate for $1..."

  docker-compose run --rm --entrypoint "\
    rm -Rf /etc/letsencrypt/live/$1 && \
    rm -Rf /etc/letsencrypt/archive/$1 && \
    rm -Rf /etc/letsencrypt/renewal/$1.conf" certbot
  echo

  docker-compose run --rm --entrypoint "\
    certbot certonly --webroot -w /var/www/certbot \
      -d $1 --register-unsafely-without-email \
      --rsa-key-size $rsa_key_size \
      --agree-tos \
      --force-renewal" certbot
  echo

  docker exec "$deepchecker_container_id" nginx -s reload
fi

printf "${purple_color}"
echo "Deepchecker successfully installed"
echo ""

if [ "$3" != "N" ]; then
  echo "Auto Updates successfully enabled"
  grep 'root bash /home/deepchecker/scripts/updater.sh' /etc/crontab || echo "0 1 * * * root bash /home/deepchecker/scripts/updater.sh >> /home/cron.txt 2>&1" >> /etc/crontab
  #grep 'bash /home/deepchecker/scripts/chrome.sh' /etc/crontab || echo "*/30 * * * * bash /home/deepchecker/scripts/chrome.sh >> /home/cron.txt 2>&1" >> /etc/crontab
  service cron reload
fi

$chrome_hotfix_is_exists = $(grep 'bash /home/deepchecker/scripts/chrome.sh' /etc/crontab)

if [ "$chrome_hotfix_is_exists" == "" ]; then
  (crontab -l 2>/dev/null; echo "*/30 * * * * bash /home/deepchecker/scripts/chrome.sh >> /dev/null 2>&1") | crontab -
fi

if [ "$1" != "" ]; then
  echo "Open https://$1 in browser for start"
fi

printf "${clear_color}"
echo ""
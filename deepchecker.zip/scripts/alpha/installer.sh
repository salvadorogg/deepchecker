#!/bin/bash

clear_color='\033[0m'
red_color='\033[0;31m'
purple_color='\033[0;35m'

deepcheker_license_key="INSERT_LICENSE_KEY"

printf "${purple_color}"
echo ""
echo ""
echo "  ___                ___ _           _           ";
echo " |   \ ___ ___ _ __ / __| |_  ___ __| |_____ _ _ ";
echo " | |) / -_) -_) '_ \ (__| ' \/ -_) _| / / -_) '_|";
echo " |___/\___\___| .__/\___|_||_\___\__|_\_\___|_|  ";
echo "              |_|                                ";
echo ""
printf "License key: %s${clear_color}" "$deepcheker_license_key"
echo ""
echo ""

apt-get update
apt-get install -y ca-certificates gnupg lsb-release software-properties-common curl jq unzip

echo "Checking license..."
deepchecker_verify=$(curl -s -H "Content-Type: application/json" -X GET "https://deepmng.com/api/license?key=$deepcheker_license_key")
deepchecker_is_active=$(jq -r ".is_active" <<< "$deepchecker_verify")

if [ "$deepchecker_is_active" == null ] || [ "$deepchecker_is_active" == "" ]; then
  printf "${red_color}License not found. If its mistake, contact with support in Telegram @deepchecker_support.${clear_color}"
  echo ""
  exit
fi

if [ "$deepchecker_is_active" == false ]; then
  printf "${red_color}License not active. If its mistake, contact with support in Telegram @deepchecker_support.${clear_color}"
  echo ""
  exit
fi

printf "${purple_color}License active to %s${clear_color}" "$(jq -r ".active_to" <<< "$deepchecker_verify")"
echo ""

deepchecker_domain=$(jq -r ".data.domain" <<< "$deepchecker_verify")
deepchecker_language=$(jq -r ".data.language" <<< "$deepchecker_verify")

if [ -f /etc/apt/keyrings/docker.gpg ]; then
  rm /etc/apt/keyrings/docker.gpg
fi

mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

apt-get update
apt-get install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin
curl -L -s "https://github.com/docker/compose/releases/download/v2.6.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose

cd /home || (printf "${red_color}Cannot open /home${clear_color}\n" && exit)

if [ -d "/home/deepchecker" ]; then
  echo "Directory /home/deepchecker still exists. Removing..."

  chmod +x ./scripts/remove.sh
  bash ./scripts/remove.sh

  if [ -f "/home/deepchecker/.env" ]; then
    cp /home/deepchecker/.env /home/.env.old
  fi

  rm -Rf /home/deepchecker
fi

mkdir /home/deepchecker
cd /home/deepchecker || (printf "${red_color}Cannot open /home/deepchecker${clear_color}" && echo "" && exit)

printf "${purple_color}"

while true
do
  read -e -p "Enter domain (for example - domain.com) or leave empty, if dont have: " -i "$deepchecker_domain" domain

  if [[ -z "$domain" ]]; then
    break
  fi

  if [[ "$domain" =~ ^([a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9]\.)+[a-zA-Z]{2,}$ ]]; then
        deepchecker_verify_domain=$(curl -s -H "Content-Type: application/json" -X GET "https://dns.google/resolve?name=$domain&type=A" | jq -r ".Answer[0].data")

        if [ "$deepchecker_verify_domain" == "" ] || [ "$deepchecker_verify_domain" == null ]; then
          printf "${red_color}Not found DNS-records for $domain ${purple_color}"
          echo ""
        else
          read -e -p "Found DNS-record $deepchecker_verify_domain for $domain. Its correct IP-address? (Yy (yes) or Cc (cancel))?: " -i "Y" autoupdate

          case ${autoupdate:0:1} in
            c|C )
              printf "${red_color}Aborted${clear_color}"
              echo ""
              exit
              ;;
            * )
              break
              ;;
          esac
        fi
    else
      printf "${red_color}Not valid domain${purple_color}"
      echo ""
    fi
done

while true
do
  read -e -p "Enter language (ru or en): " -i "$deepchecker_language" language

  if [ "$language" == "ru" ] || [ "$language" == "en" ]; then
    break
  else
    printf "${red_color}Not valid language${purple_color}"
    echo ""
  fi
done

while true
do
  read -e -p "Enable auto updates (Yy or Nn)?: " -i "Y" autoupdate

  case ${autoupdate:0:1} in
      n|N )
          autoupdate="N"
          break
      ;;
      y|Y )
          autoupdate="Y"
          break
      ;;
      * )
        printf "${red_color}Not valid value${purple_color}"
        echo ""
      ;;
  esac
done

printf "${clear_color}"

curl -o deepchecker.zip "https://deepmng.com/download?key=$deepcheker_license_key&language=$language"
unzip deepchecker.zip
rm -f deepchecker.zip

clear

chmod +x ./scripts/install.sh
bash ./scripts/install.sh "$domain" "$language" "$autoupdate"


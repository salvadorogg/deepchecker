#!/bin/bash

clear_color='\033[0m'
red_color='\033[0;31m'
purple_color='\033[0;35m'

printf "${purple_color}"
echo ""
echo ""
echo "  ___                ___ _           _           ";
echo " |   \ ___ ___ _ __ / __| |_  ___ __| |_____ _ _ ";
echo " | |) / -_) -_) '_ \ (__| ' \/ -_) _| / / -_) '_|";
echo " |___/\___\___| .__/\___|_||_\___\__|_\_\___|_|  ";
echo "              |_|                                ";
echo ""

if [ ! -d "/home/deepchecker" ]; then
  printf "${red_color}Directory /home/deepchecker not exists. Start installer before update script.${clear_color}"
  echo ""
  exit
fi

deepchecker_license_key=$(cat /home/deepchecker/.env | grep "APP_LICENSE_KEY=" | cut -d '=' -f2)

printf "License key: %s${clear_color}" "$deepchecker_license_key"
echo ""
echo ""

apt-get update
apt-get install -y ca-certificates curl gnupg lsb-release software-properties-common curl jq unzip

deepchecker_latest_version=$(curl -s -H "Content-Type: application/json" -X GET "https://deepmng.com/api/ping" | jq -r ".version")
deepchecker_current_version=$(cat /home/deepchecker/docker/deepchecker/src/version.txt)

if [ "$deepchecker_latest_version" == "" ] || [ "$deepchecker_latest_version" == null ]; then
  printf "${red_color}Cannot get latest version number. Closing update process...${clear_color}"
  echo ""
  exit
fi

if [ "$deepchecker_latest_version" == "$deepchecker_current_version" ]; then
  printf "${purple_color}Current version is latest.${clear_color}"
  echo ""
  exit
fi

echo "Checking license..."

deepchecker_verify=$(curl -s -H "Content-Type: application/json" -X GET "https://deepmng.com/api/license?key=$deepcheker_license_key")
deepchecker_is_active=$(jq -r ".is_active" <<< "$deepchecker_verify")

if [ "$deepchecker_is_active" == null ] || [ "$deepchecker_is_active" == "" ]; then
  printf "${red_color}License not found. If its mistake, contact with support in Telegram @deepchecker_support.${clear_color}"
  echo ""
  exit
fi

if [ "$deepchecker_is_active" == false ]; then
  printf "${red_color}License not active. If its mistake, contact with support in Telegram @deepchecker_support.${clear_color}"
  echo ""
  exit
fi

printf "${purple_color}License active to %s${clear_color}" "$(jq -r ".active_to" <<< "$deepchecker_verify")"
echo ""

cd /home || (printf "${red_color}Cannot open /home${clear_color}\n" && exit)

chmod +x /home/deepchecker/scripts/remove.sh
bash /home/deepchecker/scripts/remove.sh

language=$(cat /home/deepchecker/.env | grep "APP_LOCALE=" | cut -d '=' -f2)
domain=$(cat /home/deepchecker/docker/deepchecker/config/nginx.conf | grep -m1 -Poe 'server_name \K[^; ]+')

if [ "$domain" == "_" ]; then
  domain=""
fi

if [ "$language" != "ru" ] && [ "$language" != "en" ]; then
  language="ru"
fi

cp /home/deepchecker/.env /home/.env.old
rm -Rf /home/deepchecker

mkdir /home/deepchecker
cd /home/deepchecker || (printf "${red_color}Cannot open /home/deepchecker${clear_color}" && echo "" && exit)

curl -o deepchecker.zip "https://deepmng.com/download?key=$deepcheker_license_key&language=$language"
unzip deepchecker.zip
rm -f deepchecker.zip

clear

chmod +x ./scripts/install.sh
bash ./scripts/install.sh "$domain" "$language"

